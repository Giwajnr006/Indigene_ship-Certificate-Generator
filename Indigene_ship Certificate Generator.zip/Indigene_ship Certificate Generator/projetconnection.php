<?php

$hostname = "localhost";
$hostuser = "root";
$hostpass = "07061992697";
$hostdb = "myproject";

@mysql_connect($hostname, $hostuser, $hostpass) or die (mysql_error());
@mysql_select_db($hostdb);
?>