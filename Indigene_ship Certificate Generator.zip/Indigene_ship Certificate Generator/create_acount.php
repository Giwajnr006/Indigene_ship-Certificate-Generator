<?php
session_start();
ob_start();
require "projectconnection.php"; // Ensure this file uses mysqli as well
$date1 = date('d-m-y h:i:s');

if(isset($_POST['bott'])) {
    $fname = $_POST['fname'];
    $mname = $_POST['mname'];
    $lname = $_POST['lname'];
    $uname = $_POST['uname'];
    $pass = $_POST['pass'];
    $cpass = $_POST['cpass'];
    $sn = rand(123456, 999999);

    if($pass != $cpass) {
        $msg = "password does not match";
    } else {
        // Insert the new account into the database
        $query = "INSERT INTO sign_up (sn, fname, mname, lname, uname, password, cpassword) VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = mysqli_prepare($connection, $query);
        mysqli_stmt_bind_param($stmt, 'issssss', $sn, $fname, $mname, $lname, $uname, $pass, $cpass);
        
        if(mysqli_stmt_execute($stmt)) {
            $_SESSION['serial_no'] = $sn;
            header("location:mydashboard.php");
        } else {
            echo "<div class='alert alert-danger'><strong>Error</strong> something went wrong</div>";
        }
        
        mysqli_stmt_close($stmt);
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Sign up</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <link rel="icon" type="text/image" href="img/a1.jpeg">
    <!-- Linking Bootstrap -->
    <link type="text/css" rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Linking custom CSS -->
    <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.css">
    <!-- Linking JS for Bootstrap -->
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="css/style1.css" />
    <script type="text/javascript" src="js/modernizr.custom.86080.js"></script> 
</head>
<body id="page" style="background-image: url(images/80.png);background-size: cover;background-attachment: fixed;">
<ul class="cb-slideshow"> 
    <li><span>Image 01</span></li>
    <li><span>Image 02</span></li>
    <li><span>Image 03</span></li>
    <li><span>Image 04</span></li>
    <li><span>Image 05</span></li>
    <li><span>Image 06</span></li>
</ul>

<div class="container">
    <div class="codrops-top">
        <div class="clr"></div>
    </div>
</div>

<!-- Header -->
<div class="navbar navbar-default navbar-fixed-top" style="background-color:#2E8B57; height: 60px; border-bottom: 2px solid; color: yellow;">
    <div class="navbar navbar-brand">
        <a href="index.html"><img src="img/a1.jpeg" width="65%" height="65%" style="margin-top: -15px; float: left;" class="img-responsive img-circle"></a>
    </div>
    <p class="txtlogo" style="color:#fff; margin-top:25px; margin-left: -190px; font-size: 20px;">
        GOMBE L.G.A INDIGENE APPLICATION
        <a href="home.php" style="margin-left: 180px; color: #fff;">
            <span class="glyphicon glyphicon-log-out" style="margin-top:0px; margin-left: 180px; color:#fff;"></span> Logout
        </a>
    </p>
</div>

<div class="container" style="margin-top: 90px; height: 350px;">
    <div class="row">
        <div class="col-sm-3 col-lg-3"></div>
        <div class="col-sm-6 col-lg-6">
            <div class="panel panel-default" style="margin-bottom: 140px; margin-top: 50px; border: 4px solid; border-radius:6px; color: #afc0be;">
                <div class="well" style="background-color: #2E8B57; color: #fff;">
                    <h4 class="panel-title" style="color: #fff; font-size: 25px;"> Create new account
                        <span style="font-size: 30px;color: #fff;float:right;" class="glyphicon glyphicon-pencil"></span>
                    </h4>
                </div>
                <!-- Panel body -->
                <div class="panel-body">
                    <?php if(isset($msg)) { 
                        echo "<div class='alert alert-danger'><strong>Error</strong> " . $msg . "</div>";
                    } ?>
                    <form role="form" method="POST" style="color:#fff;">
                        <div class="form-group">
                            <label for="firstname" style="color:#fff;">First Name:</label>
                            <div class="form-group input-group">
                                <span class="input-group-addon"><span class="glyphicon glyphicon-name"></span></span>
                                <input type="text" name="fname" placeholder="First Name" class="form-control" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="firstname">Middle Name:</label>
                            <div class="form-group input-group">
                                <span class="input-group-addon"><span class="glyphicon glyphicon-name"></span></span>
                                <input type="text" name="mname" class="form-control" placeholder="Middle Name" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="firstname">Last Name:</label>
                            <div class="form-group input-group">
                                <span class="input-group-addon"><span class="glyphicon glyphicon-name"></span></span>
                                <input type="text" name="lname" class="form-control" placeholder="Last Name">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="firstname">User Name:</label>
                            <div class="form-group input-group">
                                <span class="input-group-addon"><span class="glyphicon glyphicon-user"></span></span>
                                <input type="text" name="uname" class="form-control" placeholder="User Name">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="firstname">Password:</label>
                            <div class="form-group input-group">
                                <span class="input-group-addon"><span class="glyphicon glyphicon-lock" style="color:e14f00;"></span></span>
                                <input type="password" name="pass" class="form-control" placeholder="Password">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="firstname" style="color:#fff;">Confirm Password:</label>
                            <div class="form-group input-group">
                                <span class="input-group-addon"><span class="glyphicon glyphicon-lock"></span></span>
                                <input type="password" name="cpass" class="form-control" placeholder="Confirm Password">
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary btn-lg" name="bott" style="background-color:#3cb371;">
                            <span class="glyphicon glyphicon-send"> Sign_up</span>
                        </button>
                        &nbsp;&nbsp;
                        <button type="reset" class="btn btn-default btn-lg" style="background-color:#3cb371; color:#fff;">
                            <span class="glyphicon glyphicon-trash"></span> Reset Form
                        </button>
                        &nbsp;&nbsp;
                        <a href="#top" class="btn btn-info btn-lg" style="float: right; color: #fff; background-color:#3cb371; font-size: 13px;" role="button">Back to top</a>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-sm-3 col-lg-3"></div>
    </div>
</div>

<!-- Footer -->
<div class="footer" style="margin-top:45px; background-color: #2E8B57; opacity: 0.9;">
    <div class="navbar navbar-inverse navbar-fixed-bottom" style="height: 50px; background-color: #2E8B57; border-top: 2px solid yellow;">
        <div class="navbar navbar-brand"> 
            <p>
                <marquee direction="left" style="color: yellow;">Welcome indigeneship online application. Copyright &#169; 2024 | 
                    <a href="http://Gombe.gme.ng/" target="_blank" style="color: yellow">app.ng</a> | All rights reserved. 
                    Copyright &#169; gigs_tech | 
                    <a href="http://Gombe.gme.ng/" target="_blank" style="color: yellow">app.ng</a> | All rights reserved. 
                </marquee>
                <b><a href="#Top" class="bb" style="float: right; margin-top: 40px;">back to top</a></b>
            </p>
        </div>
    </div>
</div>

<!-- Scripts -->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script>
    $(function(){
        $('.nav-tabs a:first').tab('show');
    });
</script>
<script>
$(document).ready(function(){
    $('[data-toggle="popover"]').popover(); 
});
</script>
</body>
</html>
