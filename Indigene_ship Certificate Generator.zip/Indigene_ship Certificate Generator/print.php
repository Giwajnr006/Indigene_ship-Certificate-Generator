<?php
session_start();
ob_start();
require "projectconnection.php";
$date1 =date('d-m-y h:i:s');
$Name=$_SESSION["name"];
?>
<!DOCTYPE html>
<html>
<head>
	<title>print form</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
  <link rel="icon" type="text/image" href="img/a1.jpeg">
	<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
	<!--linking boostrap-->
	<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css">
	<!--linking custom CSS-->
	<link rel="stylesheet" type="text/css" href="css/mystyle.css">
	<!--linking JS for boostrap-->
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
</head>
<body>
<div class="container">
  <div class="row">
    <div class="col-sm-12 col-lg-12">
      <div class="panel panel-default" style="height: 70% margin-top:50px;">
        <div class="panel-body">
          
          <table class='table'>
                            <tr>
                                <td><label class='labell'><b>Session:</b>&emsp;2017/18</label></td>
                                <td><label class='labell'><b>Form Number:</b>&emsp;$form</label></td>
                                <td><label class='labell'><b>Duration:</b>&emsp;1year</label></td>
                                
                            </tr>
                            <tr>
                                <td><label class='labell'><b>Department:</b><br>$depart</label></td>
                                <td><label class='labell'><b>Course:</b><br>$course</label></td>
                                <td><label class='labell'><b>Reg. No.:</b><br>$reg</label></td>
                            </tr>
                            <tr>
                                <td><label class='labell'><b>Surname:</b><br>$sname</label></td>
                                <td><label class='labell'><b>Other Name:</b><br>$oname</label></td>
                                <td><label class='labell'><b>First Name:</b><br>$fname</label></td>
                            </tr>
                            <tr>
                                
                                <td><label class='labell'><b>Gender:</b><br>$sex</label></td>
                                <td><label class='labell'><b>Date of birth:</b><br>$dob</label></td>
                                
                            </tr>
                            <tr>
                                <td><label class='labell'><b>Phone Number:</b><br>$phone</label></td>
                                <td><label class='labell'><b>Email:</b><br>$email</label></td>
                            </tr>
                             <tr>
                                <td><label class='labell'><b>Nationality:</b><br>$nationality</label></td>
                                <td><label class='labell'><b>State:</b><br>$state</label></td>
                                <td><label class='labell'><b>L.G.A:</b><br>$lga</label></td>
                            </tr>
                            <tr>
                                <td><label class='labell'><b>Address:</b><br>$address</label></td>
                            </tr>";
                    }
                    $dispalycourses = mysql_query("SELECT * FROM `course_reg_tbl` WHERE program = '".$rows['stdcourse']."' AND std_RegNum = '".$rows['stdRegNum']."' AND c_semester ='first' AND c_status = 'core'");
            $numbers = "";
            for ($i=0; $i<mysql_num_rows($dispalycourses); $i++) { 
                 
                 $numbers = $numbers + $i;
             }

            echo " <tr>
                    <td><b>First Semester&emsp;</b><br><b>&emsp;&emsp;Core Courses:&emsp;&emsp;&emsp;</b>$numbers</td>
                   </tr>";

                $dispalycourses = mysql_query("SELECT * FROM course_reg_tbl WHERE program = '".$rows['stdcourse']."' AND std_RegNum = '".$rows['stdRegNum']."' AND c_semester ='first' AND c_status = 'elective'");
            $numbers = "";
            for ($i=0; $i<mysql_num_rows($dispalycourses); $i++) { 
                 
                 $numbers = $numbers + $i;
             }
                   echo "<tr>
                    <td><b>&emsp;&emsp;Elective Courses:&emsp;</b>$numbers</td>
                   </tr>";

                $dispalycourses = mysql_query("SELECT c_status FROM course_reg_tbl WHERE program = '".$rows['stdcourse']."' AND std_RegNum = '".$rows['stdRegNum']."' AND c_semester ='second' AND c_status = 'CORE'");
            $numbers = "";
            for ($i=0; $i<mysql_num_rows($dispalycourses); $i++) { 
                 
                 $numbers = $numbers + $i;
             }

            echo " <tr>
                    <td><b>Second Semester&emsp;</b><br><b>&emsp;&emsp;Core Courses:&emsp;&emsp;&emsp;</b>$numbers</td>
                   </tr>";

                $dispalycourses = mysql_query("SELECT c_status FROM course_reg_tbl WHERE program = '".$rows['stdcourse']."' AND std_RegNum = '".$rows['stdRegNum']."' AND c_semester ='second' AND c_status = 'elective'");
            $numbers = "";
            for ($i=0; $i<mysql_num_rows($dispalycourses); $i++) { 
                 
                 $numbers = $numbers + $i;
             }
                   echo "<tr>
                    <td><b>&emsp;&emsp;Elective Courses:&emsp;</b>$numbers</td>
                   </tr>";

                $dispalycourses = mysql_query("SELECT std_cu FROM course_reg_tbl WHERE program = '".$rows['stdcourse']."' AND std_RegNum = '".$rows['stdRegNum']."'");
            $unit = "";
            for ($i=0; $i<mysql_num_rows($dispalycourses); $i++) { 
                 $unit = $unit + mysql_result($dispalycourses,$i, 'std_cu');
                 
                 
             }
             echo "<tr>
                    <td><b>Total Credit Unit:&emsp;&emsp;</b>$unit</td>
                   </tr>
                   <tr>
                                <td><br><br><label class='labell'><u>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;</u><br><b> H.O.D Sign and Stamp:</b></label></td>
                                <td></td>
                                <td><br><br><label class='labell'><u>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;</u><br><b> Faculty Sign and Stamp:</b></label></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td><button type='button' onclick='window.print();'>print</button></td>
                                <td></td>
                            </tr>
                </table>";
        </div>
      </div>
    </div>
  </div>
</div>
</body>
</html>