<?php
session_start();
ob_start();
require "projectconnection.php";
$date1 =date('d-m-y h:i:s');
$Name=$_SESSION["name"];
$mname =$_SESSION["mname"];
$lname =$_SESSION["lname"];
$dob=$_SESSION['dob'];
$Gender=$_SESSION['gender'];
$ward= $_SESSION['ward'];
$phpone =$_SESSION['phone'];
$comdate =$_SESSION['comdate'];
$appNo=$_SESSION['sn'];
?>
<!DOCTYPE html>
<html>
<head>
	<title>Clearance form</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
  <link rel="icon" type="text/image" href="img/a1.jpeg">
	<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
	<!--linking boostrap-->
	<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css">
	<!--linking custom CSS-->
	<link rel="stylesheet" type="text/css" href="css/mystyle.css">
	<!--linking JS for boostrap-->
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
</head>
<body style="background-image: url(images/80.png);background-size: cover;background-attachment: fixed;">
<div class ="navbar navbar-default  navbar-fixed-top" style=" background-color:#3cb371; height: 60px; border-bottom: 2px solid; color: yellow;">
    <div class="navbar navbar-brand">
        <a <href="index.html"><img src="img/a1.jpeg" width="65%" height="65%"   style="margin-top: -15px;float: left;" class="img-responsive img-circle"></a>
    </div>
    <p class="txtlogo" style="color:#fff; margin-top:25px; margin-left: -190px; font-size: 20px;">GOMBE INDGENE APPLICATION
    <a href="home.php" style="margin-left: 200px; color: #fff;"><span class="glyphicon glyphicon-log-out" style =" margin-top:0px; margin-left: 200px; color:#fff;"> </span> Logout</a>
    </p>
    </div>
<div class="container" style="margin-top: 100px;">
  <div class="row">
  <div class="col-sm-2 col-lg-2"></div>
    <div class="col-sm-8 col-lg-8">
      <div class="panel panel-default">
        <div class="panel-body">

          <form role ="form">
            <div class="table table-responsive">
              <table class="table table-condensed"> 
                 
                <tr><td colspan="6"><img src="images/flag2.png" width="100px" height="60px" style="margin-left: 200px;"></td></tr>
                  <tr><td colspan="6">
                  <p style="margin-left: 180px;"> GOMBE LOCAL GOVERNMENT<br> <p style="margin-left: 200px; margin-top: -5px;">Gombe state of Nigeria.</p></p></td></tr>
                  <tr><td colspan="6">
                    <div class="well" style="background-color: #2E8B57; height: 50px; border-radius: 50px;">
                      <p style="color: #FFF; font-size: 20px; margin-top: 0px; margin-left: 60px;">GOMBE INDIGENCE APPLICATION DETAILS</p>
                    </div>
                  </td>
                  </tr>
                  
                </tr>
                <tr><td colspan="6">
                personal information:</td></tr>
                <tr>
                  <td>full Name:</td>
                  <td></td>
                  <td colspan="4"><?php echo $Name." ".$mname." ".$lname;?></td>
                </tr>
                <tr>
                  <td>Gender:</td>
                  <td colspan="2"><?php echo $Gender;?></td>
                  <td>Date of birth:</td>
                  <td colspan="1"><?php echo $dob;?></td>
                </tr>

               <tr>
                  <td>WARD:</td>
                  <td colspan="2"><?php echo $ward;?></td>
                  <td>phone no:</td>
                  <td colspan="1"><?php echo $phpone;?></td>
                </tr>
                 <tr>
                  <td>Date apply</td>
                  <td colspan="2"><?php echo $comdate;?></td>
                  <td>APPLICATION NUMBER:</td>
                  <td colspan="1"><?php echo $appNo;?></td>
                </tr>
                <tr><td colspan="5"><span class="glyphicon glyphicon-certificate" style="color:#2E8B57; margin:40px 0px 0px 200px; font-size: 80px;"></span></td>
                
                                
                                <td colspan="6"><button type='button' onclick='window.print();' style="margin-top: 80px; "> <span class="glyphicon glyphicon-print" ></span> print</button></td>
                                <td></td>
                            </tr>
              </table>
            </div>                                      
          </form>
        </div>
      </div>
    </div>
    <div class="col-sm-2 col-lg-2"></div>
  </div>
</div>
</body>
</html>