<?php
function validatePassword($pass1,$pass2)
{
	$returnValue;
	if ($pass1 == $pass2){
		$returnValue ="yes";

	}
	else{
		$returnValue ="no";

	}
	return $returnValue;
}
function validationInput($test){
	$check;
	if (!empty($check)){
		
	}
}


?>