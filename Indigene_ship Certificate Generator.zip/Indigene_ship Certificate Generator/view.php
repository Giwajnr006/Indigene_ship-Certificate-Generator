<?php
   
    require "projectconnection.php";

?>
<!DOCTYPE html>
<html>
<head>
    <title>manage record</title>
    <meta charset="utf-8">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="=device-, initial-scale=1.0">
  <link rel="icon" type="text/image" href="img/a1.jpeg"> 
    <!--linking boostrap-->
    <link type="text/css" rel="stylesheet" href="css/bootstrap.min.css">
    <!--linking custom CSS-->
  <link rel="stylesheet" type="text/css" href="css/font-awesome.css">
    <link rel="stylesheet" type="text/css" href="css/mystyle.css">
    
</head>


<!--Begening of social icons-->
    <style>
      
.facebook:before{
    content:'\f09a';
  width:15px;
    color: #fff;
    font-family: 'fontawesome';
    font-size: 25px;
  text-decoration:none;
}
.twitter:before{
    content:'\f099';
    color: #fff;
    font-family: 'fontawesome';
    font-size: 25px;
}
.rss:before{
    content:'\f09e';
    color: #fff;
    font-family: 'fontawesome';
  font-size: 25px;
  
}
.google:before{
    content:'\f0d5';
    color: #fff;
    font-family: 'fontawesome';
  font-size: 25px;
} 
    </style>

    <!--End of social icons-->
<body id="page" style="background-image: url(images/80.png);background-size: cover;background-attachment: fixed;">
<!--header-->
<div class ="navbar navbar-default  navbar-fixed-top" style=" background-color:#2E8B57; height: 60px; border-bottom: 2px solid; color: yellow;">
    <div class="navbar navbar-brand">
        <a <href="index.html"><img src="img/a1.jpeg" width="65%" height="65%"   style="margin-top: -15px;float: left;" class="img-responsive img-circle"></a>
    </div>
    <p class="txtlogo" style="color:#fff; margin-top:25px; margin-left: -190px; font-size: 20px;">GOMBE LOCAL GOVERNMENT
      <div style="float: right; margin-top: -40px; margin-right: 10px; padding: 0px 10px 0px 10px;">
        <a href="www.facebook.com" title="www.facebook.com/gme.lga" ><span class="facebook"></span></a> 
        <a href="www.twitter.com" title="www.twitter.com/@gme.lga"><span class="twitter"></span></a> 
        <a href="www.rss.com" title="www.rss.com/gme.lga"><span class="rss"></span></a> 
        <a href="www.google.com" title="www.googleplus.com/gme.lga"><span class="google"></span></a> 
      </div>
    
    
    </p>
 
    
<nav class="navbar navbar-default navbar-fixed-top" role="navigation" style="background-color:#fff;margin-top: 60px; border-bottom: 2px solid; color: yellow;">
        <div class="container-fluid">
            <!--Brand and toggle get grouped-->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" 
                data-target="#col">
                    <span class="sr-only">toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                
                
            </div>
            <!--collect the nav links, forms and other content for toggle-->
            <div class="collapse navbar-collapse" id="col">
                <ul class="nav navbar-nav">
                    <li><a href="home.php">
                    <span class="glyphicon glyphicon-home"></span> Home
                    <span class="sr-only">(Current)</span></a></li>
                    
                </ul>
                
                <ul class="nav navbar-nav" style="margin-left: 0px;">
                    
                    <li class="dropdown active" style="margin-left: 80px;">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                    <span class="glyphicon glyphicon-user" style="height: 15px;"></span>&emsp;
                    WELCOME ADMIN!
                    <span class="caret"></span>
                        <ul class="dropdown-menu" role="menu">
                            <li role="presentation" class="dropdown-header" style="background-color: #2E8B57; height: 45px;"><label class="label" style="color:#fff; font-size: 15px;">Admin</label></li>
                            <li class="divider"></li>
                            
                            <li class="divider"></li>
                            <li><a href="home.php"><span class="glyphicon glyphicon-log-out"></span>&emsp;Logout</a></li>
                            <li class="divider"></li>
                            <li class="divider"></li>
                            <li><a href="adminhome.php"><span class="glyphicon glyphicon-dashboard" style="color: red;"></span>&emsp;Admin Dash Board</a></li>
                        </ul>
                    </li>
                </ul>
            </div> 
        </div>
    </nav>
</div>
     

<!--*********************END OF HEADER NAVIGATION**********************************************-->
<!--%%%%%%%%% LOGIN FORM %%%%%%%%%%%%%%%%%%-->
<div class="container" style="margin-top: 130px; margin-bottom: 50px;">
    <div class="row">
    <div class=" col-sm-12 col-lg-12">
            <div class="login-panel panel panel-default" style="box-shadow: 2px 2px 8px 2px #000;">
            <div class="well" style="background-color: #2E8B57; color: #fff; font-size: 35px;">Record of approved applicants<span class="glyphicon glyphicon-user pull-right"></span></div>
                <div class="panel-body">
                        <?php
require "projectconnection.php";
            if(isset($_GET['id'])) {
    $id2deleted =$_GET['id'];
    echo $id2deleted;
    $diquery =mysql_query("DELETE FROM  biodata WHERE id='$id2deleted'");
}
?>     
                    <div class="row">
                        <div class="col-sm-12 col-lg-12">
                            <div class="table-responsive">
                                <table border="1" class="table table-hover table-striped ">
                                    <tr>
                                        <th>s/n</th>
                                        <th>NAME</th>
                                        <th>dob</th>
                                        <th>ward</th>
                                        <th>phne No.</th>
                                        <th> tribe</th>
                                        <th>applying date</th>
                                        <th>Date of approve</th>
                                    </tr>
                                    <?php
                                            $result = mysql_query("SELECT * FROM biodata2 WHERE approve ='1'");
                                            $numrows = mysql_num_rows($result);
                                            for ($i=0; $i < $numrows; $i++) { 
                                               $fname = strtoupper(mysql_result($result,$i, 'fname'));
                                               $mname = strtoupper(mysql_result($result,$i, 'mname'));
                                               $lname = strtoupper(mysql_result($result,$i, 'lname'));
                                               $dob = strtoupper(mysql_result($result,$i, 'dob'));
                                               $ward = strtoupper(mysql_result($result,$i, 'ward'));
                                               $phone = strtoupper(mysql_result($result,$i, 'phoneNo'));
                                               $tribe = strtoupper(mysql_result($result,$i, 'tribe'));
                                               $date = strtoupper(mysql_result($result,$i, 'comdate'));
                                               $adate=strtoupper(mysql_result($result,$i, 'approveDate'));
                                               $id =strtoupper(mysql_result($result,$i, 'id'));
                                       echo "<tr>
                                    <td> $id </td>
                                    <td>$fname&emsp;$mname&emsp;$lname</td>
                                    <td>$dob</td>
                                    <td>$ward</td>
                                    <td>$phone</td>
                                    <td>$tribe</td>
                                    <td>$date</td>
                                    <td> $adate</td>
                    
                                    
                                </tr>";
                                    }

                                        
                                    ?>
                                </table>
                            </div>
                        </div>
                        <a href="adminhome.php" class="btn btn-default" role ="button" style="margin-left: 800px; background-color: #2E8B57; color: #fff;">back</a>
                        
                    </div>
                </div>
            </div>
        </div>

        
<!--%%%%%%%%% END LOGIN FORM %%%%%%%%%%%%%%%%%%-->

<!--%%%%%%%%% END LOGIN FORM %%%%%%%%%%%%%%%%%%-->


<!-- ******begining of the footer****************-->
   <div class="footer" style="margin-top:45px; background-color: #2E8B57;opacity: 0.9;">
    <div class ="navbar navbar-inverse  navbar-fixed-bottom" style="height: 50px; background-color: #2E8B57; border-top: 2px solid yellow;">
        <div class="navbar navbar-brand"> 
        <p> <marquee direction="left" style="color: yellow;">Welcome to Gombe local Government indigene online application. Copyright &#169; 2018 | <a href="http://Gombe.gme.ng/" target="_blank" style="color: yellow" >Gombe.gme.ng</a> | All rights reserved. powered by Briatek Computer Institute. Welcome to Gombe local Government indigene online application. Copyright &#169; 2018 | <a href="http://Gombe.gme.ng/" target="_blank" style="color: yellow" >Gombe.gme.ng</a> | All rights reserved. powered by Briatek Computer Institute.</marquee><b><a href = "#Top" class="bb" style="float: right;margin-top: 40px;">back to top</a></b><p>
       

             
    </div>
 </div>
 </div>
 
 
 <!-- ************* End of the footer ****************-->


<!---scripft -->
 <!-- jQuery -->
    
     <script src="js/jquery.min.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    

<script>
    $(function(){
        $('.nav-tabs a:first').tab('show');
    });
</script>
<script>
$(document).ready(function(){
    $('[data-toggle="popover"]').popover(); 
});
</script>
</body>
</html>