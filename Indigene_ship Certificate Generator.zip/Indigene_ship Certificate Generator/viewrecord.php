<?php
    session_start();
    ob_start();
    require 'projectconnection.php';
     $id = $_GET['id'];
    
?>

<!DOCTYPE html>
<html>
<head>
    <title>npc.com.ng</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <!--linking boostrap-->
    <link type="text/css" rel="stylesheet" href="css/bootstrap.min.css" />
    
    <!--- I copied from getboostrap.com-->
    <link rel="stylesheet" type="text/css" href="css/font-awesome.css">
    <link rel="stylesheet" type="text/css" href="css/npcprj.css">

    <link rel="icon" href="img/logomautech.png">
    <!-- Latest compiled and minified CSS -->
    
</head>
<body style="background-image: url(img/bgg.jpg);background-size: cover;background-attachment: fixed;">
<!--*********************HEADER NAVIGATION**********************************************-->
        <div class="navbar navbar-default navbar-fixed-top" style="background-color: #920;">
            <div class="navbar-header">
                <div class="navbar-brand">
                <img src="img/logomautech.png" width="6%" style="float: left;margin-top: -10px;">
                    <a href="home.php" style="color: #fff;">Modibbo Adama University of Technology</a>
                </div>
            </div>
            
        </div>
<nav class="navbar navbar-default navbar-static-top" role="navigation" style="background-color:#fff; margin-top: 50px;">
        <div class="container-fluid">
            <!--Brand and toggle get grouped-->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" 
                data-target="#col">
                    <span class="sr-only">toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    
                </button>
                <a href="#" class="navbar-brand">
                <img src="img/logo.png" width="53%" class="img image"/></a>
            </div>
            <!--collect the nav links, forms and other content for toggle-->
            <div class="collapse navbar-collapse" id="col">
                <ul class="nav navbar-nav">
                   
                    <li><a href="contact.php"><span class="glyphicon glyphicon-glass">
                    </span> Contact Us</a></li>
                    <li><a href="gallery.php"><span class="glyphicon glyphicon-picture">
                    </span> Gallery</a></li>
                    <li><a href="biodata.php"><i class="fa fa-edit fa-fw"></i> Manage Record</a></li>
                            <li class="divider"></li>
                            <li><a href="adminsite.php"><i class="fa fa-picture-o fa-fw"></i> View Student Record</a></li>
                            <li class="divider"></li>
                            <li><a href="course.php" class="active"><i class="fa fa-edit fa-fw"></i> Approve Courses</a></li>
                            <li class="divider"></li>
                            <li><a href="first.php"><i class="fa fa-files-o"></i> Print and Export Record</a></li>
                            <li class="divider"></li>
                            <li><a href="second.php"><i class="fa fa-files-o"></i> Send Text</a></li>
                            
                        
                            
                            <li class="divider"></li>
                            <li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span>&emsp;Logout</a></li>
                            <li class="divider"></li>
                            <li><a href="profile.php"><span class="glyphicon glyphicon-user"></span>&emsp;Profile</a></li>
                            <li class="divider"></li>
                            <li><a href="adminhome.php"><span class="glyphicon glyphicon-dashboard" style="color: red;"></span>&emsp;Dash Board</a></li>
                    
                    

                </ul>
                
                
            </div> 
        </div>
    </nav>

<!--*********************END OF HEADER NAVIGATION**********************************************-->

<div class="container">
    <div class="row">
        <div class="col-lg-3">
            <div class="panel panel-default" style="margin-top:0px;box-shadow: 2px 2px 4px 2px #222;">
                <div class="panel-heading" style="background-color:#930;height: 3em">
                    <h3 class="panel-title" style="font-size: 15px; font-family:'Droid Serif';color: #fff;">PASSPORT
                     <span class="glyphicon glyphicon-cloud-upload" style="margin-top:-5px;font-size: 26px;float: right;"></span>
                            </h3>

                </div>
                <div class="panel-body">
            <?php
            $id = $_GET['id'];
                $checking = mysql_query("SELECT * FROM upload_image WHERE id = '$id'");
                if (mysql_num_rows($checking)==1) {
                    for ($i=0; $i < mysql_num_rows($checking); $i++) { 
                        $form_name = mysql_result($checking,$i, 'passport');
                        $primary_name = mysql_result($checking,$i, 'primary_c');
                        $birth_name = mysql_result($checking,$i, 'birth_c');
                        echo "<form role='form' method='post' enctype='multipart/form-data'>
                
                    <div class='row'>
                           <!--passport-->
                    <div class='col-md-4'>
                        <div class='passport'>
                            <img style='height:230px; width:160px; box-shadow:0px 0px 1px 0px black;' name='image' id='image' src =images/$form_name />

                                </div><br>
                               
                                <div class='form-group input-group'>
                                <div class='upload'>
                                <input type='file'  name='img' id='passport' value=' onChange='onFileSelected(event)' disabled></div>
                                </div>
                           </div>
        
                    </div>

                    div class='col-md-4'>
                        <div class='passport'>
                            <img style='height:230px; width:160px; box-shadow:0px 0px 1px 0px black;' name='image' id='image' src = images/$primary_name/>

                                </div><br>
                               
                                <div class='form-group input-group'>
                                <div class='upload'>
                                <input type='file'  name='img' id='passport' value=' onChange='onFileSelected(event)' disabled></div>
                                </div>
                           </div>
        
                    </div>

                    div class='col-md-4'>
                        <div class='passport'>
                            <img style='height:230px; width:160px; box-shadow:0px 0px 1px 0px black;' name='image' id='image' src = images/$birth_name />

                                </div><br>
                               
                                <div class='form-group input-group'>
                                <div class='upload'>
                                <input type='file'  name='img' id='passport' value=' onChange='onFileSelected(event)' disabled></div>
                                </div>
                           </div>
        
                    </div>
                </div>
                </form>
                ";
                    }
                    
                }

                ?>
                </div>
            </div>
       </div>

    <div class="col-lg-8">
        <?php
        $id = $_GET['id'];
     $displaybiodata = mysql_query("SELECT * FROM biodata WHERE id ='$id'");
    if (mysql_num_rows($displaybiodata)==1) {
        for ($i=0; $i < mysql_num_rows($displaybiodata); $i++) { 
                            $id =strtoupper(mysql_result($result,$i, 'id'));
                             $fname = strtoupper(mysql_result($result,$i, 'fname'));
                               $mname = strtoupper(mysql_result($result,$i, 'mname'));
                               $lname = strtoupper(mysql_result($result,$i, 'lname'));
                               $dob = strtoupper(mysql_result($result,$i, 'dob'));
                               $gender = strtoupper(mysql_result($result,$i, 'gender'));
                               $mstatus = strtoupper(mysql_result($result,$i, 'mstatus'));
                               $ward = strtoupper(mysql_result($result,$i, 'ward'));
                               $phone = strtoupper(mysql_result($result,$i, 'phone'));
                               $tribe = strtoupper(mysql_result($result,$i, 'tribe'));
                               $nationality = strtoupper(mysql_result($result,$i, 'nationality'));
                               $state = strtoupper(mysql_result($result,$i, 'state'));
                               $lga = strtoupper(mysql_result($result,$i, 'lga'));
                               $caddress = strtoupper(mysql_result($result,$i, 'caddress'));
                               $Passport=strtoupper(mysql_result($result,$i, 'files'));

            echo "
            <div class='login-panel panel panel-default' style='margin-top: 0px;box-shadow: 2px 2px 4px 2px #222;'>
                <div class='panel-heading' style='background-color:#930;height: 3em'>
                    <h3 class='panel-title' style='font-size: 15px; font-family: 'Droid Serif';'>PERSONAL DATA 
                    <span class='glyphicon glyphicon-user' style='float: right;margin:0px 10px;font-size: 36px;'>
                    </span></h3>
                </div>
        <div class='panel-body'>
            <form role='form' method='post'>
                
                    <div class='row'>
                        <div class='col-md-4'>
                            <label class='label' style='color:#333;font-size: 15px; '>Registration No:
                            
                            </label>
                            <div class='form-group input-group'>
                                   <span class='input-group-addon'><span class='glyphicon glyphicon-random' style='color: #930;'></span></span>
                                   <input type='text' class='form-control' value='$id' readonly>
                                </div>
                            </div>
                        <div class='col-md-4'>
                            <label class='label' style='color:#333;font-size: 15px; '>Form No:
                            
                            </label>
                            <div class='form-group input-group'>
                                   <span class='input-group-addon'><span class='glyphicon glyphicon-random' style='color: #930;'></span></span>
                                   <input type='text' class='form-control' value='$fname' readonly>
                                </div>
                               
                        </div>

                        </div>


        
                        <div class='row'><!--nested row in row1-->
                            
                            <div class='col-md-4'>
                                 <label class='label' style='color:#333;font-size: 15px; '>First Name:</label>
                                <div class='form-group input-group'>
                                   <span class='input-group-addon'><span class='glyphicon glyphicon-user' style='color: #930;'></span></span>
                                   <input type='text' class='form-control' value ='$mname' readonly>
                                </div>
                            </div>
                            <div class='col-md-4'>
                             <label class='label' style='color:#333;font-size: 15px; '>Last Name:</label>
                                <div class='form-group input-group'>
                                   <span class='input-group-addon'><span class='glyphicon glyphicon-user' style='color: #930;'></span></span>
                                   <input type='text' class='form-control' value ='$lname' readonly>
                                </div>
                            </div>
                            
                                <div class='col-md-4'>
                                 <label class='label' style='color:#333;font-size: 15px; '>dob:</label>

                                <div class='form-group input-group'>
                                   <span class='input-group-addon'><span class='glyphicon glyphicon-user' style='color: #930;'></span></span>
                                   <input type='text' class='form-control' value = ' $dob' readonly>
                                </div>
                            </div>
                            </div>
                        <div class='row'>
                            <div class='col-md-4'>
                             <label class='label' style='color:#333;font-size: 15px; '>gender:</label>
                                 <div class='form-group input-group'>
                                   <span class='input-group-addon'><span class='fa fa-gittip' style='color: #930;'></span></span>
                                   <input type='text' class='form-control' value = '$gender' readonly>
                                </div>
                            </div>
                            
                               <div class='col-md-4'>
                             <label class='label' style='color:#333;font-size: 15px; '>marital status:</label>
                                <div class='form-group input-group'>
                                   <span class='input-group-addon'><span class='fa fa-male' style='color: #930;'></span></span>
                                   <input type='text' class='form-control' value = '$mstatus' readonly>
                                </div>
                            </div>
                            <div class='col-md-4'>
                            <label class='label' style='color:#333;font-size: 15px;'>ward:</label>
                                <div class='form-group input-group'>
                                   <span class='input-group-addon'><span class='glyphicon glyphicon-calendar' style='color: #930;'></span></span>
                                   <input type='date' class='form-control' value = '$ward' readonly>
                                </div>
                            </div>
                        </div>
                            <div class='row'>
                                <div class='col-md-4'>
                             <label class='label' style='color:#333;font-size: 15px; '>phone no:</label>
                                <div class='form-group input-group'>
                                   <span class='input-group-addon'><span class='fa fa-gittip' style='color: #930;'></span></span>
                                   <input type='text' class='form-control' value = '$phone' readonly>
                                </div>
                            </div>
                            <div class='col-md-4'>
                            <label class='label' style='color:#333;font-size: 15px; '> tribe:</label>
                                <div class='form-group input-group'>
                                   <span class='input-group-addon'><span class='glyphicon glyphicon-phone' style='color: #930;'></span></span>
                                   <input type='text' class='form-control' value = '$tribe' readonly>
                                </div>
                            </div>
                            <div class='col-md-4'>
                            <label class='label' style='color:#333;font-size: 15px; '>nationality:</label>
                                <div class='form-group input-group'>
                                   <span class='input-group-addon'><span  style='color: #930;'>@</span></span>
                                <input type='text' class='form-control' value = '$nationality' readonly>
                                </div>
                            </div>
                            </div>

                            <div class='row'>
                                <div class='col-md-4'>
                             <label class='label' style='color:#333;font-size: 15px; '>state:</label>
                                <div class='form-group input-group'>
                                   <span class='input-group-addon'><span class='fa fa-th' style='color: #930;'></span></span>
                                   <input type='text' class='form-control' value = '$state' readonly>
                                </div>
                            </div>
                            <div class='col-md-4'>
                             <label class='label' style='color:#333;font-size: 15px; '>lga:</label>
                                <div class='form-group input-group'>
                                   <span class='input-group-addon'><span class='fa fa-bank' style='color: #930;'></span></span>
                                   <input type='text' class='form-control' value = '$lga' readonly>
                                </div>
                            </div>
                            <div class='col-md-4'>
                             <label class='label' style='color:#333;font-size: 15px; '>caddress:</label>
                                <div class='form-group input-group'>
                                   <span class='input-group-addon'><span class='fa fa-bank' style='color: #930;'></span></span>
                                   <input type='text' class='form-control' value = '$caddress' readonly>
                                </div>
                            </div>
                            </div>
                            <div class='row'>
                                <div class='col-md-8'>
                                <label class='label' style='color:#333;font-size: 15px; '>Passport:</label>
                                <div class='form-group input-group'>
                                   <span class='input-group-addon'><span class='fa fa-road' style='color: #930;'></span></span>
                                   <textarea cols = '70' rows = '4' class = 'form-control' readonly> $Passport</textarea>
                                </div>
                            </div> 
                ";
           
        }
    }
    ?>
    </div>
</div>

<script>
	$(function(){
		$('.nav-tabs a:first').tab('show');
	});
</script>
    <!-- jQuery -->
    <script src="js/jquery.min.js"></script>

    <!-- Bootstrap 33 JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="js/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="js/sb-admin-2.js"></script>

</body>

</html>
