<?php
require "projectconnection.php";
$date1 =date('d-m-y h:i:s');

?>
<!DOCTYPE html>
<html>
<head>
	<title>Admin site</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="=device-, initial-scale=1.0">
  <link rel="icon" type="text/image" href="img/a1.jpeg"> 
	<!--linking boostrap-->
	<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css">
	<!--linking custom CSS-->
  <link rel="stylesheet" type="text/css" href="css/font-awesome.css">
	<link rel="stylesheet" type="text/css" href="css/mystyle.css">




   <style>
      
.facebook:before{
    content:'\f09a';
  width:15px;
    color: #fff;
    font-family: 'fontawesome';
    font-size: 25px;
  text-decoration:none;
}
.twitter:before{
    content:'\f099';
    color: #fff;
    font-family: 'fontawesome';
    font-size: 25px;
}
.rss:before{
    content:'\f09e';
    color: #fff;
    font-family: 'fontawesome';
  font-size: 25px;
  
}
.google:before{
    content:'\f0d5';
    color: #fff;
    font-family: 'fontawesome';
  font-size: 25px;
} 
    </style>
</head>
<body id="page" style="background-image: url(images/80.png);background-size: cover;background-attachment: fixed;">
<!--header-->
<div class ="navbar navbar-default  navbar-fixed-top" style=" background-color:#2E8B57; height: 60px; border-bottom: 2px solid; color: yellow;">
    <div class="navbar navbar-brand">
        <a <href="index.html"><img src="img/a1.jpeg" width="65%" height="65%"   style="margin-top: -15px;float: left;" class="img-responsive img-circle"></a>
    </div>
    <p class="txtlogo" style="color:#fff; margin-top:25px; margin-left: -190px; font-size: 20px;">GOMBE LOCAL GOVERNMENT
      <div style="float: right; margin-top: -40px; margin-right: 10px; padding: 0px 10px 0px 10px;">
        <a href="www.facebook.com" title="www.facebook.com/gme.lga" ><span class="facebook"></span></a> 
        <a href="www.twitter.com" title="www.twitter.com/@gme.lga"><span class="twitter"></span></a> 
        <a href="www.rss.com" title="www.rss.com/gme.lga"><span class="rss"></span></a> 
        <a href="www.google.com" title="www.googleplus.com/gme.lga"><span class="google"></span></a> 
      </div>
    
    
    </p>
 
    </div>
<nav class="navbar navbar-default navbar-fixed-top" role="navigation" style="background-color:#fff;margin-top: 60px; border-bottom: 2px solid; color: yellow;">
        <div class="container-fluid">
            <!--Brand and toggle get grouped-->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" 
                data-target="#col">
                    <span class="sr-only">toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                
                
            </div>
            <!--collect the nav links, forms and other content for toggle-->
            <div class="collapse navbar-collapse" id="col">
                <ul class="nav navbar-nav">
                    <li><a href="home.php">
                    <span class="glyphicon glyphicon-home"></span> Home
                    <span class="sr-only">(Current)</span></a></li>
                    <li><a href="coment.php"><span class="glyphicon glyphicon-glass">
                    </span> Comments</a></li>
                    <li class="dropdown" >
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                    <span class="glyphicon glyphicon-user">
                    </span> Admin<span class="caret"></span></a>
                        <ul class="dropdown-menu" role="menu">
                            <<li><a href="#">Manage Record</a></li>
                            <li class="divider"></li>
                            <li><a href="view.php">View applicants's Record </a></li>
                            <li class="divider"></li>
                            <li><a href="approve.php">Approve </a></li>
                            <li class="divider"></li>
                            <li class="divider"></li>
                        </ul>
                    </li>
                </ul>
    
                <ul class="nav navbar-nav" style="margin-left: 0px;">
                    
                    <li class="dropdown active">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                    <span class="glyphicon glyphicon-user" style="height: 15px;"></span>&emsp;
                    WELCOME ADMIN!
                    <span class="caret"></span>
                        <ul class="dropdown-menu" role="menu">
                            <li role="presentation" class="dropdown-header" style="background-color: #2E8B57; height: 45px;"><label class="label" style="color:#fff; font-size: 15px;">Admin</label></li>
                            <li class="divider"></li>
                            <li><a href="adminhome.php"><i class="fa fa-home fa-fw"></i> Home</a></li>
                            <li class="divider"></li>
                            <li><a href="biodata.php"><i class="fa fa-edit fa-fw"></i> Manage Record</a></li>
                            <li class="divider"></li>
                            <li><a href="view.php"><i class="fa fa-picture-o fa-fw"></i> View applicants Record</a></li>
                            <li class="divider"></li>
                            <li><a href="#" class="active"><i class="fa fa-edit fa-fw"></i> Approve applicants </a></li>
                            <li class="divider"></li>
                            <li class="divider"></li>
                            <li><a href="home.php"><span class="glyphicon glyphicon-log-out"></span>&emsp;Logout</a></li>
                            <li class="divider"></li>
                            <li class="divider"></li>
                            <li><a href="adminhome.php"><span class="glyphicon glyphicon-dashboard" style="color: red;"></span>&emsp;Dash Board</a></li>
                        </ul>
                    </li>
                </ul>
            </div> 
        </div>
    </nav>


 <div class="container" style="margin-top: 128px; ">
 <!--*******first row**********-->
   <div class="row">
     <div class="col-sm-1 col-lg-1"></div>
     <div class="col-sm-3 col-lg-3">
       <div class="panel panel-default">
         <div class="panel-heading"style ="background-color:#2E8B57; height:50px">
           <h4 class="panl-title" style ="color:#fff; margin-top: -0px; font-weight: 600;
           font-size: 12px;">Approve Applicants</h4>
         </div>
         <div class="panel-body"style="background-color:#3cb371;">
           <span class="glyphicon glyphicon-check" style="margin-left:30px;color:#fff;font-size: 40px;"> </span><br>
           <a href="approve.php" style ="margin-left:20px;font-size: 14px;color: #fff;">click here</a>
         </div>
       </div>
     </div>

     <div class="col-sm-3 col-lg-3">
       <div class="panel panel-default">
         <div class="panel-heading"style ="background-color:#2E8B57; height:40px">
           <h4 class="panl-title" style ="color:#fff; margin-top: -0px;font-size: 12px; font-weight: 600;">List of approved Applicants</h4>
         </div>
         <div class="panel-body"style="background-color:#3cb371;">
           <span class="glyphicon glyphicon-list" style="margin-left:30px;color:#fff;font-size: 40px;"></span>
           <br>
           <a href="view.php" style ="margin-left:20px;font-size: 14px;color: #fff;">click here</a>
         </div>
       </div>
     </div>
     <div class="col-sm-3 col-lg-3">
       <div class="panel panel-default">
         <div class="panel-heading" style ="background-color:#2E8B57; height:40px">
           <h4 class="panl-title" style ="color:#fff; margin-top: -0px;font-size: 12px; font-weight: 600;">View applicants record</h4>
         </div>
         <div class="panel-body"style="background-color:#3cb371;">
           <span class="glyphicon glyphicon-envelope" style="margin-left:30px;color:#fff;font-size: 40px;"></span>
           <br>
           <a href="recodviw.php" style ="margin-left:20px;font-size: 14px;color: #fff;">click here</a>
         </div>
       </div>
     </div>
     <div class="col-sm-1 col-lg-1"></div>
   </div>
<!--*******second row**********-->
   <div class="row">
     <div class="col-sm-1 col-lg-1"></div>
     <div class="col-sm-3 col-lg-3">
       <div class="panel panel-default">
         <div class="panel-heading"style ="background-color:#2E8B57; height:50px">
           <h4 class="panl-title" style ="color:#fff; margin-top: -0px;font-size: 12px; font-weight: 600;">Manage Record</h4>
         </div>
         <div class="panel-body"style="background-color:#3cb371;">
           <span class="glyphicon glyphicon-wrench" style="margin-left:30px;color:#fff;font-size: 40px;"> </span><br>
           <a href="manageRecord.php" style ="margin-left:20px;font-size: 14px;color: #fff;">click here</a>
         </div>
       </div>
     </div>

     <div class="col-sm-3 col-lg-3">
       <div class="panel panel-default">
         <div class="panel-heading"style ="background-color:#2E8B57; height:40px">
           <h4 class="panl-title" style ="font-size:15px;color:#fff; margin-top: -0px;font-size: 12px; font-weight: 600;">Search Applicant's record</h4>
         </div>
         <div class="panel-body"style="background-color:#3cb371;">
           <span class="glyphicon glyphicon-search" style="margin-left:30px;color:#fff;font-size: 40px;"></span>
           <br>
           <a href="search.php" style ="margin-left:20px;font-size: 14px;color: #fff;">click here</a>
         </div>
       </div>
     </div>
     <div class="col-sm-3 col-lg-3">
       <div class="panel panel-default">
         <div class="panel-heading"style ="background-color:#2E8B57; height:40px">
           <h4 class="panl-title" style ="color:#fff; margin-top: -0px;font-size: 12px;">View applicant's complains</h4>
         </div>
         <div class="panel-body"style="background-color:#3cb371;">
           <span class="glyphicon glyphicon-comment" style="margin-left:30px;color:#fff;font-size: 40px;"></span>
           <br>
           <a href="coment.php" style ="margin-left:20px;font-size: 14px;color: #fff;">click here</a>
         </div>
       </div>
     </div>
     <div class="col-sm-1 col-lg-1"></div>
   </div>
 </div>

  <!-- ******begining of the footer****************-->
   <div class="footer" style="margin-top:45px; background-color: #2E8B57;opacity: 0.9;">
    <div class ="navbar navbar-inverse  navbar-fixed-bottom" style="height: 50px; background-color: #2E8B57; border-top: 2px solid yellow;">
        <div class="navbar navbar-brand"> 
        <p> <marquee direction="left" style="color: yellow;">Welcome to Gombe local Government indigene online application. Copyright &#169; 2018 | <a href="http://Gombe.gme.ng/" target="_blank" style="color: yellow" >Gombe.gme.ng</a> | All rights reserved. powered by Briatek Computer Institute. Welcome to Gombe local Government indigene online application. Copyright &#169; 2018 | <a href="http://Gombe.gme.ng/" target="_blank" style="color: yellow" >Gombe.gme.ng</a> | All rights reserved. powered by Briatek Computer Institute.</marquee><b><a href = "#Top" class="bb" style="float: right;margin-top: 40px;">back to top</a></b><p>
       

             
    </div>
 </div>
 </div>
 
 
 <!-- ************* End of the footer ****************-->

 <!---scripft -->
 <!-- jQuery -->
    
     <script src="js/jquery.min.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    

<script>
    $(function(){
        $('.nav-tabs a:first').tab('show');
    });
</script>
<script>
$(document).ready(function(){
    $('[data-toggle="popover"]').popover(); 
});
</script>
</body>
</html>