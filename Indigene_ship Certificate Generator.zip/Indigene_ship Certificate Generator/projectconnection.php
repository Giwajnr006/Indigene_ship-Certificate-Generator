<?php

$hostname = "localhost";
$hostuser = "root";
$hostpass = "";
$hostdb = "myproject";

// Create connection
$connection = mysqli_connect($hostname, $hostuser, $hostpass, $hostdb);

// Check connection
if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
} else {
    echo "Connected successfully!";
}
?>
