<?php
session_start();
ob_start();
require "projectconnection.php";
$date1 =date('d-m-y h:i:s');
 //if login button is press
if(isset($_POST['sumit'])){
  $user = mysql_real_escape_string($_POST['user']);
  $pass = mysql_real_escape_string($_POST['psw']);

/****making query***/
    if ($user== "admin" && $pass =="admin") {
       header("location:adminhome.php");
    }
    else{
      //Selecting from create_acount to check if record exist
      $qr ="SELECT * FROM sign_up WHERE uname ='$user' AND Password ='$pass'";
      $result =mysql_query($qr);
      $info = mysql_fetch_array($result);
      $rows =mysql_num_rows($result);
      //if its exist******
      if($rows ==1){
        header("location:mydashboard.php");
        $_SESSION['serial_no'] = $info['sn'];
      }
      else{
        $messg = "<div class='alert alert-danger' style='font-size:12px;border:1px solid red;color:red;'>Incorrect <b>Username or Password</b> !!!&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class='glyphicon glyphicon-alert' style='font-size:20px; margin-top:0px;'></span></div>";
      }
    }

}
?>
<!DOCTYPE html>
<html>
<head>
	<title>login page</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="=device-, initial-scale=1.0"> 
  <link rel="icon" type="text/image" href="img/a1.jpeg"> 
	<!--linking boostrap-->
	<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css">
	<!--linking custom CSS-->
  <link rel="stylesheet" type="text/css" href="css/font-awesome.css">
	<link rel="stylesheet" type="text/css" href="css/mystyle.css">
	<!--linking JS for boostrap-->
  <link rel="shortcut icon" href="../favicon.ico"> 
        
	<script type="text/javascript" src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js" type="text/javascript"></script>
<!-- background slider link
<link rel="stylesheet" type="text/css" href="css/style1.css" />
    <script type="text/javascript" src="js/modernizr.custom.86080.js"></script>
    -->



 <style>
      
.facebook:before{
    content:'\f09a';
  width:15px;
    color: #fff;
    font-family: 'fontawesome';
    font-size: 25px;
  text-decoration:none;
}
.twitter:before{
    content:'\f099';
    color: #fff;
    font-family: 'fontawesome';
    font-size: 25px;
}
.rss:before{
    content:'\f09e';
    color: #fff;
    font-family: 'fontawesome';
  font-size: 25px;
  
}
.google:before{
    content:'\f0d5';
    color: #fff;
    font-family: 'fontawesome';
  font-size: 25px;
} 
    </style>
<style>
  .carousel-inner > .item > img,
  .carousel-inner > .item > a > img {
   width: 80   height: 110%;
      margin: auto;
  }
  </style>
    <!--slider-->
    <link rel="stylesheet" type="text/css" href="css/custom-slider.css"/>
    <script type="text/javascript" src="js/jquery-1.11.1.js"></script>
    <script type="text/javascript" src="js/jquery.custom-slider.js"></script>
    <script>
        $(document).ready(function(){
            $(".slider").customslider({ height:"px", : "%", speed:700 })
        });
    </script>
</head>
<body id="page" style="background-image: url(images/80.png);background-size: cover;background-attachment: fixed;">
       <!-- <ul class="cb-slideshow">
            <li><span>Image 01</span></li>
            <li><span>Image 02</span></li>
            <li><span>Image 03</span></li>
            <li><span>Image 04</span></li>
            <li><span>Image 05</span></li>
            <li><span>Image 06</span></li>
        </ul>
        
        <div class="container">

            <div class="codrops-top">
              
                <div class="clr"></div>
            </div>
           
        </div>
        -->
<!--header-->
<div class ="navbar navbar-default  navbar-fixed-top" style=" background-color:#2E8B57; height: 60px; border-bottom: 2px solid; color: yellow;">
    <div class="navbar navbar-brand">
        <a <href="index.html"><img src="img/a1.jpeg" width="65%" height="65%"   style="margin-top: -15px;float: left;" class="img-responsive img-circle"></a>
    </div>
    <p class="txtlogo" style="color:#fff; margin-top:25px; margin-left: -190px; font-size: 20px;">GOMBE INDIGENE APPLICATION
      <div style="float: right; margin-top: -40px; margin-right: 10px; padding: 0px 10px 0px 10px;">
        <a href="www.facebook.com" title="www.facebook.com/gme.lga" ><span class="facebook"></span></a> 
        <a href="www.twitter.com" title="www.twitter.com/@gme.lga"><span class="twitter"></span></a> 
        <a href="www.rss.com" title="www.rss.com/gme.lga"><span class="rss"></span></a> 
        <a href="www.google.com" title="www.googleplus.com/gme.lga"><span class="google"></span></a> 
      </div>
    
    
    </p>
 
    <nav class="navbar navbar-default navbar-static-top" role="navigation" style="background-color:#fff;margin-top: -3px; border-bottom: 2px solid; color: yellow;">
        <div class="container-fluid">
            <!--Brand and toggle get grouped-->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" 
                data-target="#col">
                    <span class="sr-only">toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                
                
            </div>
            <!--collect the nav links, forms and other content for toggle-->
            <div class="collapse navbar-collapse" id="col">
                <ul class="nav navbar-nav">
                    <li><a href="home.php" class="active">
                    <span class="glyphicon glyphicon-home"></span> Home
                    <span class="sr-only">(Current)</span></a></li>
                    <li><a href="contact.php"><span class="glyphicon glyphicon-glass">
                    </span> Contact us</a></li>
                    <li class="dropdown" >
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                    <span class="glyphicon glyphicon-user">
                    </span> Welcome<span class=""></span></a>
                        <ul class="dropdown-menu" role="menu">
                            <li><a href="home.php">logout</a></li>
                            <li class="divider"></li>
                            
                        </ul>

                    </li>
                    
                </ul>
                
            </div> 
        </div>
    </nav>
</div>
<div class="container"style="margin-top:50px;">
   <div class="row">
      <div class="col-sm-3 col-lg-3"></div>
        

<div class="col-sm-6 col-lg-6">
  <div class="panel panel-default" style="margin-top: 120px; margin-button:10px; box-shadow: 2px 2px 8px 4px #2E8B57;">
    <div class="panel-heading" style ="background-color:#2E8B57; font-size:25px; color:#fff; height: 50px;>
      <h4 class="panel-title" style ="color:#fff; font-size:30px;">Login <span  class="glyphicon glyphicon-lock" style= "color:#ffF;float:right;font-size:25px;"> </span></h4>
                 </div>
<div class="panel-body">
<?php
            if(isset( $messg)){
                echo  $messg;
            }
                                
        ?>
 <form role ="form" method="POST">
      <div class="form-group">
         <label for="username">Username:</label>
              <div class="form-group input-group">
                  <span class="input-group-addon">
                    <span class="glyphicon glyphicon-user"></span>
                        </span>
                              <input type="text"class="form-control" name="user" placeholder="Enter Username">
                           </div>
                       </div> 

   <div class="form-group">
     <label for="username">Password:</label>
     <div class="form-group input-group">
        <span class="input-group-addon">
         <span class="glyphicon glyphicon-lock"></span>
      </span>
      <input type="Password" name="psw" class="form-control"placeholder="Enter Password">
    </div>
  </div> 
 <div class="checkbox">
      <label><input type="checkbox"><p style="color:#2E8B57;"> Remember me</p></label>
  </div>
        <button type ="submit" name="sumit"class="btn btn-md btn-success" style="float: right; background-color:#2E8B57;"><span class="glyphicon glyphicon-log-in"></span>  Login</button>  
      <br><br>
</form>
</div>
</div>
</div> 
      <div class="col-sm-3 col-lg-3"></div>
</div>
</div>


    <!-- ******begining of the footer****************-->
   <div class="footer" style="margin-top:45px; background-color: #2E8B57;opacity: 0.9;">
    <div class ="navbar navbar-inverse  navbar-fixed-bottom" style="height: 50px; background-color: #2E8B57; border-top: 2px solid yellow;">
        <div class="navbar navbar-brand"> 
        <p> <marquee direction="left" style="color: yellow;">Welcome to Gombe local Government indigene online application. Copyright &#169; 2018 | <a href="http://Gombe.gme.ng/" target="_blank" style="color: yellow" >Gombe.gme.ng</a> | All rights reserved. powered by Briatek Computer Institute. Welcome to Gombe local Government indigene online application. Copyright &#169; 2018 | <a href="http://Gombe.gme.ng/" target="_blank" style="color: yellow" >Gombe.gme.ng</a> | All rights reserved. powered by Briatek Computer Institute.</marquee><b><a href = "#Top" class="bb" style="float: right;margin-top: 40px;">back to top</a></b><p>
             
    </div>
 </div>
 </div>
 <!-- ************* End of the footer ****************-->
</body>
</html>