<?php
require "connection.php";
$date1 =date('d-m-y h:i:s');
?>
<!DOCTYPE html>
<html>
<head>
	<title>home page</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="=device-, initial-scale=1.0"> 
  <link rel="icon" type="text/image" href="img/a1.jpeg">
	<!--linking boostrap-->
	<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css">
	<!--linking custom CSS-->
  <link rel="stylesheet" type="text/css" href="css/font-awesome.css">
	<link rel="stylesheet" type="text/css" href="css/mystyle.css">
	<!--linking JS for boostrap--> 

  <script type="text/javascript" src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js" type="text/javascript"></script>
<!-- background slider link
<link rel="stylesheet" type="text/css" href="css/style1.css" />
    <script type="text/javascript" src="js/modernizr.custom.86080.js"></script>
    -->

<!--Begening of social icons-->
    <style>
      
.facebook:before{
    content:'\f09a';
  width:15px;
    color: #fff;
    font-family: 'fontawesome';
    font-size: 25px;
  text-decoration:none;
}
.twitter:before{
    content:'\f099';
    color: #fff;
    font-family: 'fontawesome';
    font-size: 25px;
}
.rss:before{
    content:'\f09e';
    color: #fff;
    font-family: 'fontawesome';
  font-size: 25px;
  
}
.google:before{
    content:'\f0d5';
    color: #fff;
    font-family: 'fontawesome';
  font-size: 25px;
} 
    </style>

    <!--End of social icons-->
<style>
  .carousel-inner > .item > img,
  .carousel-inner > .item > a > img {
   width: 80   height: 110%;
      margin: auto;
  }

  </style>
    <!--slider-->
    <link rel="stylesheet" type="text/css" href="css/custom-slider.css"/>
    <script type="text/javascript" src="js/jquery-1.11.1.js"></script>
    <script type="text/javascript" src="js/jquery.custom-slider.js"></script>
    <script>
        $(document).ready(function(){
            $(".slider").customslider({ height:"px", : "%", speed:700 })
        });
    </script>
</head>
<body id="page" style="background-image: url(images/80.png);background-size: cover;background-attachment: fixed;">
       <!-- <ul class="cb-slideshow">
            <li><span>Image 01</span></li>
            <li><span>Image 02</span></li>
            <li><span>Image 03</span></li>
            <li><span>Image 04</span></li>
            <li><span>Image 05</span></li>
            <li><span>Image 06</span></li>
        </ul>
        
        <div class="container">

            <div class="codrops-top">
              
                <div class="clr"></div>
            </div>
           
        </div>
        -->
<!--header-->
<div class ="navbar navbar-default  navbar-fixed-top" style=" background-color:#2E8B57; height: 60px; border-bottom: 2px solid; color: yellow;">
    <div class="navbar navbar-brand">
        <a <href="index.html"><img src="img/a1.jpeg" width="65%" height="65%"   style="margin-top: -15px;float: left;" class="img-responsive img-circle"></a>
    </div>
    <p class="txtlogo" style="color:#fff; margin-top:25px; margin-left: -190px; font-size: 20px;">GOMBE INDIGENE APPLICATION
      <div style="float: right; margin-top: -40px; margin-right: 10px; padding: 0px 10px 0px 10px;">
        <a href="www.facebook.com" title="www.facebook.com/gme.lga" ><span class="facebook"></span></a> 
        <a href="www.twitter.com" title="www.twitter.com/@gme.lga"><span class="twitter"></span></a> 
        <a href="www.rss.com" title="www.rss.com/gme.lga"><span class="rss"></span></a> 
        <a href="www.google.com" title="www.googleplus.com/gme.lga"><span class="google"></span></a> 
      </div>
    
    </p>
 </div>

    <nav class="navbar navbar-default navbar-static-top" role="navigation" style="background-color:#fff;margin-top: 55px; border-bottom: 2px solid; color: yellow;">
        <div class="container-fluid">
            <!--Brand and toggle get grouped-->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" 
                data-target="#col">
                    <span class="sr-only">toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                
                
            </div>
            <!--collect the nav links, forms and other content for toggle-->
            <div class="collapse navbar-collapse" id="col">
                <ul class="nav navbar-nav">
                    <li><a href="home.php" class="active">
                    <span class="glyphicon glyphicon-home"></span> Home
                    <span class="sr-only">(Current)</span></a></li>
                    <li><a href="contact.php"><span class="glyphicon glyphicon-glass">
                    </span> Contact us</a></li>
                    
                    <li> <a href="userLogin.php"> <span class="glyphicon glyphicon-user"></span>  About</a></li>
                </ul>
                
            </div> 
        </div>
    </nav>

<div class="container" style="margin-top: 50px; background-color: ">
   <div class="row">
      <div class="col-sm-8 col-lg-8 col-xs-8">
        <div class="panel panel-default">
          
         <div>

 
  <div id ="myCarousel" class="carousel slide" data-ride="carousel">
       <!-- Indicators -->
       <ol class="carousel-indicators">
        <li class="item1 active"></li>
        <li class="item2"></li>
        <li class="item3"></li>
        <li class="item4"></li>
        <li class="item5"></li>
        <li class="item6"></li>
         <li class="item7"></li>
        
       </ol>

        <!-- Wrapper for slides -->
        <div class="carousel-inner" role ="listbox">
          <div class="item active">
            <img src="images/cc3.png"  alt=" image">
            <div class="carousel-caption">
              <h3>Gombe</h3>
              <p> Office of the chirman</p>
            </div>
          </div>

          
          <div class="item ">
            <img src="img/slider/3.jpg"   alt=" image">
            <div class="carousel-caption">
              <h3>Gombe</h3>
              <p>Gombe local government Gombe state</p>
            </div>
          </div>

          
          <div class="item ">
            <img src="img/slider/a4.png"  alt="image">
            <div class="carousel-caption">
              <h3>Gombe</h3>
              <p>Gombe local government Gombe state</p>
            </div>
          </div>

          <div class="item ">
            <img src="img/slider/a5.png"   alt="image">
            <div class="carousel-caption">
              <h3>Gombe</h3>
              <p>Gombe local government Gombe state</p>
            </div>
          </div>

          <div class="item ">
            <img src="images/bannner.jpg"   alt="image" style="height: justify;">
            <div class="carousel-caption">
              <h3>Gombe</h3>
              <p>Gombe Emir Palace</p>
            </div>
          </div>
        </div>

         <!-- Left and right controls 
         <a class="Left carousel-control" href="#myCarousel" role ="button" data-slide="prev"><span class="glyphicon glyphicon-chevron-left" aria-hidden ="true"></span><span class="sr-only">Previous</span></a>

         <a class="right carousel-control" href="#myCarousel" role ="button" data-slide="Next"><span class="glyphicon glyphicon-chevron-right" aria-hidden ="true"></span><span class="sr-only">Next</span></a>-->
      </div>
    </div>
  </div>
</div>
<div class="col-sm-4 col-lg-4 col-xs-4">
       <div class="panel panel-default">
          <div class="panel-heading" style ="background-color: #2E8B57; color:#fff;>
          <h4 class="panel-title" style ="color:#fff;font-size:20px;">Access your local Govertment <span  class="glyphicon glyphicon-user" style= "color:#ffF;float:right;font-size:20px;"> </span></h4>
                                 </div>
               <div class="panel-body">
                 

                 <div class="row">
                   <div class="col-sm-6 col-lg-6 col-xs-6">

                    <!-- trigger button to open the modal-->
      <a href="#myModal12" class="btn btn-info btn-md" data-toggle="modal" data-backdrop="false"><img src="images/icons/e.png" class="img-circle img-responsive" width="140px"height="90px"/><p style="margin-left: 30px">Sign Up</p></a>
      
      <!-- Modal -->
  <div class="modal fade" id="myModal12" role="dialog" style="margin: 70px 0px 0px 40px;">
    <div class="modal-dialog modal-sm">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header" style="background-color:#2E8B57; color: #fff;>
          
          <h4 class="modal-title">Create account <span class="glyphicon glyphicon-pencil pull-right"style="font-size:20px;"></h4>
        </div>
        <div class="modal-body">
          Do you want to create account ?
          
        </div>
         <div class="modal-footer">
        <div class="row">
        <div class="col-sm-6 col-lg-6 col-xs-6">
          <button type="button" class="btn btn-default btn-block" data-dismiss="modal">No</button></div>
          <div class="col-sm-6 col-lg-6 col-xs-6">
          <a href="create_acount.php"role="button" class="btn btn-default btn-block" style="font-size: 20px;">Yes</a></div>
          </div>
        </div>
      </div>
      
    </div>
  </div>
     </div>  

                    
                   
         <div class="col-sm-6 col-lg-6 col-xs-6">

           <!-- trigger button to open the modal-->
      <a href="#myModal2" class="btn btn-info btn-md" data-toggle="modal" data-backdrop="false"><img src="images/icons/d.png" class="img-circle img-responsive" width="140px"height="90px"/> <p style="margin-left: 34px">  Login</p></a>
      
      <!-- Modal -->
  <div class="modal fade" id="myModal2" role="dialog" style="margin: 70px 0px 0px 40px;">
    <div class="modal-dialog modal-sm">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header" style="background-color:#2E8B57; color: #fff;">
          
          <h4 class="modal-title">Login <span class="glyphicon glyphicon-lock pull-right"></span></h4>
        </div>
        <div class="modal-body">
          
          Do you want to Login ?
          
        </div>
        <div class="modal-footer">
        <div class="row">
        <div class="col-sm-6 col-lg-6 col-xs-4">
          <button type="button" class="btn btn-default btn-block" data-dismiss="modal">No</button></div>
          <div class="col-sm-6 col-lg-6 col-xs-6">
          <a href="userLogin.php"role="button" class="btn btn-default btn-block" style="font-size: 20px;">Yes</a></div>
          </div>
        </div>
      </div>
      
       </div>
     </div>
  </div>
</div>                               
</div>
</div>
</div> 
</div>

 <div class="row">
<div class="col-sm-7 col-lg-7 col-xs-7">

 <div class="panel-heading" style ="background-color: #2E8B57;">
    <h4 class="panel-title" style ="color:#fff;">MISSION</h4>
    <a href="www.rss.com" title="www.rss.com/gme.lga"><span class="rss pull-right"  style=" font-size:30px; margin-top: -25px; margin-right: -10px;"></span></a></div>
      <div class="panel-body">
          <P style ="font-weight: 200;color: #000;"><img src="img/gombe.jpeg" width ="145px" height="120px" style="float:left;
  width:90px;
  height:100px;
  margin-top:10px;
  padding-right:10px;
  position:relative;">
  To provide indigene letter to all people in Gombe local government who are certify that they are the indigene of Gombe local government. 
         </P>
      </div>
    
</div>
    <div class="col-sm-5 col-lg-5 col-xs-5">
       <div class="panel-heading"style ="background-color: #2E8B57;">
    <h4 class="panel-title"style ="color:#fff;">VISSION</h4>
    <a href="www.twitter.com" title="www.twitter.com/@gme.lga"><span class="twitter pull-right"  style=" font-size:30px; margin-top: -25px; margin-right: -10px;"></span></a>
    </div>
      <div class="panel-body">
          <P style ="font-weight: 200;color: #000;"><img src="img/sarki.jpeg" width ="145px" height="120px" style="float:left;
  width:90px;
  height:100px;
  margin-top:10px;
  padding-right:10px;
  position:relative;">
         To lead the way in delivery of indigene letters to all over in Gombe local government</P>
      </div>
</div> 

 </div>

<div class="row">
<div class="col-sm-7 col-lg-7 col-xs-7">

 <div class="panel-heading" style ="background-color: #2E8B57;">
    <h4 class="panel-title"style ="color:#fff;">HISTORY OF GOMBE LOCAL GOVERNMENT  GOMBE STATE</h4></div>
      <div class="panel-body">
          <P style ="font-weight: 200;color: #000;"><img src="img/gombe.jpeg" width ="145px" height="120px" style="float:left;
  width:90px;
  height:100px;
  margin-top:10px;
  padding-right:10px;
  position:relative;">
          Gombe is the capital city of Gombe state, North-eastern Nigeria, with and estimeted population of 261,536. The city is the headquarters of the Gombe Emirate, a traditional state that covers most of Gombe state.
          Gombe State is mainly populated by Fulani people constituting more than half of the state population(more than 50%) Other minor ethnic groups include the Hausa, Bolewa, Tera, Tangale, Waja, and Kanuri.<br>   The LGA has an area of 52 kilometers and a population of 268,000 at the 2006 census.</P>
      </div>
    
</div>
    <div class="col-sm-5 col-lg-5 col-xs-5">
       <div class="panel-heading"style ="background-color: #2E8B57;">
    <h4 class="panel-title"style ="color:#fff;">HISTORY OF GOMBE EMIRATE</h4></div>
      <div class="panel-body">
          <P style ="font-weight: 200;color: #000;"><img src="img/sarki.jpeg" width ="145px" height="120px" style="float:left;
  width:90px;
  height:100px;
  margin-top:10px;
  padding-right:10px;
  position:relative;">
         The Gombe Emirate is a traditional state in Nigeria that rougthly corresponds in area to the modern Gombe state. Gombe state also contains the emirates of Dukku, Deba, Akko, Yamaltu, pindiga, Nafada,and Funakaye. The Gombe emirate was founded in 1804 during the fulani jihad by dan fodio. Buba yero made Gombe Aba his headquarters for a campaign against the jukun stttelemens of pindga and kalma, followed by extensive raids in which he went as far as Adamawa on the other side of the Benue River. </P>
      </div>
</div> 

 </div>
</diV>

    <!-- ******begining of the footer****************-->
   <div class="footer" style="margin-top:45px; background-color: #2E8B57;opacity: 0.9;">
    <div class ="navbar navbar-inverse  navbar-fixed-bottom" style="height: 50px; background-color: #2E8B57; border-top: 2px solid yellow;">
        <div class="navbar navbar-brand"> 
        <p> <marquee direction="left" style="color: yellow;">Welcome to Gombe local Government indigene online application. Copyright &#169; 2018 | <a href="http://Gombe.gme.ng/" target="_blank" style="color: yellow" >Gombe.gme.ng</a> | All rights reserved. powered by Briatek Computer Institute. Welcome to Gombe local Government indigene online application. Copyright &#169; 2018 | <a href="http://Gombe.gme.ng/" target="_blank" style="color: yellow" >Gombe.gme.ng</a> | All rights reserved. powered by Briatek Computer Institute.</marquee><b><a href = "#Top" class="bb" style="float: right;margin-top: 40px;">back to top</a></b><p>
       

             
    </div>
 </div> 
 </div>
 
 
 <!-- ************* End of the footer ****************-->


<script>
$(document).ready(function(){
    // Activate Carousel
    $("#myCarousel").carousel({interval:500});
    
    // Enable Carousel Indicators
    $(".item1").click(function(){
        $("#myCarousel").carousel(0);
    });
    $(".item2").click(function(){
        $("#myCarousel").carousel(1);
    });
    $(".item3").click(function(){
        $("#myCarousel").carousel(2);
    });
    $(".item4").click(function(){
        $("#myCarousel").carousel(3);
    });
    $(".item5").click(function(){
        $("#myCarousel").carousel(4);
    });
    $(".item6").click(function(){
        $("#myCarousel").carousel(5);

        $(".item").click(function(){
        $("#myCarousel").carousel(6);
    });
       
    // Enable Carousel Controls
   // $(".left").click(function(){
       // $("#myCarousel").carousel("prev");
    //});
    $(".right").click(function(){
       // $("#myCarousel").carousel("next");
   // });
//});
</script>
  
</body>
</html>