<?php
 session_start();
require "socialconnection.php"; 
$date1 =date('d-m-y h:i:s');

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Log in</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css"/>
<link href="css/mystyle.css" rel="stylesheet" type="text/css"/>
</head>

<body>
<?php
	require "socialconnection.php";
	if (isset($_POST['boton'])) {
		$name =$_POST['nam'];
		$image =$_FILES['uplod']['name'];
		$tmpName =$_FILES['uplod']['tmp_name'];
		if(!empty($name)and !empty($image)){
			$_SESSION['userid'] =$name;
			$_SESSION['userimage'] =$image;
			//move image
			move_uploaded_file($tmpName,"images/".$image);
			header("location:media.php");
		}else{
			echo "you must enter name";
		}
	}
	?>
<form class="form-inline" role ="form" enctype="multipart/form-data" method="POST">

	<input type="text" name="nam"placeholder ="name" class="form-control"style="margin-left:90px;margin-top: 50px;">
	<input type="file" name="uplod" class="form-control"style="margin-left:90px;margin-top: 50px;">
	<button type="submit"name ="boton"style="margin-left:10px; margin-top:50px;" class="btn btn-success btn-sm" >login</button>
	
</form>

</body>
</html>