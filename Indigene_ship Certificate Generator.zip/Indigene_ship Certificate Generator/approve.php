<?php
session_start();
ob_start();
require "projectconnection.php";
$date1 =date('d-m-y h:i:s');

?>
<!DOCTYPE html>
<html>
<head>
	<title>Approve applicants</title>
  <link rel ="icon" type ="text/image" href="img/a1.jpeg">
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="=device-, initial-scale=1.0"> 
	<!--linking boostrap-->
	<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css">
	<!--linking custom CSS-->
  <link rel="stylesheet" type="text/css" href="css/font-awesome.css">
	<link rel="stylesheet" type="text/css" href="css/mystyle.css">
	<!--linking JS for boostrap-->
  <link rel="shortcut icon" href="../favicon.ico"> 
        
	<script type="text/javascript" src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js" type="text/javascript"></script>
<!-- background slider link
<link rel="stylesheet" type="text/css" href="css/style1.css" />
    <script type="text/javascript" src="js/modernizr.custom.86080.js"></script>
    -->

    
</head>
<body id="page" style="background-image: url(images/80.png);background-size: cover;background-attachment: fixed;">
<!--header-->
<div class ="navbar navbar-default  navbar-fixed-top" style=" background-color:#2E8B57; height: 60px; border-bottom: 2px solid; color: yellow;">
    <div class="navbar navbar-brand">
        <a <href="index.html"><img src="img/a1.jpeg" width="65%" height="65%"   style="margin-top: -15px;float: left;" class="img-responsive img-circle"></a>
    </div>
    <p class="txtlogo" style="color:#fff; margin-top:25px; margin-left: -190px; font-size: 20px;">GOMBE LOCAL GOVERNMENT
      <div style="float: right; margin-top: -40px; margin-right: 10px; padding: 0px 10px 0px 10px;">
        <a href="www.facebook.com" title="www.facebook.com/gme.lga" ><span class="facebook"></span></a> 
        <a href="www.twitter.com" title="www.twitter.com/@gme.lga"><span class="twitter"></span></a> 
        <a href="www.rss.com" title="www.rss.com/gme.lga"><span class="rss"></span></a> 
        <a href="www.google.com" title="www.googleplus.com/gme.lga"><span class="google"></span></a> 
      </div>
    
    
    </p>
 
    </div>
<nav class="navbar navbar-default navbar-fixed-top" role="navigation" style="background-color:#fff;margin-top: 60px; border-bottom: 2px solid; color: yellow;">
        <div class="container-fluid">
            <!--Brand and toggle get grouped-->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" 
                data-target="#col">
                    <span class="sr-only">toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                
                
            </div>
            <!--collect the nav links, forms and other content for toggle-->
            <div class="collapse navbar-collapse" id="col">
                <ul class="nav navbar-nav">
                    <li><a href="home.php">
                    <span class="glyphicon glyphicon-home"></span> Home
                    <span class="sr-only">(Current)</span></a></li>
                    
                </ul>
                
                <ul class="nav navbar-nav" style="margin-left: 0px;">
                    
                    <li class="dropdown active" style="margin-left: 80px;">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                    <span class="glyphicon glyphicon-user" style="height: 15px;"></span>&emsp;
                    WELCOME ADMIN!
                    <span class="caret"></span>
                        <ul class="dropdown-menu" role="menu">
                            <li role="presentation" class="dropdown-header" style="background-color: #2E8B57; height: 45px;"><label class="label" style="color:#fff; font-size: 15px;">Admin</label></li>
                            <li class="divider"></li>
                            
                            <li class="divider"></li>
                            <li><a href="home.php"><span class="glyphicon glyphicon-log-out"></span>&emsp;Logout</a></li>
                            <li class="divider"></li>
                            <li class="divider"></li>
                            <li><a href="adminhome.php"><span class="glyphicon glyphicon-dashboard" style="color: red;"></span>&emsp;Admin Dash Board</a></li>
                        </ul>
                    </li>
                </ul>
            </div> 
        </div>
    </nav>

    </div>



 <div class="container" style ="margin-top:130px;">
   <div class="row">
     <div class="col-sm-0 col-lg-0"></div>
     <div class="col-sm-12 col-lg-12">
       <form role  ="form">
         <div class="panel panel-default" style="border-radius: 25px 25px 0px 0px; box-shadow:">

         <!--<div class="panel-heading"style="background-color: #2E8B57;">
           <h4 class="panel-title" style="color: #fff;">Applicants information</h4>
         </div>-->
         <div class="well" style="background-color: #2E8B57; font-size: 30px; color: #fff; font-style: italic; border-radius: 25px 25px 0px 0px;">applicants information <span style="font-size: 30px;color: #fff;float:right;" class="glyphicon glyphicon-pencil"></div>
           <div class="panel-body"style="background-color:#>
              <?php
        require "projectconnection.php";
            if(isset($_GET['id'])) {
        $serial_no =$_GET['id'];
        $_SESSION['serial'] = $serial_no;
     
      
}
?>     
           <div class="jumbotron">

             <div class="table-responsive">
  <table border="0" class="table table-borderd table-striped ">
    <tr>
      <th>S/n</th>
      <th>Full Name</th>
      <th>ward</th>
      <th>Phone NO.</th>
      <th>Date Of apply</th>
      <th>All information</th>
    </tr>

     <?php
                                            $result = mysql_query("SELECT * FROM biodata2 WHERE approve = '0'");
                                            $numrows = mysql_num_rows($result);
                                            for ($i=0; $i < $numrows; $i++) { 
                                               $fname = strtoupper(mysql_result($result,$i, 'fname'));
                                               $mname = strtoupper(mysql_result($result,$i, 'mname'));
                                               $lname = strtoupper(mysql_result($result,$i, 'lname'));
                                               $ward = strtoupper(mysql_result($result,$i, 'ward'));
                                               $phone = strtoupper(mysql_result($result,$i, 'phoneNo'));
                                               $comdate = strtoupper(mysql_result($result,$i, 'comdate'));
                                               $id =strtoupper(mysql_result($result,$i, 'id'));
                                               $serial_no = mysql_result($result,$i, 'sn');
                                       echo "<tr>
                                    <td> $id </td>
                                    <td>$fname&emsp;$mname&emsp;$lname</td>
                                    <td>$ward</td>
                                    <td>$phone</td>
                                    <td>$comdate</td>
                                   <td><a href ='moredetails.php?id=$serial_no' style='font-size: 20px;color:#fff; background-color: #2E8B57;' role='button' class='btn btn-success'> More details</a></td>
                                    
                                </tr>";
                                    }

                                        
                                    ?>
    
  </table>
  
</div>
</div>
           </div>
         </div>
       </form>
     </div>
     <div class="col-sm-0 col-lg-0"></div>
   </div>
 </div>

 <!-- ******begining of the footer****************-->
   <div class="footer" style="margin-top:45px; background-color: #2E8B57;opacity: 0.9;">
    <div class ="navbar navbar-inverse  navbar-fixed-bottom" style="height: 50px; background-color: #2E8B57; border-top: 2px solid yellow;">
        <div class="navbar navbar-brand"> 
        <p> <marquee direction="left" style="color: yellow;">Welcome to Gombe local Government indigene online application. Copyright &#169; 2017 | <a href="http://Gombe.gme.ng/" target="_blank" style="color: yellow" >Gombe.gme.ng</a> | All rights reserved. powered by Briatek Computer Institute. Welcome to Gombe local Government indigene online application. Copyright &#169; 2017 | <a href="http://Gombe.gme.ng/" target="_blank" style="color: yellow" >Gombe.gme.ng</a> | All rights reserved. powered by Briatek Computer Institute.</marquee><b><a href = "#Top" class="bb" style="float: right;margin-top: 40px;">back to top</a></b><p>
       <!-- <p style ="color: #fff;">Copyright &#169; 2017 | <a href="http://gsu.edu.ng/" target="_blank" >Gombe.gme.ng</a> | All rights reserved.</p>
        </div>
        <div class="icons">
                <a href="www.facebook.com/mautech" title="www.facebook.com/gme"
                style ="margin-top: 8px;float: right; font-size: 20px; padding: 0px 5px 0px 0px; ">
                <span class="fa fa-facebook-square" style="color: #fff;"></span></a>

                <a href="www.googleplus.com/mautech" title="www.googleplus.com/gme"
                style ="margin-top: 8px;float: right; font-size: 20px; padding: 0px 5px 0px 0px; ">
                <span class="fa fa-google-plus-square" style="color: #fff;"></span></a>

                <a href="www.twitter.com/@glga" title="www.twitter.com/@gme"
                style ="margin-top: 8px;float: right; font-size: 20px; padding: 0px 5px 0px 0px; ">
                <span class="fa fa-twitter-square" style="color: #fff;"></span></a>

                <a href="www.rss.com/gme" title="www.rss.com/gme"
                style ="margin-top: 8px;float: right; font-size: 20px; padding: 0px 5px 0px 0px; ">
                <span class="fa fa-rss-square" style="color: #fff;"></span></a>

                <a href="www.linkedin.com/gme" title="www.linkedlocl.com/gme"
                style ="margin-top: 8px;float: right; font-size: 20px; padding: 0px 5px 0px 0px; ">
                <span class="fa fa-linkedin-square" style="color: #fff;"></span></a>

                <a href="callto:+2347061992697" title="+2347061992697">
                <span class="fa fa-phone-square" style="color: #fff;margin-top: 12px;float: right; font-size: 20px; padding: 0px 5px 0px 0px;"></span></a>

                <a href="mailto:gme@gmail.com" title="gme@gmail.com">
                <span class="glyphicon glyphicon-phone-alt" style="color: #fff; margin-top: 10px;float: right; font-size: 20px; padding: 0px 5px 0px 0px;"></span></a>

                <a href="mailto:gme@gmail.com" title="gme@gmail.com">
                <span class="glyphicon glyphicon-envelope" style="color: #fff; margin-top: 12px;float: right; font-size: 20px; padding: 0px 5px 0px 0px;"></span></a>
            </div><br>-->
           
             
    </div>
 </div>
 </div>
 
 </footer>
 <!-- ************* End of the footer ****************-->
</body>
</html>