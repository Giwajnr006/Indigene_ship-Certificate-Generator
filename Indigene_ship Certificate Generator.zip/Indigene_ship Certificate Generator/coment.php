<?php
    require 'projectconnection.php';


?>

<!DOCTYPE html>
<html>
<head>
    <title>coments</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <link rel="icon" type="text/image" href="img/a1.jpeg"> 
    <!--linking boostrap-->
    <link type="text/css" rel="stylesheet" href="css/bootstrap.min.css" />
    
    <!--- I copied from getboostrap.com-->
    <link rel="stylesheet" type="text/css" href="css/font-awesome.css">
    <link rel="stylesheet" type="text/css" href="css/npcprj.css">

    <link rel="icon" href="img/logomautech.png">
    <!-- Latest compiled and minified CSS -->
    
</head>
<body style="background-image: url(images/80.jpg);background-size: cover;background-attachment: fixed;">
<!--*********************HEADER NAVIGATION**********************************************-->
        <div class ="navbar navbar-default  navbar-fixed-top" style=" background-color:#2E8B57; height: 60px; border-bottom: 2px solid; color: yellow;">
    <div class="navbar navbar-brand">
        <a <href="index.html"><img src="img/a1.jpeg" width="65%" height="65%"   style="margin-top: -15px;float: left;" class="img-responsive img-circle"></a>
    </div>
    <p class="txtlogo" style="color:#fff; margin-top:25px; margin-left: -190px; font-size: 20px;">GOMBE LOCAL GOVERNMENT
    <a href="home.php" style="margin-left: 200px; color: #fff;"><span class="glyphicon glyphicon-log-out" style =" margin-top:0px; margin-left: 200px; color:#fff;"> </span> Logout</a>
    </p>
 
    </div>
<nav class="navbar navbar-default navbar-static-top" role="navigation" style="background-color:#fff;margin-top: 50px;">
        <div class="container-fluid">
            <!--Brand and toggle get grouped-->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" 
                data-target="#col">
                    <span class="sr-only">toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                
                
            </div>
            <!--collect the nav links, forms and other content for toggle-->
            <div class="collapse navbar-collapse" id="col">
                <ul class="nav navbar-nav">
                    <li><a href="adminhome.php">
                    <span class="glyphicon glyphicon-home"></span> Home
                    <span class="sr-only">(Current)</span></a></li>
                    
                </ul>
                <form class="navbar-form navbar-left" role="search">
                                <div class="input-group">
                                    <a href="search.php " class="btn btn-default" name="search">search</a>
                                 </div>              
                </form>
                <ul class="nav navbar-nav" style="margin-left: 0px;">
                    
                    <li class="dropdown active">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                    <span class="glyphicon glyphicon-user"></span>&emsp;
                    WELCOME ADMIN!
                    <span class="caret"></span>
                        <ul class="dropdown-menu" role="menu">
                            <li role="presentation" class="dropdown-header" style="background-color: #2E8B57;"><label class="label" style="color:#fff;font-size: 15px;">Admin</label></li>
                            <li class="divider"></li>
                            <li><a href="adminhome.php"><i class="fa fa-home fa-fw"></i> Home</a></li>
                            <li class="divider"></li>
                            <li><a href="biodata.php"><i class="fa fa-edit fa-fw"></i> Manage Record</a></li>
                            <li class="divider"></li>
                            <li><a href="viewapplicant.php"><i class="fa fa-picture-o fa-fw"></i> View applicants Record</a></li>
                            <li class="divider"></li>
                            <li><a href="#" class="active"><i class="fa fa-edit fa-fw"></i> Approve </a></li>
                            <li class="divider"></li>
                            <li><a href="first.php"><i class="fa fa-files-o"></i> Print and Export Record</a></li>
                            <li class="divider"></li>
                            <li><a href="second.php"><i class="fa fa-files-o"></i> Send Text</a></li>
                            
                        
                            
                            <li class="divider"></li>
                            <li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span>&emsp;Logout</a></li>
                            <li class="divider"></li>
                            <li><a href="profile.php"><span class="glyphicon glyphicon-user"></span>&emsp;Profile</a></li>
                            <li class="divider"></li>
                            <li><a href="adminhome.php"><span class="glyphicon glyphicon-dashboard" style="color: red;"></span>&emsp;Dash Board</a></li>
                        </ul>
                    </li>
                </ul>
            </div> 
        </div>
    </nav>

<!--*********************END OF HEADER NAVIGATION**********************************************-->
<!--%%%%%%%%% LOGIN FORM %%%%%%%%%%%%%%%%%%-->
<!--%%%%%%%%% LOGIN FORM %%%%%%%%%%%%%%%%%%-->
<div class="container">
<div class="row">
    <div class="col-lg-offset-1 col-lg-10">
        <div class="panel panel-default" style="margin-bottom: 100px;">
            <div class="panel-heading" style="background-color: #E0E0E0;">
                <h1 style="color: #424242;"><span class="fa fa-comments" style="color: #424242;font-size: 40px;"></span>&emsp;Comments</h1>
            </div>
            <div class="panel-body">
                <div class="row">
                <div class="col-lg-12">
                    <ul class='media-list'>
                    <?php
                    $dispalycomm = mysql_query("SELECT * FROM cantact_tbl ORDER BY id DESC");
                    for ($i=0; $i <mysql_num_rows($dispalycomm) ; $i++) { 
                       $name = mysql_result($dispalycomm,$i, 'name');
                       $email = mysql_result($dispalycomm,$i, 'email');
                       $phone = mysql_result($dispalycomm,$i, 'phone');
                       $mss = mysql_result($dispalycomm,$i, 'message');
                       $time = mysql_result($dispalycomm,$i, 'comdate');
                echo "
                        <li style = 'background-color:#eee;border-radius:35px 30px 0px 0px; border-bottom:2px solid; color:#585856;'>
                            <img src = 'img/images.png' class = 'image img-circle img-responsive' style = 'float:left;margin-right:10px;' width='10%'/>
                            <p style='font-size:20px;color:#424242; margin-left:30px;'>$name</p>
                            <p style= 'font-size:15px; color:#424242; margin-left:30px;'>
                            <a href = 'mailto:$email  margin-left:30px;'>$email</a></p>
                            <p style= 'font-size:15px; color:#424242; margin-left:30px;'>$phone</p>
                            <p style= 'font-size:15px; color:#424242;margin-left:30px;'>$mss</p>
                            <p style= 'font-size:15px; color:#FF3D00;margin-left:30px;'>at $time</p>
                            <a href = 'mailto:$email' class = 'btn btn-lg btn-primary' style='background-color:#2E8B57; color:#fff; margin-left:30px;'>Send Mail<a/>
                            <hr>
                        </li>
                    ";
                    }
                ?>
                </ul>
                </div>
                </div>
            </div>
        </div>
    </div>
</div>
    
</div>
<!--%%%%%%%%% END LOGIN FORM %%%%%%%%%%%%%%%%%%-->

<!--%%%%%%%%% END LOGIN FORM %%%%%%%%%%%%%%%%%%-->
<div class="navbar navbar-default navbar-fixed-bottom" style="background-color: #2E8B57; border-top: 2px solid yellow;">
            
            <div class="navbar-header">
                <div class="navbar-brand">
                    <marquee style="color: #fff;">powered by Briatek Computer Institute</marquee>
                </div>
            </div>
        </div>



<!---scripft -->
 <!-- jQuery -->
    
     <script src="js/jquery.min.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    

<script>
    $(function(){
        $('.nav-tabs a:first').tab('show');
    });
</script>
<script>
$(document).ready(function(){
    $('[data-toggle="popover"]').popover(); 
});
</script>
</body>
</html>