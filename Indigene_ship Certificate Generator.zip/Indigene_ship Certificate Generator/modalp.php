<?php
require "connection.php";
$date1 =date('d-m-y h:i:s');
?>
<!DOCTYPE html>
<html>
<head>
	<title>mautech.edu.ng</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="=device-, initial-scale=1.0"> 
	<!--linking boostrap-->
	<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css">
	<!--linking custom CSS-->
  <link rel="stylesheet" type="text/css" href="css/font-awesome.css">
	<link rel="stylesheet" type="text/css" href="css/mystyle.css">
	<!--linking JS for boostrap-->
  <link rel="shortcut icon" href="../favicon.ico"> 

</head>
<body>
     <div class="container">
       <!-- trigger button to open the modal-->
      <button type="button" class="btn btn-info" data-toggle="modal" data-target="#mymodal">open modal</button>
      <!--modal-->
      <div id ="mymodal" class="modal fade" role ="dialog">
        <div class="modal-dialog modal-sm">
          <!-- modal content-->
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close"data-dismiss="modal">&times;</button>
              <h4 class="modal-title">Do you want to log in?</h4>
            </div>
            <div class="modal-body">
              <h4><a href="login.pph">yes</a></h4>
            </div>
          </div>
        </div>
      </div>
     </div>  

     <div class="container">
       <!-- trigger button to open the modal-->
      <button type="button" class="btn btn-info btn-md" data-toggle="modal" data-target="#myModal2" data-backdrop="false">Modal without Overlay (false)</button>
      
      <!-- Modal -->
  <div class="modal fade" id="myModal2" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">×</button>
          <h4 class="modal-title">Modal without Overlay</h4>
        </div>
        <div class="modal-body">
          <p>This modal has no overlay.</p>
          <p><strong>Note:</strong> You cannot click outside of this modal to close it.</p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
     </div>  

</script>
  <script type="text/javascript" src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js" type="text/javascript"></script>
</body>
</html>