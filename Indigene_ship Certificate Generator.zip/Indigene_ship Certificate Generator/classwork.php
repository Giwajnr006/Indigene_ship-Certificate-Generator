<?php
session_start();
require"connection.php";
?>
<!DOCTYPE html>
<html>
<head>
	<title>upload image</title>
</head>
<body>
<?php
	require "connection.php";
	if (isset($_POST['submit'])) {
		$name =$_FILES['imaged']['name'];
		$size =$_FILES['imaged']['size'];
		$tmpName =$_FILES['imaged']['tmp_name'];
		$_SESSION['regno']=$username;

		//echo $size." ".$name." ".$tmpName;
		$extended =explode(".", ($name));
		$imagextention =strtolower(end($extended ));
		$finalName ="ug12/sccs/1023";
		$rename =str_replace("/", "m", $finalName).".".$imagextention;
		
		 $nnn =end($extended);
		 if(!empty($name)){
		if($nnn=='pngp'or $nnn='jpgy'){
			if($size<=30720){
				move_uploaded_file($tmpName,"images/".$name);
				mysql_query("INSERT INTO pass_tbl(passport) VALUES('$rename')");

			}else{
				echo "image is too large";
			}
			echo "valid image";
		}else{
			echo "invalid image";
		}
		}

	$sqlqury =mysql_query("SELECT * FROM pass_tbl WHERE reg_no ='$rename');
	$hun =$_SESSION['regno'];
	$nam =mysql_result($sqlqury,0,'passport');
	
	echo $nam;                                                                                                     

	}
?>
<form enctype="multipart/form-data" method="POST">
	<input type="file" name="imaged"><br><br>
	<input type="submit" name="submit" value="upload">
</form>

</body>
</html>