
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Log in</title> 
<link href="css/bootstrap.css" rel="stylesheet" type="text/css"/>
<!--<link href="css/mystyle.css" rel="stylesheet" type="text/css"/>-->

<script type="text/javascript" src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js" type="text/javascript"></script>
<style>
  .carousel-inner > .item > img,
  .carousel-inner > .item > a > img {
      width: 70%;
      margin: auto;
  }
  </style>
</head>

<body>
<div class="container" style="margin-top: 80px;">
	<div class="row">
		<div id ="myCarousel" class="carousel slide" data-ride="carousel">
			 <!-- Indicators -->
			 <ol class="carousel-indicators">
			 	<li class="item1 active"></li>
			 	<li class="item2"></li>
			 	<li class="item3"></li>
			 	<li class="item4"></li>
			 	<li class="item5"></li>
			 	<li class="item6"></li>
			 	
			 </ol>

			  <!-- Wrapper for slides -->
			  <div class="carousel-inner" role ="listbox">
			  	<div class="item active">
			  		<img src="img/slider/a3.png" width="460" height="345" alt="love image">
			  		<div class="carousel-caption">
			  			<h3>Gombe</h3>
			  			<p>Gombe local government Gombe state</p>
			  		</div>
			  	</div>

			  	<div class="item ">
			  		<img src="img/slider/a3.png" width="460" height="345" alt="love image">
			  		<div class="carousel-caption">
			  			<h3>Gombe</h3>
			  			<p>Gombe local government Gombe state</p>
			  		</div>
			  	</div>

			  	<div class="item ">
			  		<img src="img/slider/3.jpg" width="460" height="345" alt="love image">
			  		<div class="carousel-caption">
			  			<h3>Gombe</h3>
			  			<p>Gombe local government Gombe state</p>
			  		</div>
			  	</div>

			  	<div class="item ">
			  		<img src="img/slider/4.jpg" width="460" height="345" alt="love image">
			  		<div class="carousel-caption">
			  			<h3>Gombe</h3>
			  			<p>Gombe local government Gombe state</p>
			  		</div>
			  	</div>

			  	<div class="item ">
			  		<img src="img/slider/a4.png" width="460" height="345" alt="love image">
			  		<div class="carousel-caption">
			  			<h3>Gombe</h3>
			  			<p>Gombe local government Gombe state</p>
			  		</div>
			  	</div>

			  	<div class="item ">
			  		<img src="img/slider/a5.png" width="460" height="345" alt="image">
			  		<div class="carousel-caption">
			  			<h3>Gombe</h3>
			  			<p>Gombe local government Gombe state</p>
			  		</div>
			  	</div>
			  </div>

			   <!-- Left and right controls -->
			   <a class="Left carousel-control" href="#myCarousel" role ="button" data-slide="prev"><span class="glyphicon glyphicon-chevron-left" aria-hidden ="true"></span><span class="sr-only">Previous</span></a>

			   <a class="right carousel-control" href="#myCarousel" role ="button" data-slide="Next"><span class="glyphicon glyphicon-chevron-right" aria-hidden ="true"></span><span class="sr-only">Next</span></a>
		</div>

		<script>
$(document).ready(function(){
    // Activate Carousel
    $("#myCarousel").carousel({interval: 2000});
    
    // Enable Carousel Indicators
    $(".item1").click(function(){
        $("#myCarousel").carousel(0);
    });
    $(".item2").click(function(){
        $("#myCarousel").carousel(1);
    });
    $(".item3").click(function(){
        $("#myCarousel").carousel(2);
    });
    $(".item4").click(function(){
        $("#myCarousel").carousel(3);
    });
    $(".item5").click(function(){
        $("#myCarousel").carousel(3);
    });
    $(".item6").click(function(){
        $("#myCarousel").carousel(3);
    });
    // Enable Carousel Controls
    $(".left").click(function(){
        $("#myCarousel").carousel("prev");
    });
    $(".right").click(function(){
        $("#myCarousel").carousel("next");
    });
});
</script>

	<p>The data-placement attribute specifies the tooltip position.</p>
  <ul class="list-inline">
    <li><a href="#" data-toggle="tooltip" data-placement="top" title="Hooray!">Top</a></li>
    <li><a href="#" data-toggle="tooltip" data-placement="bottom" title="Hooray!">Bottom</a></li>
    <li><a href="#" data-toggle="tooltip" data-placement="left" title="Hooray!">Left</a></li>
    <li><a href="#" data-toggle="tooltip" data-placement="right" title="Hooray!">Right</a></li>
  </ul>
</div>

<script>
$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();   
});
</script>


</body>
</html> 

