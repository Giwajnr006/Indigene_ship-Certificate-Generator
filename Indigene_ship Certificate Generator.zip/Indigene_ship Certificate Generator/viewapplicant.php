<?php
require "projectconnection.php";
$date1 =date('d-m-y h:i:s');

?>
<!DOCTYPE html>
<html>
<head>
	<title>Approve applicants</title>
  <link rel="icon" type="text/image" href="img/a1.jpeg">
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="=device-, initial-scale=1.0"> 
	<!--linking boostrap-->
	<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css">
	<!--linking custom CSS-->
  <link rel="stylesheet" type="text/css" href="css/font-awesome.css">
	<link rel="stylesheet" type="text/css" href="css/mystyle.css">
	<!--linking JS for boostrap-->
  <link rel="shortcut icon" href="../favicon.ico"> 
        
	<script type="text/javascript" src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js" type="text/javascript"></script>
<!-- background slider link
<link rel="stylesheet" type="text/css" href="css/style1.css" />
    <script type="text/javascript" src="js/modernizr.custom.86080.js"></script>
    -->

    
</head>
<body style="background-image: url(img/bgg.jpg);background-size: cover;background-attachment: fixed;">
<!--%%%%%%%%%%%%HEADER %%%%%%%%%%%%%%%%%%%%%-->
<div class ="navbar navbar-default  navbar-fixed-top" style=" background-color:#2E8B57; height: 60px; border-bottom: 2px solid; color: yellow;">
    <div class="navbar navbar-brand">
        <a <href="index.html"><img src="img/a1.jpeg" width="65%" height="65%"   style="margin-top: -15px;float: left;" class="img-responsive img-circle"></a>
    </div>
    <p class="txtlogo" style="color:#fff; margin-top:25px; margin-left: -190px; font-size: 20px;">GOMBE LOCAL GOVERNMENT
    <a href="home.php" style="margin-left: 200px; color: #fff;"><span class="glyphicon glyphicon-log-out" style =" margin-top:0px; margin-left: 200px; color:#fff;"> </span> Logout</a>
    </p>

     <nav class="navbar navbar-default navbar-static-top" role="navigation" style="background-color:#fff; margin-top: -3px;">
        <div class="container-fluid">
            <!--Brand and toggle get grouped-->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" 
                data-target="#col">
                    <span class="sr-only">toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                
                
            </div>
            <!--collect the nav links, forms and other content for toggle-->
            <div class="collapse navbar-collapse" id="col">
                <ul class="nav navbar-nav">
                    <li><a href="home.php">
                    <span class="glyphicon glyphicon-home"></span> Home
                    <span class="sr-only">(Current)</span></a></li>
                    <li><a href="contact.php"><span class="glyphicon glyphicon-glass">
                    </span> Contact Us</a></li>
                    <li class="dropdown" >
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                    <span class="glyphicon glyphicon-user">
                    </span>  WELCOME ADMIN<span class="caret"></span></a>
                        <ul class="dropdown-menu" role="menu">
                            <li><a href="login.php">Login</a></li>
                            <li class="divider"></li>
                            <li><a href="create_acaunt.php">Sign up </a></li>
                            <li class="divider"></li>
                            <li><a href="biodata">Registration form </a></li>
                            <li class="divider"></li>
                            <li class="divider"></li>
                            <li><a href="#">check approve</a></li>
                        </ul>
                    </li>
                </ul>
                
            </div> 
        </div>
    </nav>
 
    </div>



 <div class="container" style ="margin-top:130px;">
   <div class="row">
     <div class="col-sm-0 col-lg-0"></div>
     <div class="col-sm-12 col-lg-12">
       <form role  ="form">
         <div class="panel panel-default" style="border-radius: 25px 25px 0px 0px; box-shadow:2px 2px 8px 4px #BDBDBD;">

         <!--<div class="panel-heading"style="background-color: #2E8B57;">
           <h4 class="panel-title" style="color: #fff;">Applicants information</h4>
         </div>-->
         <div class="well" style="background-color: #2E8B57; font-size: 30px; color: #fff; font-style: italic; border-radius: 25px 25px 0px 0px;">applicants information <span style="font-size: 30px;color: #fff;float:right;" class="glyphicon glyphicon-pencil"></div>
           <div class="panel-body"style="background-color:#>

           <div class="jumbotron">

             <div class="table-responsive">
  <table border="0" class="table table-borderd table-striped ">
    <tr>
      <th>S/n</th>
      <th>Full Name</th>
      <th>ward</th>
      <th>Phone NO.</th>
      <th>Date Of apply</th>
      <th>All information</th>
    </tr>
    <tr>
      <td>1</td>
      <td>Nura muhammad sani</td>
      <td>investiment quaters</td>
      <td>0706199297</td>
      <td>25-9-2017 10:30:03</td>
      <td><a href ="moreinformation.php" style="font-size: 20px;color:#fff; background-color: #2E8B57;" role="button" class="btn btn-success"> More details</a></td>
    </tr>
    <tr>
      <td>2</td>
      <td>abubakar muhammad sadiq</td>
      <td>dawaki quaters</td>
      <td>0706199297</td>
      <td>25-9-2017 10:30:03</td>
      <td><a href ="moreinformation.php" style="font-size: 20px;color:#fff; background-color: #2E8B57;" role="button" class="btn btn-success"> More idetails</a></td>
    </tr>
    <tr>
      <td>3</td>
      <td>Nura muhammad sani</td>
      <td>shamaki ward</td>
      <td>08135267782</td>
      <td>26-9-2017 10:54:08</td>
      <td><a href ="moreinformation.php" style="font-size: 20px; color:#fff; background-color: #2E8B57;" class="btn btn-success"> More idetails</a></td>
    </tr>
    <tr>
      <td>4</td>
      <td>yusuf sulaiman ali</td>
      <td>shamaki ward</td>
      <td>08027823390</td>
      <td>26-9-2017 11:11:01</td>
      <td><a href ="moreinformation.php" style="font-size: 20px; color:#fff; background-color: #2E8B57;" class="btn btn-success"> More details</a></td>
    </tr>
   <tr>
      <td>5</td>
      <td>fatima muhammad bello</td>
      <td>anguwar gandu</td>
      <td>08035298897</td>
      <td>26-9-2017 10:24:12</td>
      <td><a href ="moreinformation.php" style="font-size: 20px; color:#fff; background-color: #2E8B57;" class="btn btn-success" > More details</a></td>
    </tr>
  </table>
  
</div>
</div>
           </div>
         </div>
       </form>
     </div>
     <div class="col-sm-0 col-lg-0"></div>
   </div>
 </div>
</body>
</html>