<?php
session_start();
ob_start();
require_once "connection.php"; // Ensure this path is correct and the file exists

if (!isset($_SESSION['serial_no'])) {
    header("Location: login.php"); // DEV BY GIGS_tech
    exit;
}

$session = $_SESSION['serial_no'];
$query = $connection->query("SELECT * FROM sign_up WHERE sn = '$session'");
$result = $query->fetch_assoc();

if (isset($_POST['submit'])) {
    $sn = $_SESSION['serial_no'];
    $fname = $_POST['fname'];
    $mname = $_POST['mname'];
    $lname = $_POST['lname'];
    $dob = $_POST['dob'];
    $gender = $_POST['gender'];
    $mstatus = $_POST['mstatus'];
    $ward = $_POST['ward'];
    $phoneNo = $_POST['phone'];
    $tribe = $_POST['tribe'];
    $nationality = $_POST['nationality'];
    $state = $_POST['state'];
    $lga = $_POST['lga'];
    $religion = $_POST['religion'];
    $email = $_POST['email'];
    $address = $_POST['address'];
    $caddress = $_POST['caddress'];
    $comdate = date("Y-m-d");

    $_SESSION["name"] = $fname;
    $_SESSION['mname'] = $mname;
    $_SESSION['lname'] = $lname;
    $_SESSION['dob'] = $dob;
    $_SESSION['gender'] = $gender;
    $_SESSION['ward'] = $ward;
    $_SESSION['phone'] = $phoneNo;
    $_SESSION['comdate'] = $comdate;
    $_SESSION['sn'] = $sn;

    $stmt = $connection->prepare("INSERT INTO biodata2 (sn, fname, mname, lname, dob, gender, mstatus, ward, phoneNo, tribe, nationality, state, lga, religion, email, address, caddress, comdate) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("isssssssssssssssss", $sn, $fname, $mname, $lname, $dob, $gender, $mstatus, $ward, $phoneNo, $tribe, $nationality, $state, $lga, $religion, $email, $address, $caddress, $comdate);

    if ($stmt->execute()) {
        header("Location: uploadimage.php");
        exit;
    } else {
        die("Error: " . $stmt->error);
    }
    $stmt->close();
}

$connection->close();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Biodata2</title>
    <meta charset="utf-8">
    <link rel="icon" type="text/image" href="img/a1.jpeg">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Linking Bootstrap -->
    <link type="text/css" rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Linking custom CSS -->
    <link rel="stylesheet" type="text/css" href="css/biostyle.css">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.css">
</head>
<body id="page" style="background-image: url(images/80.png); background-size: cover; background-attachment: fixed;">
<!-- Header -->
<div class="navbar navbar-default navbar-fixed-top" style="background-color: #2E8B57; height: 60px; border-bottom: 2px solid; color: yellow;">
    <div class="navbar navbar-brand">
        <a href="index.html"><img src="img/a1.jpeg" width="65%" height="65%" style="margin-top: -15px; float: left;" class="img-responsive img-circle"></a>
    </div>
    <p class="txtlogo" style="color: #fff; margin-top: 25px; margin-left: -190px; font-size: 20px;">INDIGENESHIP APPLICATION
        <a href="home.php" style="margin-left: 200px; color: #fff;"><span class="glyphicon glyphicon-log-out" style="margin-top: 0px; margin-left: 200px; color: #fff;"> </span> Logout</a>
    </p>
</div>
<nav class="navbar navbar-default navbar-static-top" role="navigation" style="background-color: #fff; margin-top: -3px; border-bottom: 2px solid; color: yellow;">
    <div class="container-fluid">
        <!-- Brand and toggle get grouped -->
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#col">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
        </div>
        <!-- Collect the nav links, forms, and other content for toggle -->
        <div class="collapse navbar-collapse" id="col">
            <ul class="nav navbar-nav">
                <li><a href="home.php"><span class="glyphicon glyphicon-home"></span> Home<span class="sr-only">(Current)</span></a></li>
                <li><a href="mydashboard.php"><span class="glyphicon glyphicon-glass"></span> Dashboard</a></li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                        <span class="glyphicon glyphicon-user"></span> You are welcome <?php echo strtoupper($result['fname']); ?><span class=""></span></a>
                    <ul class="dropdown-menu" role="menu">
                        <li><a href="mydashboard.php">Dashboard</a></li>
                        <li class="divider"></li>
                        <li><a href="#">Check approve</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>
<!-- Main Content -->
<div class="container" style="margin-top: 100px;">
    <div class="row">
        <div class="col-sm-1"></div>
        <div class="col-sm-10">
            <div class="panel panel-default">
                <div class="panel-heading" style="background-color: #3cb371; border-bottom: 2px solid; color: yellow; height: 50px;">
                    <h4 class="panel-title" style="color: #fff; font-size: 25px;">Registration form<span class="glyphicon glyphicon-pencil" style="float: right; font-size: 25px;"></span></h4>
                </div>
                <div class="panel-body" style="background-color: #F8F8F8;">
                    <form role="form" method="post">
                        <div class="row">
                            <div class="col-sm-4 col-lg-4">
                                <div class="form-group">
                                    <label for="fname">First Name:</label>
                                    <div class="form-group input-group">
                                        <span class="input-group-addon">
                                            <span class="glyphicon glyphicon-user" style="color: #3cb371;"></span>
                                        </span>
                                        <input type="text" name="fname" placeholder="First Name" class="form-control" required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4 col-lg-4">
                                <div class="form-group">
                                    <label for="mname">Middle Name:</label>
                                    <div class="form-group input-group">
                                        <span class="input-group-addon">
                                            <span class="glyphicon glyphicon-user" style="color: #3cb371;"></span>
                                        </span>
                                        <input type="text" name="mname" placeholder="Middle Name" class="form-control" required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4 col-lg-4">
                                <div class="form-group">
                                    <label for="lname">Last Name:</label>
                                    <div class="form-group input-group">
                                        <span class="input-group-addon">
                                            <span class="glyphicon glyphicon-user" style="color: #3cb371;"></span>
                                        </span>
                                        <input type="text" name="lname" placeholder="Last Name" class="form-control" required>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-4 col-lg-4">
                                <div class="form-group">
                                    <label for="dob">Date Of Birth:</label>
                                    <div class="form-group input-group">
                                        <span class="input-group-addon">
                                            <span class="glyphicon glyphicon-calendar" style="color: #3cb371;"></span>
                                        </span>
                                        <input type="date" name="dob" placeholder="Date Of Birth" class="form-control" required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4 col-lg-4">
                                <div class="form-group">
                                    <label for="gender">Gender:</label>
                                    <div class="form-group input-group">
                                        <span class="input-group-addon">
                                            <span class="glyphicon glyphicon-user" style="color: #3cb371;"></span>
                                        </span>
                                        <select class="form-control" name="gender" required>
                                            <option value="">Select Gender</option>
                                            <option value="male">Male</option>
                                            <option value="female">Female</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4 col-lg-4">
                                <div class="form-group">
                                    <label for="mstatus">Marital Status:</label>
                                    <div class="form-group input-group">
                                        <span class="input-group-addon">
                                            <span class="glyphicon glyphicon-user" style="color: #3cb371;"></span>
                                        </span>
                                        <select class="form-control" name="mstatus" required>
                                            <option value="">Select Marital Status</option>
                                            <option value="single">Single</option>
                                            <option value="married">Married</option>
                                            <option value="divorced">Divorced</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Add more input fields as needed -->
                        <div class="row">
                            <div class="col-sm-4 col-lg-4">
                                <div class="form-group">
                                    <label for="ward">Ward:</label>
                                    <div class="form-group input-group">
                                        <span class="input-group-addon">
                                            <span class="glyphicon glyphicon-map-marker" style="color: #3cb371;"></span>
                                        </span>
                                        <input type="text" name="ward" placeholder="Ward" class="form-control" required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4 col-lg-4">
                                <div class="form-group">
                                    <label for="phone">Phone Number:</label>
                                    <div class="form-group input-group">
                                        <span class="input-group-addon">
                                            <span class="glyphicon glyphicon-earphone" style="color: #3cb371;"></span>
                                        </span>
                                        <input type="text" name="phone" placeholder="Phone Number" class="form-control" required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4 col-lg-4">
                                <div class="form-group">
                                    <label for="tribe">Tribe:</label>
                                    <div class="form-group input-group">
                                        <span class="input-group-addon">
                                            <span class="glyphicon glyphicon-user" style="color: #3cb371;"></span>
                                        </span>
                                        <input type="text" name="tribe" placeholder="Tribe" class="form-control">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-4 col-lg-4">
                                <div class="form-group">
                                    <label for="nationality">Nationality:</label>
                                    <div class="form-group input-group">
                                        <span class="input-group-addon">
                                            <span class="glyphicon glyphicon-globe" style="color: #3cb371;"></span>
                                        </span>
                                        <input type="text" name="nationality" placeholder="Nationality" class="form-control">
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4 col-lg-4">
                                <div class="form-group">
                                    <label for="state">State of Origin:</label>
                                    <div class="form-group input-group">
                                        <span class="input-group-addon">
                                            <span class="glyphicon glyphicon-map-marker" style="color: #3cb371;"></span>
                                        </span>
                                        <input type="text" name="state" placeholder="State of Origin" class="form-control" required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4 col-lg-4">
                                <div class="form-group">
                                    <label for="lga">Local Government Area:</label>
                                    <div class="form-group input-group">
                                        <span class="input-group-addon">
                                            <span class="glyphicon glyphicon-map-marker" style="color: #3cb371;"></span>
                                        </span>
                                        <input type="text" name="lga" placeholder="Local Government Area" class="form-control">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-4 col-lg-4">
                                <div class="form-group">
                                    <label for="religion">Religion:</label>
                                    <div class="form-group input-group">
                                        <span class="input-group-addon">
                                            <span class="glyphicon glyphicon-heart" style="color: #3cb371;"></span>
                                        </span>
                                        <input type="text" name="religion" placeholder="Religion" class="form-control" required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4 col-lg-4">
                                <div class="form-group">
                                    <label for="email">Email:</label>
                                    <div class="form-group input-group">
                                        <span class="input-group-addon">
                                            <span class="glyphicon glyphicon-envelope" style="color: #3cb371;"></span>
                                        </span>
                                        <input type="email" name="email" placeholder="Email" class="form-control">
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4 col-lg-4">
                                <div class="form-group">
                                    <label for="address">Address:</label>
                                    <div class="form-group input-group">
                                        <span class="input-group-addon">
                                            <span class="glyphicon glyphicon-home" style="color: #3cb371;"></span>
                                        </span>
                                        <input type="text" name="address" placeholder="Address" class="form-control" required>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-4 col-lg-4">
                                <div class="form-group">
                                    <label for="caddress">Current Address:</label>
                                    <div class="form-group input-group">
                                        <span class="input-group-addon">
                                            <span class="glyphicon glyphicon-home" style="color: #3cb371;"></span>
                                        </span>
                                        <input type="text" name="caddress" placeholder="Current Address" class="form-control">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <input type="submit" name="submit" value="Submit" class="btn btn-success">
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-sm-1"></div>
    </div>
</div>
<!-- Linking Bootstrap JS -->
<script src="js/bootstrap.min.js"></script>
</body>
</html>
