<?php
require "connection.php";
session_start();
if(isset($_POST['ok']))
	{
		$Rno = $_POST['Rno'];
		$fname = $_POST['fname'];
		$lname = $_POST['lname'];
		$oname = $_POST['oname'];
		$phNo = $_POST['phNo'];
		$email = $_POST['email'];
		$dob = $_POST['dob'];
		$gender = $_POST['gen'];
		$mstatus = $_POST['status'];
		$nation = $_POST['nationality'];
		$sta = $_POST['state'];
		$lga = $_POST['lga'];
		$religion = $_POST['religion'];
		$add = $_POST['add'];
		$nfname = $_POST['N_fname'];
		$nlname = $_POST['N_lname'];
		$noname = $_POST['N_oname'];
		$nphone = $_POST['N_phno'];
		$nemail = $_POST['N_email'];
		$ngender = $_POST['N_gen'];
		$nrelation = $_POST['N_relation'];
		$nadd = $_POST['N_add'];
		
		
		 $qr_strng ="INSERT INTO bio_data (Registration_Number, First_Name, Last_Name, Other_Name, Phone_Number, Email, DOB, Gender, Marital_Status, Nationality, State, LGA, Religion, C_Address, N_First_Name, N_Last_Name, N_Other_Name, N_Phone, N_Email, N_Gender, Relationship, N_C_Address) VALUES ('$Rno','$fname', '$lname', '$oname', '$phNo','$email', '$dob','$gender', '$mstatus', '$nation', '$sta', '$lga', '$religion', '$add', '$nfname', '$nlname', '$noname', '$nphone',  '$nemail', '$ngender', '$nrelation', '$nadd')";
		$qr = mysql_query($qr_strng) or die(mysql_error());
		if($qr){
			echo "opps not transfered";
            }
          header("location:passport.php");    
	}
		
		?>

<!DOCTYPE html>
<html >
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Bio data</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" />
<link href="css/mystyle.css" rel="stylesheet" type="text/css" />
</head>

<body>
<!-!><div class="navbar navbar-fixed-top navbar-default">
	<div class="container">
    	<div class="row">
        	<a href="home.php"><img src="images/mautech.jpe" /></a>
            	<h3>Mautech Portal</h3>
                	<h4>Portal Application</h4>
                    
        </div>
    </div>
</div>


	<!-!>  <div class="navbar navbar-fixed-top navbar-inverse">
  <div class="container" style="margin-top:0px;">
    <div class="navbar-header">
   
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
        </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
      <li><a href="home.php">Home</a></li>
      	<li class="active"><a href="bio_data.php">Bio Data</a></li>
      
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#" style="color:#fff; background-color:transparent; font-weight:bold;"><span class="glyphicon glyphicon-user"></span> Welcome, <?php echo $_SESSION['reg'];?></a></li>
        <li><a href="log_in.php" style="color:#fff; background-color:transparent; font-weight:bold;"><span class="glyphicon glyphicon-log-in"></span> Log Out</a></li>
      </ul>
    </div>
  </div>
</div>
<!-- End Nav -->

<!-- First COntainer -->
<form method="POST" action="" enctype="multipart/form-data">
<div class="container" style="margin-top:160px;">
	<div class="row">
    <!-- Login DIV-->
    <div class="col-lg-offset-2">
    	<div class="col-lg-9">
        	<div class="panel panel-default">
            	<div class="panel-heading">
                	<h3 class="panel-title"><span class="glyphicon glyphicon-user"></span> Bio Data</h3>
                </div>
                <div class="panel-body">
                	<div class="row">
                   
                    	<div class="col-lg-12">
                        	<label>Registration <span style="color:red; font-size:18px">*</span></label>
                            <input type="text" name="Rno" class="form-control" />
                        </div>
                        <div class="col-lg-4">
                        	<label>First Name <span style="color:red; font-size:18px">*</span></label>
                            <input type="text" name="fname" class="form-control" />
                        </div>
                        <div class="col-lg-4">
                        	<label>Last Name <span style="color:red; font-size:18px">*</span></label>
                            <input type="text" name="lname" class="form-control" />
                        </div>
                        <div class="col-lg-4">
                        	<label>Other Name </label>
                            <input type="text" name="oname" class="form-control" />
                            <br />
                        </div>
                        <div class="col-lg-4">
                        	<label>Phone Number <span style="color:red; font-size:18px">*</span></label>
                            <input type="text" name="phNo" class="form-control" />
                        </div>
                        <div class="col-lg-4">
                        	<label>Email Address <span style="color:red; font-size:18px">*</span></label>
                            <input type="text" name="email" class="form-control" placeholder="Enter Your Email Address" />
                        </div>
                        <div class="col-lg-4">
                        	<label>Date of Birth <span style="color:red; font-size:18px">*</span></label>
                            <input type="text" name="dob" class="form-control" placeholder="02-02-2017" />
                            <br />
                        </div>
                        <div class="col-lg-4">
                        	<label>Gender <span style="color:red; font-size:18px">*</span></label>
                            <select class="form-control" name="gen">
                            	<option>[ Select Gender ]</option>
                                <option >Male</option>
                                <option >Female</option>
                            </select>
                        </div>
                        <div class="col-lg-4">
                        	<label>Marital Status <span style="color:red; font-size:18px">*</span></label>
                            <select class="form-control" name="status">
                            	<option>[ Select Marital Status ]</option>
                                <option >Single</option>
                                <option>Married</option>
                                <option>Divorce</option>
                            </select>
                        </div>
                        <div class="col-lg-4">
                        	<label>Nationality <span style="color:red; font-size:18px">*</span></label>
                            <select class="form-control" name="nationality">
                            	<option>[ Select Nationality ]</option>
                                <option  >Nigeria</option>
                                <option >Ghana</option>
                                <option > Cameroon</option>
                            </select>
                            <br />
                        </div>
                        
                        	
      <form method="POST" action="">
 <div class="col-lg-4">
 <label>State of Origin <span style="color:red; font-size:18px">*</span></label>
 
<select id="st" class="form-control" name="sta" onchange="getLocal('st','lg'), getState('st','lg'), getAnam('st','lg'), getAkwa('st','lg'), getBau('st','lg'), getBayl('st','lg'), getBen('st','lg'), getBorn('st','lg'),getCros('st','lg'),getDel('st','lg'), getEbon('st','lg'),getEd('st','lg'),getEk('st','lg'),getEn('st','lg'),getGm('st','lg'),getIm('st','lg'),getJg('st','lg'),getKd('st','lg'),getKn('st','lg'),getAbj('st','lg'),getKt('st','lg'),getKb('st','lg'),getKg('st','lg'),getKw('st','lg'),getLg('st','lg'),getNs('st','lg'),getNg('st','lg'),getOg('st','lg'),getON('st','lg'),getOs('st','lg'),getOy('st','lg'),getPl('st','lg'),getRv('st','lg'),getSk('st','lg'),getTr('st','lg'),getYb('st','lg'),getZm('st','lg')"/ >

</select>
 </div>
 
 <div class="col-lg-4">
<label>L.G.A <span style="color:red; font-size:18px">*</span></label>
 <select id="lg" class="form-control" name="lga">
<option>Select LGA</option>
</select>
 
<script type="text/javascript">

var Astate="";
var stated = new Array("Abia","Adamawa", "Anambara", "Akwa-ibom", "Bauchi","Bayelsa","Benue","Borno", "Cross-River", "Delta", "Ebonyi","Edo","Ekiti","Enugu", "Gombe", "Imo", "Jigawa","Kaduna", "FCT Abuja","Kano","Katsina", "Kebbi", "Kogi", "Kwara","Lagos","Nasrawa","Niger", "Ogun", "Ondo", "Osun","Oyo","Plateau","Rivers", "Sokoto", "Taraba", "Yobe","Zamfara");

for(var i=0; i<stated.length; i++){
Astate = Astate + "<option value="+i+">"+ stated[i]+"</option>";
}
document.getElementById('st').innerHTML=Astate;

function getLocal(sta,lga){
var localga ="";
var selectedstate = document.getElementById(sta).value;
var abiaLga =new Array('Aba North', 'Aba South', 'Arochukwu', 'Bende','Isiala Ngwa South', 'Ikwuano', 'Ngwa North','Isiala', 'Isukwuato', 'Ukwa West', 'Ukwa East','Umuahia','Umuahia South');


if(selectedstate=="0"){
	for(var i=0; i<abiaLga.length; i++){
localga = localga + "<option>"+abiaLga[i]+"</option>";
}
document.getElementById(lga).innerHTML=localga;
}
}
var Adstates="";
var statedd = new Array("Abia","Adamawa", "Anambara", "Akwa-ibom", "Bauchi","Bayelsa","Benue","Borno", "Cross-River", "Delta", "Ebonyi","Edo","Ekiti","Enugu", "Gombe", "Imo", "Jigawa","Kaduna", "FCT Abuja","Kano","Katsina", "Kebbi", "Kogi", "Kwara","Lagos","Nasrawa","Niger", "Ogun", "Ondo", "Osun","Oyo","Plateau","Rivers", "Sokoto", "Taraba", "Yobe","Zamfara");
for(var i=0; i<statedd.length; i++){
Adstates = Adstates + "<option value="+i+">"+ statedd[i]+"</option>";
}
document.getElementById('st').innerHTML=Adstates;

function getState(adsta,adlga){
var localgaa ="";
var selectedstates = document.getElementById(adsta).value;
var adamLga =new Array('Demsa', 'Fufore', 'Ganye','Girei', 'Gombi', 'Jada',' Yola', 'North', 'Lamurde', ' Madagali','Maiha','Mayo-Belwa','Michika', 'Mubi South', 'Numna', 'Shelleng','Song', 'Toungo', 'Jimeta',' Yola South', 'Hung'); 

if(selectedstates=="1"){
	for(var i=0; i<adamLga.length; i++){
localgaa = localgaa + "<option>"+adamLga[i]+"</option>";
}
document.getElementById(adlga).innerHTML=localgaa;
}
} 

var Anastates="";
var statedd = new Array("Abia","Adamawa", "Anambara", "Akwa-ibom", "Bauchi","Bayelsa","Benue","Borno", "Cross-River", "Delta", "Ebonyi","Edo","Ekiti","Enugu", "Gombe", "Imo", "Jigawa","Kaduna", "FCT Abuja","Kano","Katsina", "Kebbi", "Kogi", "Kwara","Lagos","Nasrawa","Niger", "Ogun", "Ondo", "Osun","Oyo","Plateau","Rivers", "Sokoto", "Taraba", "Yobe","Zamfara");
for(var i=0; i<statedd.length; i++){
Anastates = Anastates + "<option value="+i+">"+ statedd[i]+"</option>";
}
document.getElementById('st').innerHTML=Anastates;

function getAnam(anasta,analga){
var analocalga ="";
var selectedanam = document.getElementById(anasta).value;
var anamLga =new Array('Aguata', 'Anambra', 'Anambra West','Anaocha', 'Awka','South', 'Awka North',' Ogbaru', 'Onitsha South', 'Onitsha North', ' Orumba North','Orumba South','Oyi'); 


if(selectedanam=="2"){
	for(var i=0; i<anamLga.length; i++){
analocalga = analocalga + "<option>"+anamLga[i]+"</option>";
}
document.getElementById(analga).innerHTML=analocalga;
}

} 
var Akwstates="";
var statedd = new Array("Abia","Adamawa", "Anambara", "Akwa-ibom", "Bauchi","Bayelsa","Benue","Borno", "Cross-River", "Delta", "Ebonyi","Edo","Ekiti","Enugu", "Gombe", "Imo", "Jigawa","Kaduna", "FCT Abuja","Kano","Katsina", "Kebbi", "Kogi", "Kwara","Lagos","Nasrawa","Niger", "Ogun", "Ondo", "Osun","Oyo","Plateau","Rivers", "Sokoto", "Taraba", "Yobe","Zamfara");
for(var i=0; i<statedd.length; i++){
Akwstates = Akwstates + "<option value="+i+">"+ statedd[i]+"</option>";
}
document.getElementById('st').innerHTML=Akwstates;

function getAkwa(aksta,aklga){
var akwlocalga ="";
var selectedAkw = document.getElementById(aksta).value;
var akwaLga =new Array('Abak', 'Eastern Obolo', 'Eket','Essien', 'Udim', 'Etimekpo',' Etinan', 'Ibeno', 'Ibesikpo Asutan', ' Ibiono Ibom','Ika','Ikono','Ikot Abasi', 'Ikot Ekpene', 'Ini', 'Itu','Mbo', 'Mkpat Enin', 'Nsit Ibom',' Nsit Ubium', 'Obot Akara', ' Okobo','Onna','Orukanam','Oron', 'Udung Uko', 'Ukanafun', 'Esit Eket','Uruan', 'Urue Offoung', 'Oruko Ete',' Uyo'); 

if(selectedAkw=="3"){
	for(var i=0; i<akwaLga.length; i++){
akwlocalga = akwlocalga + "<option>"+akwaLga[i]+"</option>";
}
document.getElementById(aklga).innerHTML=akwlocalga;
}
}

var Baustates="";
var statedd = new Array("Abia","Adamawa", "Anambara", "Akwa-ibom", "Bauchi","Bayelsa","Benue","Borno", "Cross-River", "Delta", "Ebonyi","Edo","Ekiti","Enugu", "Gombe", "Imo", "Jigawa","Kaduna", "FCT Abuja","Kano","Katsina", "Kebbi", "Kogi", "Kwara","Lagos","Nasrawa","Niger", "Ogun", "Ondo", "Osun","Oyo","Plateau","Rivers", "Sokoto", "Taraba", "Yobe","Zamfara");
for(var i=0; i<statedd.length; i++){
Baustates = Baustates + "<option value="+i+">"+ statedd[i]+"</option>";
}
document.getElementById('st').innerHTML=Baustates;

function getBau(basta,balga){
var baulocalga ="";
var selectedBau = document.getElementById(basta).value;
var bauLga =new Array('Alkaleri', 'Bauchi', 'Bogoro','Darazo', 'Dass', 'Gamawa',' Ganjuwa', 'Giade', 'Jama`are', 'Katagum','Kirfi','Misau','Ningi', 'hira', 'Tafawa Balewa', 'Itas gadau','Toro', 'Warji', 'Zaki','Dambam'); 

if(selectedBau=="4"){
	for(var i=0; i<bauLga.length; i++){
baulocalga = baulocalga + "<option>"+bauLga[i]+"</option>";
}
document.getElementById(balga).innerHTML=baulocalga;
}
} 

var Baystates="";
var statedd = new Array("Abia","Adamawa", "Anambara", "Akwa-ibom", "Bauchi","Bayelsa","Benue","Borno", "Cross-River", "Delta", "Ebonyi","Edo","Ekiti","Enugu", "Gombe", "Imo", "Jigawa","Kaduna", "FCT Abuja","Kano","Katsina", "Kebbi", "Kogi", "Kwara","Lagos","Nasrawa","Niger", "Ogun", "Ondo", "Osun","Oyo","Plateau","Rivers", "Sokoto", "Taraba", "Yobe","Zamfara");
for(var i=0; i<statedd.length; i++){
Baystates = Baystates + "<option value="+i+">"+ statedd[i]+"</option>";
}
document.getElementById('st').innerHTML=Baystates;

function getBayl(baysta,baylga){
var baylocalga ="";
var selectedBay = document.getElementById(baysta).value;
var baylLga =new Array('Brass', 'Ekeremor', 'Kolok/Opokuma','Nembe', 'Ogbia', 'Sagbama',' Southern Ijaw', 'Yenagoa', 'Membe'); 

if(selectedBay=="5"){
	for(var i=0; i<baylLga.length; i++){
baylocalga = baylocalga + "<option>"+baylLga[i]+"</option>";
}
document.getElementById(baylga).innerHTML=baylocalga;
}
} 

var Benstates="";
var statedd = new Array("Abia","Adamawa", "Anambara", "Akwa-ibom", "Bauchi","Bayelsa","Benue","Borno", "Cross-River", "Delta", "Ebonyi","Edo","Ekiti","Enugu", "Gombe", "Imo", "Jigawa","Kaduna", "FCT Abuja","Kano","Katsina", "Kebbi", "Kogi", "Kwara","Lagos","Nasrawa","Niger", "Ogun", "Ondo", "Osun","Oyo","Plateau","Rivers", "Sokoto", "Taraba", "Yobe","Zamfara");
for(var i=0; i<statedd.length; i++){
Benstates = Benstates + "<option value="+i+">"+ statedd[i]+"</option>";
}
document.getElementById('st').innerHTML=Benstates;

function getBen(bensta,benulga){
var benlocalga ="";
var selectedBen = document.getElementById(bensta).value;
var benLga =new Array('Ador', 'Agatu', 'Apa','Buruku', 'Gboko', 'Guma',' Gwer east', 'Gwer west', 'Kastina-ala','Konshisha', 'Kwande', 'Logo','Makurdii', 'Obi', 'Ogbadibo',' Ohimini', 'Oju', 'Okpokwu','Oturkpo', 'Tarka',' Ukum', 'Vandekya'); 

if(selectedBen=="6"){
	for(var i=0; i<benLga.length; i++){
benlocalga = benlocalga + "<option>"+benLga[i]+"</option>";
}
document.getElementById(benulga).innerHTML=benlocalga;
}
} 


var Borstates="";
var statedd = new Array("Abia","Adamawa", "Anambara", "Akwa-ibom", "Bauchi","Bayelsa","Benue","Borno", "Cross-River", "Delta", "Ebonyi","Edo","Ekiti","Enugu", "Gombe", "Imo", "Jigawa","Kaduna", "FCT Abuja","Kano","Katsina", "Kebbi", "Kogi", "Kwara","Lagos","Nasrawa","Niger", "Ogun", "Ondo", "Osun","Oyo","Plateau","Rivers", "Sokoto", "Taraba", "Yobe","Zamfara");
for(var i=0; i<statedd.length; i++){
Borstates = Borstates + "<option value="+i+">"+ statedd[i]+"</option>";
}
document.getElementById('st').innerHTML=Borstates;

function getBorn(borsta,borlga){
var borlocalga ="";
var selectedBorn = document.getElementById(borsta).value;
var bornLga =new Array('Abadan', 'Askira/Uba', 'Bama','Bayo', 'Biu', 'Chibok','Damboa', 'Dikwagubio', 'Guzamala','Gwoza', 'Hawul', 'Jere','Kaga', 'Kalka/Balge', 'Konduga',' Kukawa', 'Kwaya-ku', 'Mafa','Ngala', 'Nganzai',' Shani'); 

if(selectedBorn=="7"){
	for(var i=0; i<bornLga.length; i++){
borlocalga = borlocalga + "<option>"+bornLga[i]+"</option>";
}
document.getElementById(borlga).innerHTML=borlocalga;
}
} 

var Crostates="";
var statedd = new Array("Abia","Adamawa", "Anambara", "Akwa-ibom", "Bauchi","Bayelsa","Benue","Borno", "Cross-River", "Delta", "Ebonyi","Edo","Ekiti","Enugu", "Gombe", "Imo", "Jigawa","Kaduna", "FCT Abuja","Kano","Katsina", "Kebbi", "Kogi", "Kwara","Lagos","Nasrawa","Niger", "Ogun", "Ondo", "Osun","Oyo","Plateau","Rivers", "Sokoto", "Taraba", "Yobe","Zamfara");
for(var i=0; i<statedd.length; i++){
Crostates = Crostates + "<option value="+i+">"+ statedd[i]+"</option>";
}
document.getElementById('st').innerHTML=Crostates;

function getCros(crosta,crolga){
var Crolocalga ="";
var selectedCro = document.getElementById(crosta).value;
var CrosnLga =new Array('Abia', 'Akampa', 'Akpabuyo','Bakassi', 'Bekwara', 'Biase','Boki', 'Calabar south', 'Etung','Ikom', 'Obanliku', 'Obubra','Obudu', 'Odukpani', 'Ogoja',' Ugep north', 'Yala', 'Yarkur'); 

if(selectedCro=="8"){
	for(var i=0; i<CrosnLga.length; i++){
Crolocalga = Crolocalga + "<option>"+CrosnLga[i]+"</option>";
}
document.getElementById(crolga).innerHTML=Crolocalga;
}
}

var Delstates="";
var statedd = new Array("Abia","Adamawa", "Anambara", "Akwa-ibom", "Bauchi","Bayelsa","Benue","Borno", "Cross-River", "Delta", "Ebonyi","Edo","Ekiti","Enugu", "Gombe", "Imo", "Jigawa","Kaduna", "FCT Abuja","Kano","Katsina", "Kebbi", "Kogi", "Kwara","Lagos","Nasrawa","Niger", "Ogun", "Ondo", "Osun","Oyo","Plateau","Rivers", "Sokoto", "Taraba", "Yobe","Zamfara");
for(var i=0; i<statedd.length; i++){
Delstates = Delstates + "<option value="+i+">"+ statedd[i]+"</option>";
}
document.getElementById('st').innerHTML=Delstates;

function getDel(delsta,dellga){
var Dellocalga ="";
var selectedDel = document.getElementById(delsta).value;
var DeltLga =new Array('Aniocha south', 'Isoko south', 'Isoko north','Ndokwa east', 'Ndokwa west', 'Okpe','Oshimili north', ' Oshimili south', 'Patani','Sapele', 'Udu', 'Ughelli south','Ughelli north','Ukwuani','Uviwie','Warri central', 'Warri south'); 

if(selectedDel=="9"){
	for(var i=0; i<DeltLga.length; i++){
Dellocalga = Dellocalga + "<option>"+DeltLga[i]+"</option>";
}
document.getElementById(dellga).innerHTML=Dellocalga;
}
}

var Ebontates="";
var statedd = new Array("Abia","Adamawa", "Anambara", "Akwa-ibom", "Bauchi","Bayelsa","Benue","Borno", "Cross-River", "Delta", "Ebonyi","Edo","Ekiti","Enugu", "Gombe", "Imo", "Jigawa","Kaduna", "FCT Abuja","Kano","Katsina", "Kebbi", "Kogi", "Kwara","Lagos","Nasrawa","Niger", "Ogun", "Ondo", "Osun","Oyo","Plateau","Rivers", "Sokoto", "Taraba", "Yobe","Zamfara");
for(var i=0; i<statedd.length; i++){
Ebontates = Ebontates + "<option value="+i+">"+ statedd[i]+"</option>";
}
document.getElementById('st').innerHTML=Ebontates;

function getEbon(ebonsta,ebolga){
var Ebonlocalga ="";
var selectedEbon = document.getElementById(ebonsta).value;
var EbontLga =new Array('Abakaliki', 'Afikpo south', 'Afikpo north','Ebonyi', 'Ezza', 'Ezza south','Ikwo', ' Ishielu', 'Ivo','Ohaozara', 'Ohaukwu', 'Onicha','Izzi'); 

if(selectedEbon=="10"){
	for(var i=0; i<EbontLga.length; i++){
Ebonlocalga = Ebonlocalga + "<option>"+EbontLga[i]+"</option>";
}
document.getElementById(ebolga).innerHTML=Ebonlocalga;
}
}

var EdStates="";
var statedd = new Array("Abia","Adamawa", "Anambara", "Akwa-ibom", "Bauchi","Bayelsa","Benue","Borno", "Cross-River", "Delta", "Ebonyi","Edo","Ekiti","Enugu", "Gombe", "Imo", "Jigawa","Kaduna", "FCT Abuja","Kano","Katsina", "Kebbi", "Kogi", "Kwara","Lagos","Nasrawa","Niger", "Ogun", "Ondo", "Osun","Oyo","Plateau","Rivers", "Sokoto", "Taraba", "Yobe","Zamfara");
for(var i=0; i<statedd.length; i++){
EdStates = EdStates + "<option value="+i+">"+ statedd[i]+"</option>";
}
document.getElementById('st').innerHTML=EdStates;

function getEd(edsta,edlga){
var Edlocalga ="";
var selectedEdo = document.getElementById(edsta).value;
var EdotLga =new Array('Akoko-Edo', 'Egor', 'Essann east','Esan south east', 'Esan central', 'Esan west','Etsako central', ' Etsako east', 'Etsako','Orhionwon', 'Ivia north', 'Ovia south west','Owan west', ' Owan south','Uhunwonde'); 

if(selectedEdo=="11"){
	for(var i=0; i<EdotLga.length; i++){
Edlocalga = Edlocalga + "<option>"+EdotLga[i]+"</option>";
}
document.getElementById(edlga).innerHTML=Edlocalga;
}
}

var EkStates="";
var statedd = new Array("Abia","Adamawa", "Anambara", "Akwa-ibom", "Bauchi","Bayelsa","Benue","Borno", "Cross-River", "Delta", "Ebonyi","Edo","Ekiti","Enugu", "Gombe", "Imo", "Jigawa","Kaduna", "FCT Abuja","Kano","Katsina", "Kebbi", "Kogi", "Kwara","Lagos","Nasrawa","Niger", "Ogun", "Ondo", "Osun","Oyo","Plateau","Rivers", "Sokoto", "Taraba", "Yobe","Zamfara");
for(var i=0; i<statedd.length; i++){
EkStates = EkStates + "<option value="+i+">"+ statedd[i]+"</option>";
}
document.getElementById('st').innerHTML=EkStates;

function getEk(eksta,eklga){
var Eklocalga ="";
var selectedEki = document.getElementById(eksta).value;
var EkitLga =new Array('Ado Ekiti', ' Effon Alaiye', 'Ekiti south west','Ekiti west', 'Ekiti east', 'Emure/ise','Orun', ' Ido', 'Osi','Ijero', 'Ikere', 'Ikole','Ilejemeje', ' Irepodun','Ise/Orun','Moba', ' Oye','Aiyekire'); 

if(selectedEki=="12"){
	for(var i=0; i<EkitLga.length; i++){
Eklocalga = Eklocalga + "<option>"+EkitLga[i]+"</option>";
}
document.getElementById(eklga).innerHTML=Eklocalga;
}
}

var EnuStates="";
var statedd = new Array("Abia","Adamawa", "Anambara", "Akwa-ibom", "Bauchi","Bayelsa","Benue","Borno", "Cross-River", "Delta", "Ebonyi","Edo","Ekiti","Enugu", "Gombe", "Imo", "Jigawa","Kaduna", "FCT Abuja","Kano","Katsina", "Kebbi", "Kogi", "Kwara","Lagos","Nasrawa","Niger", "Ogun", "Ondo", "Osun","Oyo","Plateau","Rivers", "Sokoto", "Taraba", "Yobe","Zamfara");
for(var i=0; i<statedd.length; i++){
EnuStates = EnuStates + "<option value="+i+">"+ statedd[i]+"</option>";
}
document.getElementById('st').innerHTML=EnuStates;

function getEn(ensta,enlga){
var Enlocalga ="";
var selectedEki = document.getElementById(ensta).value;
var EnuLga =new Array('Awgu', ' Aninri', 'Enugu east','Enugu south', 'Enugu north', 'Ezeagu','Igbo Eze north', ' Igbi etiti', 'Nsukka','Oji river', 'Undenu', 'Uzo Uwani','Udi'); 

if(selectedEki=="13"){
	for(var i=0; i<EnuLga.length; i++){
Enlocalga = Enlocalga + "<option>"+EnuLga[i]+"</option>";
}
document.getElementById(enlga).innerHTML=Enlocalga;
}
}

var GmStates="";
var statedd = new Array("Abia","Adamawa", "Anambara", "Akwa-ibom", "Bauchi","Bayelsa","Benue","Borno", "Cross-River", "Delta", "Ebonyi","Edo","Ekiti","Enugu", "Gombe", "Imo", "Jigawa","Kaduna", "FCT Abuja","Kano","Katsina", "Kebbi", "Kogi", "Kwara","Lagos","Nasrawa","Niger", "Ogun", "Ondo", "Osun","Oyo","Plateau","Rivers", "Sokoto", "Taraba", "Yobe","Zamfara");
for(var i=0; i<statedd.length; i++){
GmStates = GmStates + "<option value="+i+">"+ statedd[i]+"</option>";
}
document.getElementById('st').innerHTML=GmStates;

function getGm(gmsta,gmlga){
var Gomlocalga ="";
var selectedGm = document.getElementById(gmsta).value;
var GomLga =new Array('Akko', ' Balanga', 'Billiri','Dukku', 'Funakaye', 'Gombe','Kaltungo', ' Kwami', 'Nafada/Bajoga','Shomgom', 'Yamaltu/Deba'); 

if(selectedGm=="14"){
	for(var i=0; i<GomLga.length; i++){
Gomlocalga = Gomlocalga + "<option>"+GomLga[i]+"</option>";
}
document.getElementById(gmlga).innerHTML=Gomlocalga;
}
}

var ImStates="";
var statedd = new Array("Abia","Adamawa", "Anambara", "Akwa-ibom", "Bauchi","Bayelsa","Benue","Borno", "Cross-River", "Delta", "Ebonyi","Edo","Ekiti","Enugu", "Gombe", "Imo", "Jigawa","Kaduna", "FCT Abuja","Kano","Katsina", "Kebbi", "Kogi", "Kwara","Lagos","Nasrawa","Niger", "Ogun", "Ondo", "Osun","Oyo","Plateau","Rivers", "Sokoto", "Taraba", "Yobe","Zamfara");
for(var i=0; i<statedd.length; i++){
ImStates = ImStates + "<option value="+i+">"+ statedd[i]+"</option>";
}
document.getElementById('st').innerHTML=ImStates;

function getIm(imsta,imlga){
var Imlocalga ="";
var selectedImo = document.getElementById(imsta).value;
var ImoLga =new Array('Aboh-mbaise', ' Ahiazu-Mbaise', 'Ehime-Mbaino','Ezinhite', 'Ideato North', 'Ideato south','Ihitte/Uboma', ' Ikeduru', 'Isiala','Isu', 'Mbaitoli','Ngor Okpala',' Njaba', 'Nwangele','Nkwere', 'Obowo', 'Aguta','Ohaji Egbema', ' Okigwe', 'Onuimo','Orlu', 'Orsu','Oru west', ' Oru', 'Owerri','Owerri North', 'Owerri south'); 

if(selectedImo=="15"){
	for(var i=0; i<ImoLga.length; i++){
Imlocalga = Imlocalga + "<option>"+ImoLga[i]+"</option>";
}
document.getElementById(imlga).innerHTML=Imlocalga;
}
}

var JgStates="";
var statedd = new Array("Abia","Adamawa", "Anambara", "Akwa-ibom", "Bauchi","Bayelsa","Benue","Borno", "Cross-River", "Delta", "Ebonyi","Edo","Ekiti","Enugu", "Gombe", "Imo", "Jigawa","Kaduna", "FCT Abuja","Kano","Katsina", "Kebbi", "Kogi", "Kwara","Lagos","Nasrawa","Niger", "Ogun", "Ondo", "Osun","Oyo","Plateau","Rivers", "Sokoto", "Taraba", "Yobe","Zamfara");
for(var i=0; i<statedd.length; i++){
JgStates = JgStates + "<option value="+i+">"+ statedd[i]+"</option>";
}
document.getElementById('st').innerHTML=JgStates;

function getJg(jgsta,jglga){
var Jglocalga ="";
var selectedJig = document.getElementById(jgsta).value;
var JigLga =new Array('Auyo','Babura', 'Birnin- Kudu','Birniwa', 'Buji', 'Dute','Garki', ' Gagarawa', 'Gumel','Guri', 'Gwaram','Gwiwa',' Hadeji', 'Jahun','Kafin-Hausa', 'kaugama', 'Kazaure','Kirikisamma', ' Birnin-magaji', 'Maigatari','Malamaduri', 'Miga','Ringim', ' Roni', 'Sule Tankarka','Taura', 'Yankwasi'); 

if(selectedJig=="16"){
	for(var i=0; i<JigLga.length; i++){
Jglocalga = Jglocalga + "<option>"+JigLga[i]+"</option>";
}
document.getElementById(jglga).innerHTML=Jglocalga;
}
}

var KdStates="";
var statedd = new Array("Abia","Adamawa", "Anambara", "Akwa-ibom", "Bauchi","Bayelsa","Benue","Borno", "Cross-River", "Delta", "Ebonyi","Edo","Ekiti","Enugu", "Gombe", "Imo", "Jigawa","Kaduna", "FCT Abuja","Kano","Katsina", "Kebbi", "Kogi", "Kwara","Lagos","Nasrawa","Niger", "Ogun", "Ondo", "Osun","Oyo","Plateau","Rivers", "Sokoto", "Taraba", "Yobe","Zamfara");
for(var i=0; i<statedd.length; i++){
KdStates = KdStates + "<option value="+i+">"+ statedd[i]+"</option>";
}
document.getElementById('st').innerHTML=KdStates;
function getKd(kdsta,kdlga){
var Kdlocalga ="";
var selectedkd = document.getElementById(kdsta).value;
var KadLga =new Array('Brnin Gwari','Chukun', 'Giwa','Kajuru', 'Igabi', 'Ikara','Jaba', ' Jema`a', 'Kachia','Kaduna North', 'Kaduna south','Kagarok',' Kauru', 'Kabau','Kudan', 'Kere', 'Makarfi','Sabongari', ' Sanga', 'Soba','Zangon-Kataf'); 
if(selectedkd=="17"){
	for(var i=0; i<KadLga.length; i++){
Kdlocalga = Kdlocalga + "<option>"+KadLga[i]+"</option>";
}
document.getElementById(kdlga).innerHTML=Kdlocalga;
}
}

var AbjStates="";
var statedd = new Array("Abia","Adamawa", "Anambara", "Akwa-ibom", "Bauchi","Bayelsa","Benue","Borno", "Cross-River", "Delta", "Ebonyi","Edo","Ekiti","Enugu", "Gombe", "Imo", "Jigawa","Kaduna", "FCT Abuja","Kano","Katsina", "Kebbi", "Kogi", "Kwara","Lagos","Nasrawa","Niger", "Ogun", "Ondo", "Osun","Oyo","Plateau","Rivers", "Sokoto", "Taraba", "Yobe","Zamfara");
for(var i=0; i<statedd.length; i++){
AbjStates = AbjStates + "<option value="+i+">"+ statedd[i]+"</option>";
}
document.getElementById('st').innerHTML=AbjStates;

function getAbj(absta,ablga){
var Abjlocalga ="";
var selectedAbj = document.getElementById(absta).value;
var AbjLga =new Array('Abaji',' Abuja Municipal', 'Bwari','Gwagwalada', 'Kuje', 'Kwali'); 

if(selectedAbj=="18"){
	for(var i=0; i<AbjLga.length; i++){
Abjlocalga = Abjlocalga + "<option>"+AbjLga[i]+"</option>";
}
document.getElementById(ablga).innerHTML=Abjlocalga;
}
}

var KnStates="";
var statedd = new Array("Abia","Adamawa", "Anambara", "Akwa-ibom", "Bauchi","Bayelsa","Benue","Borno", "Cross-River", "Delta", "Ebonyi","Edo","Ekiti","Enugu", "Gombe", "Imo", "Jigawa","Kaduna", "FCT Abuja","Kano","Katsina", "Kebbi", "Kogi", "Kwara","Lagos","Nasrawa","Niger", "Ogun", "Ondo", "Osun","Oyo","Plateau","Rivers", "Sokoto", "Taraba", "Yobe","Zamfara");
for(var i=0; i<statedd.length; i++){
KnStates = KnStates + "<option value="+i+">"+ statedd[i]+"</option>";
}
document.getElementById('st').innerHTML=KnStates;

function getKn(knsta,knlga){
var Knlocalga ="";
var selectedkn = document.getElementById(knsta).value;
var KanLga =new Array('Ajigi','Albasu', 'Bagwai','Bebeji', 'Bichi', 'Bunkure','Dala', ' Dambatta', 'Dawakin kudu','Dawakin tofa', 'Doguwa','Fagge',' Gabasawa', 'Garko','Garun mallam', 'Gaya', 'Gezawa','Gwale', ' Gwarzo', 'Kano','Karay','Kibiya','Kiru', 'Kumbtso','Kunch', 'Kura', 'Maidobi','Makoda', ' Minjibir Nassarawa', 'Rano','Rimin gado', 'Rogo','Shanono',' Sumaila', 'Takai','Tarauni', 'Tofa', 'Tsanyawa','Tudunwada', ' Ungogo', 'Warawa','Wudil'); 

if(selectedkn=="19"){
	for(var i=0; i<KanLga.length; i++){
Knlocalga = Knlocalga + "<option>"+KanLga[i]+"</option>";
}
document.getElementById(knlga).innerHTML=Knlocalga;
}
}

var KtStates="";
var statedd = new Array("Abia","Adamawa", "Anambara", "Akwa-ibom", "Bauchi","Bayelsa","Benue","Borno", "Cross-River", "Delta", "Ebonyi","Edo","Ekiti","Enugu", "Gombe", "Imo", "Jigawa","Kaduna", "FCT Abuja","Kano","Katsina", "Kebbi", "Kogi", "Kwara","Lagos","Nasrawa","Niger", "Ogun", "Ondo", "Osun","Oyo","Plateau","Rivers", "Sokoto", "Taraba", "Yobe","Zamfara");
for(var i=0; i<statedd.length; i++){
KtStates = KtStates + "<option value="+i+">"+ statedd[i]+"</option>";
}
document.getElementById('st').innerHTML=KtStates;

function getKt(ktsta,ktlga){
var Ktlocalga ="";
var selectedKt = document.getElementById(ktsta).value;
var KatLga =new Array('Bakori','Batagarawa', 'Batsari','Baure', 'Bindawa', 'Charanchi','Dan- Musa', ' Dandume', 'Danja','Daura', 'Dutsi','Dutsin `ma',' Faskar', 'Funtua','Ingawa', 'Jibiya', 'Kafur','Kaita', ' Kankara', 'Kankiya','Katsina','Furfi','Kusada', 'Mai aduwa','Malumfashi', 'Mani', 'Mash','Matazu', ' Musawa', 'Rimi','Sabuwa', 'Safana','Sandamu',' Zango'); 

if(selectedKt=="20"){
	for(var i=0; i<KatLga.length; i++){
Ktlocalga = Ktlocalga + "<option>"+KatLga[i]+"</option>";
}
document.getElementById(ktlga).innerHTML=Ktlocalga;
}
}

var KbStates="";
var statedd = new Array("Abia","Adamawa", "Anambara", "Akwa-ibom", "Bauchi","Bayelsa","Benue","Borno", "Cross-River", "Delta", "Ebonyi","Edo","Ekiti","Enugu", "Gombe", "Imo", "Jigawa","Kaduna", "FCT Abuja","Kano","Katsina", "Kebbi", "Kogi", "Kwara","Lagos","Nasrawa","Niger", "Ogun", "Ondo", "Osun","Oyo","Plateau","Rivers", "Sokoto", "Taraba", "Yobe","Zamfara");
for(var i=0; i<statedd.length; i++){
KbStates = KbStates + "<option value="+i+">"+ statedd[i]+"</option>";
}
document.getElementById('st').innerHTML=KbStates;

function getKb(kbsta,kblga){
var Kblocalga ="";
var selectedKb = document.getElementById(kbsta).value;
var KebLga =new Array('Aliero','Arewa Dandi', 'Argungu','Augie', 'Bagudo', 'Birnin Kebbi','Bunza', ' Dandi', 'Danko','Fakai', 'Gwandu','Jeda',' Kalgo', 'Koko-besse','Maiyaama', 'Ngaski', 'Sakaba','Shanga', ' Suru', 'Wasugu','Yauri','Zuru'); 

if(selectedKb=="21"){
	for(var i=0; i<KebLga.length; i++){
Kblocalga = Kblocalga + "<option>"+KebLga[i]+"</option>";
}
document.getElementById(kblga).innerHTML=Kblocalga;
}
}

var KgStates="";
var statedd = new Array("Abia","Adamawa", "Anambara", "Akwa-ibom", "Bauchi","Bayelsa","Benue","Borno", "Cross-River", "Delta", "Ebonyi","Edo","Ekiti","Enugu", "Gombe", "Imo", "Jigawa","Kaduna", "FCT Abuja","Kano","Katsina", "Kebbi", "Kogi", "Kwara","Lagos","Nasrawa","Niger", "Ogun", "Ondo", "Osun","Oyo","Plateau","Rivers", "Sokoto", "Taraba", "Yobe","Zamfara");
for(var i=0; i<statedd.length; i++){
KgStates = KgStates + "<option value="+i+">"+ statedd[i]+"</option>";
}
document.getElementById('st').innerHTML=KgStates;

function getKg(kgsta,kglga){
var Kglocalga ="";
var selectedKg = document.getElementById(kgsta).value;
var KogbLga =new Array('Adavi','Ajaokuta', 'Ankpa','Bassa', 'Dekina', 'Yagba east','Ibaji', ' Idah', 'Igalamela','Ijumu', 'Kabba bunu','Kogi',' Mopa muro', 'Ofu','Ogori magongo', 'Okehi', 'Okene','Olamaboro', ' Omala', 'Yagba west'); 

if(selectedKg=="22"){
	for(var i=0; i<KogbLga.length; i++){
Kglocalga = Kglocalga + "<option>"+KogbLga[i]+"</option>";
}
document.getElementById(kglga).innerHTML=Kglocalga;
}
}

var KwStates="";
var statedd = new Array("Abia","Adamawa", "Anambara", "Akwa-ibom", "Bauchi","Bayelsa","Benue","Borno", "Cross-River", "Delta", "Ebonyi","Edo","Ekiti","Enugu", "Gombe", "Imo", "Jigawa","Kaduna", "FCT Abuja","Kano","Katsina", "Kebbi", "Kogi", "Kwara","Lagos","Nasrawa","Niger", "Ogun", "Ondo", "Osun","Oyo","Plateau","Rivers", "Sokoto", "Taraba", "Yobe","Zamfara");
for(var i=0; i<statedd.length; i++){
KwStates = KwStates + "<option value="+i+">"+ statedd[i]+"</option>";
}
document.getElementById('st').innerHTML=KwStates;

function getKw(kwsta,kwlga){
var Kwlocalga ="";
var selectedKw = document.getElementById(kwsta).value;
var KwaLga =new Array('Asa','Baruten', 'Ede','Ekiti', 'Ifelodun', 'Ilorin south','Ilorin west', ' Ilorin east', 'Irepodun','Isin', 'Kaiama','Moro',' Offa', 'Oke ero','Oyun', 'Pategi'); 

if(selectedKw=="23"){
	for(var i=0; i<KwaLga.length; i++){
Kwlocalga = Kwlocalga + "<option>"+KwaLga[i]+"</option>";
}
document.getElementById(kwlga).innerHTML=Kwlocalga;
}
}

var LgStates="";
var statedd = new Array("Abia","Adamawa", "Anambara", "Akwa-ibom", "Bauchi","Bayelsa","Benue","Borno", "Cross-River", "Delta", "Ebonyi","Edo","Ekiti","Enugu", "Gombe", "Imo", "Jigawa","Kaduna", "FCT Abuja","Kano","Katsina", "Kebbi", "Kogi", "Kwara","Lagos","Nasrawa","Niger", "Ogun", "Ondo", "Osun","Oyo","Plateau","Rivers", "Sokoto", "Taraba", "Yobe","Zamfara");
for(var i=0; i<statedd.length; i++){
LgStates = LgStates + "<option value="+i+">"+ statedd[i]+"</option>";
}
document.getElementById('st').innerHTML=LgStates;

function getLg(lgsta,lglga){
var lglocalga ="";
var selectedLg = document.getElementById(lgsta).value;
var lagLga =new Array('Agege','Alimosho Ifelodun', 'Alimosho','Amuwo-Odofin', 'Ifelodun', 'Apapa', ' Badagry', 'Epe','Eti-Osa', 'Ibeju-Lekki','Ifako/Ijaye',' Ikeja', 'Ikorodu','Kosofe', 'Lagos Island', 'Lagos Mainland','Mushin',' Ojo', 'Oshodi -Isolo','Shomolu', 'Surulere'); 

if(selectedLg=="24"){
	for(var i=0; i<lagLga.length; i++){
lglocalga = lglocalga + "<option>"+lagLga[i]+"</option>";
}
document.getElementById(lglga).innerHTML=lglocalga;
}
}

var NsStates="";
var statedd = new Array("Abia","Adamawa", "Anambara", "Akwa-ibom", "Bauchi","Bayelsa","Benue","Borno", "Cross-River", "Delta", "Ebonyi","Edo","Ekiti","Enugu", "Gombe", "Imo", "Jigawa","Kaduna", "FCT Abuja","Kano","Katsina", "Kebbi", "Kogi", "Kwara","Lagos","Nasrawa","Niger", "Ogun", "Ondo", "Osun","Oyo","Plateau","Rivers", "Sokoto", "Taraba", "Yobe","Zamfara");
for(var i=0; i<statedd.length; i++){
NsStates = NsStates + "<option value="+i+">"+ statedd[i]+"</option>";
}
document.getElementById('st').innerHTML=NsStates;

function getNs(nssta,nslga){
var nslocalga ="";
var selectedNs = document.getElementById(nssta).value;
var NasLga =new Array('Akwanga','Awe', 'Doma','Karu', 'Keana', 'Keffi', ' Kokona', 'Lafia','Nassarawa', 'Nassarawa/Eggon','Obi',' Toto', 'Wamba'); 

if(selectedNs=="25"){
	for(var i=0; i<NasLga.length; i++){
nslocalga = nslocalga + "<option>"+NasLga[i]+"</option>";
}
document.getElementById(nslga).innerHTML=nslocalga;
}
}

var NgStates="";
var statedd = new Array("Abia","Adamawa", "Anambara", "Akwa-ibom", "Bauchi","Bayelsa","Benue","Borno", "Cross-River", "Delta", "Ebonyi","Edo","Ekiti","Enugu", "Gombe", "Imo", "Jigawa","Kaduna", "FCT Abuja","Kano","Katsina", "Kebbi", "Kogi", "Kwara","Lagos","Nasrawa","Niger", "Ogun", "Ondo", "Osun","Oyo","Plateau","Rivers", "Sokoto", "Taraba", "Yobe","Zamfara");
for(var i=0; i<statedd.length; i++){
NgStates = NgStates + "<option value="+i+">"+ statedd[i]+"</option>";
}
document.getElementById('st').innerHTML=NgStates;

function getNg(ngsta,nglga){
var nglocalga ="";
var selectedNg = document.getElementById(ngsta).value;
var NgsLga =new Array('Agaie','Agwara', 'Bida','Borgu', 'Bosso', 'Chanchanga', ' Edati', 'Gbako','Gurara', 'Kitcha','Kontagora',' Lapai', 'Lavun','Magama', 'Mokwa','Moshegu',' Muya'); 

if(selectedNg=="26"){
	for(var i=0; i<NgsLga.length; i++){
nglocalga = nglocalga + "<option>"+NgsLga[i]+"</option>";
}
document.getElementById(nglga).innerHTML=nglocalga;
}
}

var OgStates="";
var statedd = new Array("Abia","Adamawa", "Anambara", "Akwa-ibom", "Bauchi","Bayelsa","Benue","Borno", "Cross-River", "Delta", "Ebonyi","Edo","Ekiti","Enugu", "Gombe", "Imo", "Jigawa","Kaduna", "FCT Abuja","Kano","Katsina", "Kebbi", "Kogi", "Kwara","Lagos","Nasrawa","Niger", "Ogun", "Ondo", "Osun","Oyo","Plateau","Rivers", "Sokoto", "Taraba", "Yobe","Zamfara");
for(var i=0; i<statedd.length; i++){
OgStates = OgStates + "<option value="+i+">"+ statedd[i]+"</option>";
}
document.getElementById('st').innerHTML=OgStates;

function getOg(ogsta,oglga){
var oglocalga ="";
var selectedOg = document.getElementById(ogsta).value;
var NgsLga =new Array('Abeokuta south','Abeokuta north', 'Ado-odo/otta','Agbado south', 'Agbado north', 'Ewekoro', ' Idarapo', 'Ifo','Ijebu east', 'Ijebu north','Ikenne',' Ilugun Alaro', 'Imeko afon','Ipokia', 'Obafemi/owode','Odeda',' Muya','Ogun waterside',' Sagamu'); 

if(selectedOg=="27"){
	for(var i=0; i<NgsLga.length; i++){
oglocalga = oglocalga + "<option>"+NgsLga[i]+"</option>";
}
document.getElementById(oglga).innerHTML=oglocalga;
}
}

var OnStates="";
var statedd = new Array("Abia","Adamawa", "Anambara", "Akwa-ibom", "Bauchi","Bayelsa","Benue","Borno", "Cross-River", "Delta", "Ebonyi","Edo","Ekiti","Enugu", "Gombe", "Imo", "Jigawa","Kaduna", "FCT Abuja","Kano","Katsina", "Kebbi", "Kogi", "Kwara","Lagos","Nasrawa","Niger", "Ogun", "Ondo", "Osun","Oyo","Plateau","Rivers", "Sokoto", "Taraba", "Yobe","Zamfara");
for(var i=0; i<statedd.length; i++){
OnStates = OnStates + "<option value="+i+">"+ statedd[i]+"</option>";
}
document.getElementById('st').innerHTML=OnStates;

function getON(onsta,onlga){
var onlocalga ="";
var selectedOn = document.getElementById(onsta).value;
var OndsLga =new Array('Akoko north','Akoko north east', 'Akoko south east','Akoko south', 'Akure north', 'Akure', ' Idanre', 'Ifedore','Ese odo', 'Ilaje','Ilaje oke-igbo',' Irele', 'Odigbo','Okitipupa', 'Ondo','Ondo east',' Ose','Owo'); 

if(selectedOn=="28"){
	for(var i=0; i<OndsLga.length; i++){
onlocalga = onlocalga + "<option>"+OndsLga[i]+"</option>";
}
document.getElementById(onlga).innerHTML=onlocalga;
}
}

var OsStates="";
var statedd = new Array("Abia","Adamawa", "Anambara", "Akwa-ibom", "Bauchi","Bayelsa","Benue","Borno", "Cross-River", "Delta", "Ebonyi","Edo","Ekiti","Enugu", "Gombe", "Imo", "Jigawa","Kaduna", "FCT Abuja","Kano","Katsina", "Kebbi", "Kogi", "Kwara","Lagos","Nasrawa","Niger", "Ogun", "Ondo", "Osun","Oyo","Plateau","Rivers", "Sokoto", "Taraba", "Yobe","Zamfara");
for(var i=0; i<statedd.length; i++){
OsStates = OsStates + "<option value="+i+">"+ statedd[i]+"</option>";
}
document.getElementById('st').innerHTML=OsStates;

function getOs(ossta,oslga){
var oslocalga ="";
var selectedOs = document.getElementById(ossta).value;
var OndsLga =new Array('Atakumosa west','Atakumosa east', 'Ayeda-ade','Ayedire', 'Bolawaduro', 'Boripe', ' Ede', 'Ede north','Egbedore', 'Ejigbo','Ife north',' Ife central', 'Ife south','Ife east', 'Ifedayo','Ifelodun',' Ilesha west','Ila-orangun','Ilesah east','Irepodun', 'Irewole','Isokan', 'Iwo', 'Obokun', ' Odo-otin', 'ola oluwa','olorunda', 'Oriade','Orolu',' Osogbo'); 

if(selectedOs=="29"){
	for(var i=0; i<OndsLga.length; i++){
oslocalga = oslocalga + "<option>"+OndsLga[i]+"</option>";
}
document.getElementById(oslga).innerHTML=oslocalga;
}
}

var OyStates="";
var statedd = new Array("Abia","Adamawa", "Anambara", "Akwa-ibom", "Bauchi","Bayelsa","Benue","Borno", "Cross-River", "Delta", "Ebonyi","Edo","Ekiti","Enugu", "Gombe", "Imo", "Jigawa","Kaduna", "FCT Abuja","Kano","Katsina", "Kebbi", "Kogi", "Kwara","Lagos","Nasrawa","Niger", "Ogun", "Ondo", "Osun","Oyo","Plateau","Rivers", "Sokoto", "Taraba", "Yobe","Zamfara");
for(var i=0; i<statedd.length; i++){
OyStates = OyStates + "<option value="+i+">"+ statedd[i]+"</option>";
}
document.getElementById('st').innerHTML=OyStates;

function getOy(oysta,oylga){
var oylocalga ="";
var selectedOy = document.getElementById(oysta).value;
var OndsLga =new Array('Afijio','Akinyele', 'Attba','Atigbo', 'Egbeda', 'Ibadan', ' north east', 'Ibadan central','Ibadan south east', 'Ibadan west south','Ibarapa east',' Ibarapa north', 'Ido','Ifedapo', 'Ifeloju','Irepo',' Iseyin','Itesiwaju','Iwajowa','Iwajowa olorunshogo', 'Kajola','Lagelu', 'Ogbomosho north', 'Ogbomosho south', ' Oluyole', 'Ona ara','Ore lope', 'Orire','Oyo east',' Oyo west','Saki east',' Saki west',' Surulere'); 

if(selectedOy=="30"){
	for(var i=0; i<OndsLga.length; i++){
oylocalga = oylocalga + "<option>"+OndsLga[i]+"</option>";
}
document.getElementById(oylga).innerHTML=oylocalga;
}
}


var PlStates="";
var statedd = new Array("Abia","Adamawa", "Anambara", "Akwa-ibom", "Bauchi","Bayelsa","Benue","Borno", "Cross-River", "Delta", "Ebonyi","Edo","Ekiti","Enugu", "Gombe", "Imo", "Jigawa","Kaduna", "FCT Abuja","Kano","Katsina", "Kebbi", "Kogi", "Kwara","Lagos","Nasrawa","Niger", "Ogun", "Ondo", "Osun","Oyo","Plateau","Rivers", "Sokoto", "Taraba", "Yobe","Zamfara");
for(var i=0; i<statedd.length; i++){
PlStates = PlStates + "<option value="+i+">"+ statedd[i]+"</option>";
}
document.getElementById('st').innerHTML=PlStates;

function getPl(plsta,pllga){
var pllocalga ="";
var selectedPl = document.getElementById(plsta).value;
var OndsLga =new Array('Barkin/ladi','Bassa', 'Bokkos','Jos north', 'Jos east', 'Jos south', ' Kanam', 'kiyom','Langtang north', 'Langtang south','Mangu',' Mikang', 'Pankshin','Qua`an pan', 'Shendam','Wase'); 

if(selectedPl=="31"){
	for(var i=0; i<OndsLga.length; i++){
pllocalga = pllocalga + "<option>"+OndsLga[i]+"</option>";
}
document.getElementById(pllga).innerHTML=pllocalga;
}
}


var RvStates="";
var statedd = new Array("Abia","Adamawa", "Anambara", "Akwa-ibom", "Bauchi","Bayelsa","Benue","Borno", "Cross-River", "Delta", "Ebonyi","Edo","Ekiti","Enugu", "Gombe", "Imo", "Jigawa","Kaduna", "FCT Abuja","Kano","Katsina", "Kebbi", "Kogi", "Kwara","Lagos","Nasrawa","Niger", "Ogun", "Ondo", "Osun","Oyo","Plateau","Rivers", "Sokoto", "Taraba", "Yobe","Zamfara");
for(var i=0; i<statedd.length; i++){
RvStates = RvStates + "<option value="+i+">"+ statedd[i]+"</option>";
}
document.getElementById('st').innerHTML=RvStates;

function getRv(rvsta,rvlga){
var rvlocalga ="";
var selectedRv = document.getElementById(rvsta).value;
var OndsLga =new Array('Abua/Odial','Ahoada west', 'Akuku toru','Andoni', 'Asari toru', 'Bonny', ' Degema', 'Eleme','Emohua', 'Etche','Gokana',' Ikwerre', 'Oyigbo','Khana', 'Obio/Akpor','Ogba east /Edoni', ' Ogu/bolo','Okrika', 'Omumma','Opobo/Nkoro',' Portharcourt', 'Tai','Khana'); 

if(selectedRv=="32"){
	for(var i=0; i<OndsLga.length; i++){
rvlocalga = rvlocalga + "<option>"+OndsLga[i]+"</option>";
}
document.getElementById(rvlga).innerHTML=rvlocalga;
}
}

var SkStates="";
var statedd = new Array("Abia","Adamawa", "Anambara", "Akwa-ibom", "Bauchi","Bayelsa","Benue","Borno", "Cross-River", "Delta", "Ebonyi","Edo","Ekiti","Enugu", "Gombe", "Imo", "Jigawa","Kaduna", "FCT Abuja","Kano","Katsina", "Kebbi", "Kogi", "Kwara","Lagos","Nasrawa","Niger", "Ogun", "Ondo", "Osun","Oyo","Plateau","Rivers", "Sokoto", "Taraba", "Yobe","Zamfara");
for(var i=0; i<statedd.length; i++){
SkStates = SkStates + "<option value="+i+">"+ statedd[i]+"</option>";
}
document.getElementById('st').innerHTML=SkStates;

function getSk(sksta,sklga){
var sklocalga ="";
var selectedSk = document.getElementById(sksta).value;
var OndsLga =new Array('Binji','Bodinga', 'Dange/shuni','Gada', 'Goronyo', 'Gudu', ' Gwadabawa', 'Illella','Kebbe', 'Kware','Rabah',' Sabon -Birni', 'Shagari','Silame', 'Sokoto south','Sokoto north', ' Tambuwal','Tangaza', 'Tureta','Wamakko',' Wurno', 'Yabo'); 

if(selectedSk=="33"){
	for(var i=0; i<OndsLga.length; i++){
sklocalga = sklocalga + "<option>"+OndsLga[i]+"</option>";
}
document.getElementById(sklga).innerHTML=sklocalga;
}
}

var TrStates="";
var statedd = new Array("Abia","Adamawa", "Anambara", "Akwa-ibom", "Bauchi","Bayelsa","Benue","Borno", "Cross-River", "Delta", "Ebonyi","Edo","Ekiti","Enugu", "Gombe", "Imo", "Jigawa","Kaduna", "FCT Abuja","Kano","Katsina", "Kebbi", "Kogi", "Kwara","Lagos","Nasrawa","Niger", "Ogun", "Ondo", "Osun","Oyo","Plateau","Rivers", "Sokoto", "Taraba", "Yobe","Zamfara");
for(var i=0; i<statedd.length; i++){
TrStates = TrStates + "<option value="+i+">"+ statedd[i]+"</option>";
}
document.getElementById('st').innerHTML=TrStates;

function getTr(trsta,trlga){
var trlocalga ="";
var selectedTr = document.getElementById(trsta).value;
var OndsLga =new Array('Akdo -kola','Bali', 'Donga','Gashaka', 'Gassol', 'Ibi', ' Jalingo', ' K/Lamido','Kurmi', 'lan','Sardauna',' Tarum', 'Ussa','Wukari', 'Yorro','Zing'); 

if(selectedTr=="34"){
	for(var i=0; i<OndsLga.length; i++){
trlocalga = trlocalga + "<option>"+OndsLga[i]+"</option>";
}
document.getElementById(trlga).innerHTML=trlocalga;
}
}

var YbStates="";
var statedd = new Array("Abia","Adamawa", "Anambara", "Akwa-ibom", "Bauchi","Bayelsa","Benue","Borno", "Cross-River", "Delta", "Ebonyi","Edo","Ekiti","Enugu", "Gombe", "Imo", "Jigawa","Kaduna", "FCT Abuja","Kano","Katsina", "Kebbi", "Kogi", "Kwara","Lagos","Nasrawa","Niger", "Ogun", "Ondo", "Osun","Oyo","Plateau","Rivers", "Sokoto", "Taraba", "Yobe","Zamfara");
for(var i=0; i<statedd.length; i++){
YbStates = YbStates + "<option value="+i+">"+ statedd[i]+"</option>";
}
document.getElementById('st').innerHTML=YbStates;

function getYb(ybsta,yblga){
var yblocalga ="";
var selectedYb = document.getElementById(ybsta).value;
var OndsLga =new Array('Borsari','Damaturu','Fika','Fune','Geidam','Gogaram',' Gujba',' Gulani','Jakusko','Karasuwa','Machina','Nagere','Nguru','Potiskum','Tarmua','Yunusari','Yusufari','G ashua'); 

if(selectedYb=="35"){
	for(var i=0; i<OndsLga.length; i++){
yblocalga = yblocalga + "<option>"+OndsLga[i]+"</option>";
}
document.getElementById(yblga).innerHTML=yblocalga;
}
}

var ZmStates="";
var statedd = new Array("Abia","Adamawa", "Anambara", "Akwa-ibom", "Bauchi","Bayelsa","Benue","Borno", "Cross-River", "Delta", "Ebonyi","Edo","Ekiti","Enugu", "Gombe", "Imo", "Jigawa","Kaduna", "FCT Abuja","Kano","Katsina", "Kebbi", "Kogi", "Kwara","Lagos","Nasrawa","Niger", "Ogun", "Ondo", "Osun","Oyo","Plateau","Rivers", "Sokoto", "Taraba", "Yobe","Zamfara");
for(var i=0; i<statedd.length; i++){
ZmStates = ZmStates + "<option value="+i+">"+ statedd[i]+"</option>";
}
document.getElementById('st').innerHTML=ZmStates;

function getZm(zmsta,zmlga){
var zmlocalga ="";
var selectedZm = document.getElementById(zmsta).value;
var OndsLga =new Array('Anka','bukkuyum','Dungudu','Chafe','Gummi','Gusau',' Isa',' Kaura/Namoda','Mradun','Maru','Shinkafi','Talata/Mafara','Zumi'); 

if(selectedZm=="36"){
	for(var i=0; i<OndsLga.length; i++){
zmlocalga = zmlocalga + "<option>"+OndsLga[i]+"</option>";
}
document.getElementById(zmlga).innerHTML=zmlocalga;
}
}
</script>
</div>
  

							<div class="col-lg-4">
                        	<label>Religion <span style="color:red; font-size:18px">*</span></label>
                            <select class="form-control" name="religion">
                            	<option>[ Select Religion ]</option>
                                <option >Christianity</option>
                                <option>Islam</option>
                            </select>
                            <br />
                        </div>
                        <div class="col-lg-12">
                        	<label>Contact Address <span style="color:red; font-size:18px;">*</span>  </label>
                            <input type="text"  name="add" class="form-control" placeholder="Enter Your Address" />
                            
                        </div>
                       
                    </div>
                </div>
            </div>
        </div>
        <!--- End Login DIV -->
      
    </div>
</div>
</div>
<!--- End Container DIV -->

<!-- First COntainer -->
<div class="container" style="margin-top:10px; margin-bottom:50px;">
	<div class="row">
    <!-- Login DIV-->
    <div class="col-lg-offset-2">
    	<div class="col-lg-9">
        	<div class="panel panel-default">
            	<div class="panel-heading">
                	<h3 class="panel-title"><span class="glyphicon glyphicon-user"></span> Next of Kin</h3>
                </div>
                <div class="panel-body">
                	<div class="row">
                 
                        <div class="col-lg-4">
                        	<label>First Name <span style="color:red; font-size:18px">*</span></label>
                            <input type="text" name="N_fname" class="form-control" />
                        </div>
                        <div class="col-lg-4">
                        	<label>Last Name <span style="color:red; font-size:18px">*</span></label>
                            <input type="text"name="N_lname"  class="form-control" />
                        </div>
                        <div class="col-lg-4">
                        	<label>Other Name </label>
                            <input type="text" name="N_oname" class="form-control" />
                            <br />
                        </div>
                        <div class="col-lg-4">
                        	<label>Phone Number <span style="color:red; font-size:18px">*</span></label>
                            <input type="text" name="N_phno" class="form-control" />
                        </div>
                        <div class="col-lg-4">
                        	<label>Email Address </label>
                            <input type="text" name="N_email" class="form-control" placeholder="Enter Your Email Address" />
                        </div>
                        <div class="col-lg-4">
                        	<label>Gender <span style="color:red; font-size:18px">*</span></label>
                            <select class="form-control" name="N_gen" >
                            	<option>[ Select Gender ]</option>
                                <option>Male</option>
                                <option>Female</option>
                            </select>
                            <br />
                        </div>
                        <div class="col-lg-4">
                        	<label>Relationship <span style="color:red; font-size:18px">*</span></label>
                            <input type="text" name="N_relation" class="form-control" placeholder="Enter Yor Relationship" />
                        </div>
                        <div class="col-lg-8">
                        	<label>Contact Address <span style="color:red; font-size:18px">*</span></label>
                            <input type="text" name="N_add" class="form-control" placeholder="Enter Yor Address" />
                            <br />
                        </div>
                        
                             
                        </div>
                 
                    <div class="col-lg-12">
	<input type="submit" value="Next & Continue" name="ok" class="btn btn-default"><span class="glyphicon glyphicon-saved"></span> &nbsp;&nbsp;
   <button type="reset" class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span> Reset Form</button>
	                    </div>  
                                   
                  </div>
		
             </div>
          </form> 
        </div>
    </div>
    </div>
  <!--- End Login DIV -->
        
    </div>
</div>
</form> 
<!--- End Container DIV -->

<div class="navbar navbar-fixed-bottom navbar-default">
	<div class="container">
    	<div class="col-lg-6">
        	<div style="color:#930; font-weight:bold; margin:10px auto;">&copy; 2017 all right reserved mautech.com.ng</div>
        </div>
        <div class="col-lg-6">
        	<div style="color:#930; font-weight:bold; margin:10px auto; float:right;">Powered By Companie Name</div>
        </div>
    </div>
</div>
</body>
</html>