<?php
if (isset($_POST['doc'])) {
	$name = $_FILES['document']['name'];
	$size = $_FILES['document']['size'];
	$tmp = $_FILES['document']['tmp_name'];
	$ext = explode(".", $name);
	$realext = strtolower(end($ext));
	$filenam = "UG14/SCCS/1036";
	$rename = str_replace("/", "", $filenam).".".$realext;
	echo $name;
	echo $size."<br>";
	echo $tmp."<br>";
	echo $realext;
	echo $rename;
	

	if (!empty($name)) {
		if ($realext =='doc' || $realext == 'docx') {
			if ($size<=2097152) {
				move_uploaded_file($tmp, "doc/".$rename);
				echo "Your Picture was uploaded!!";
			}
			else{
				echo "Uploaded document must not be greater than 2MB";
				
			}
		}
		else{
			echo "document must be in .doc or .docx extention";
		}
	}
	else{
		echo "Dear User You must upload a document!";
	}
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>upload</title>
	<link rel="stylesheet" type="text/css" href="css/boostrap.css"/>
</head>
<body>
<form role="form" method="post" enctype="multipart/form-data">
<input type="text" name="document" class="form-control"/>
	<input type="file" name="document" class="form-control"/>
	<input type="submit" name="doc" class="btn btn-success btn-lg" value="Upload" />

</form>

</body>
</html>