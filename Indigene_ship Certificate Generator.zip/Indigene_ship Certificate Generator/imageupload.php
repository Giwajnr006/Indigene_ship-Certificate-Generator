<?php
require "projectconnection.php";
$date1 =date('d-m-y h:i:s');
?>
<!DOCTYPE html>
<html>
<head>
	<title>upload image</title>
  <link rel="icon" type="text/image" href="img/a1.jpeg">
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
	<!--linking boostrap-->
	<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css">
	<!--linking custom CSS-->
  <link rel="stylesheet" type="text/css" href="css/font-awesome.css">
    <!--<link rel="stylesheet" type="text/css" href="css/npcprj.css">-->
	<link rel="stylesheet" type="text/css" href="css/mystyle.css">
	<!--linking JS for boostrap-->
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<!--- I copied from getboostrap.com-->
	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
	<!-- jQuery library -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
	<!-- Latest compiled JavaScript -->
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    <!--slider-->
    <link rel="stylesheet" type="text/css" href="css/custom-slider.css"/>
    <script type="text/javascript" src="js/jquery-1.11.1.js"></script>
    <script type="text/javascript" src="js/jquery.custom-slider.js"></script>
    <script>
        $(document).ready(function(){
            $(".slider").customslider({ height:"100px", width: "100%", speed:700 })
        });
    </script>
</head>
<body style="background-image: url(img/bgg.jpg);background-size: cover;background-attachment: fixed;">

<!--header-->
<div class ="navbar navbar-default  navbar-fixed-top" style=" background-color:#3cb371; height: 60px; border-bottom: 2px solid; color: yellow;">
    <div class="navbar navbar-brand">
        <a <href="index.html"><img src="img/a1.jpeg" width="65%" height="65%"   style="margin-top: -15px;float: left;" class="img-responsive img-circle"></a>
    </div>
    <p class="txtlogo" style="color:#fff; margin-top:25px; margin-left: -190px; font-size: 20px;">GOMBE LOCAL GOVERNMENT
    <a href="home.php" style="margin-left: 200px; color: #fff;"><span class="glyphicon glyphicon-log-out" style =" margin-top:0px; margin-left: 200px; color:#fff;"> </span> Logout</a>
    </p>
 
    </div>
  
<form enctype ="multipart/form-data"method ="POST" action ="">
<div class="container"style ="margin-top:100px;">
  <div class="row">
    <div class="col-sm-4 col-lg-4">
      <div class="panel panel-success">
        <div class="panel-heading" style="background-color:#3cb371;
            border-bottom: 2px solid yellowgreen;">
              <h4 class="panel-title"><h3 class="panel-title" style ="color: #fff;"><span class="glyphicon glyphicon-picture"></span> Upload your identification letter</h3><h4>
        </div>
         <div class="panel-body">
                     

                     <?php
require "projectconnection.php";
if(isset($_POST['upld'])){
  $name =$_FILES['Certificate']['name'];
  $size =$_FILES['Certificate']['size'];
  $temName =$_FILES['Certificate']['tmp_name'];
  echo $name;
  $extension =explode(".",$name);
  $imgextention =strtolower(end ($extension));
  $finalName ="your/passport";
  $rename = str_ireplace("/", "", $finalName)."." .$imgextention;
  if(!empty($name)){
  $nnn =end($extension);
  if($nnn =='jpg'or $nnn =='png'){
    if($size<=2097152){
      move_uploaded_file($temName, "images/".$name);
      //mysql_query("INSERT INTO upload_image(passpord,primary_c,birth_c) VALUES('$rename','','')");
       echo "<div class ='alert alert-success'><strong> Yes</strong> Your document was uploaded!</div>";
    }else{
      echo "<div class ='alert alert-info'><strong> Something wrong!</strong> document must be in .png or .jpg extention</div>";
    }
    }
  }else{
   echo "<div class ='alert alert-danger'><strong> Error:</strong> Dear User You must upload a document!</div>";
  } 
 
}
?>
                      <div class="col-lg-12">
                      <input type="file" name="Certificate" />
                     <!-- <input type="submit" name="submit" value="Upload"class ="btn btn-default btn-lg"style ="margin-top:7px;">-->
                    </div>
                
            </div>
      </div>
    </div>


    <div class="col-sm-4 col-lg-4">
   

      <div class="panel panel-success">
        <div class="panel-heading" style="background-color:#3cb371;
           border-bottom: 2px solid yellowgreen;">
          <h4 class="panel-title"><h3 class="panel-title"style ="color: #fff;"><span class="glyphicon glyphicon-picture"></span>  Upload your primary certificate</h3><h4>
        </div>
         <div class="panel-body">
 <?php
if (isset($_POST['upld'])) {
  $name = $_FILES['document']['name'];
  $size = $_FILES['document']['size'];
  $tmp = $_FILES['document']['tmp_name'];
  $ext = explode(".", $name);
  $realext = strtolower(end($ext));
  $filenam = "pirmary/certificate";
  $renam = str_replace("/", "", $filenam).".".$realext;
  echo $name;
  //echo $size."<br>";
 // echo $tmp."<br>";
  //echo $realext;
 // echo $rename;
  

  if (!empty($name)) {
    if ($realext =='png' || $realext == 'jpg') {
      if ($size<=2097152) {
        move_uploaded_file($tmp, "images/".$renam);
         //mysql_query("INSERT INTO upload_image(passpord,primary_c,birth_c) VALUES('','$renam','')");
        echo "<div class ='alert alert-success'><strong> Yes</strong> Your document was uploaded!</div>";
      }
      else{
        echo "<div class ='alert alert-danger'><strong> Error:</strong>  Uploaded document must not be greater than 2MB</div>";
        
      }
    }
    else{
      echo "<div class ='alert alert-info'><strong> Something wrong!</strong> document must be in .doc or .docx extention</div>";
    }
  }
  else{
    echo "<div class ='alert alert-danger'><strong> Error:</strong> Dear User You must upload a document!</div>";
  }
}
?>
                  
            <input type="file" name="document" class="form-control"/>
           <!--<input type="submit" name="doc" class="btn btn-default btn-lg" value="Upload"style ="margin-top:7px;" />-->
            </div>
          </div>
      </div>
      <div class="col-sm-4 col-lg-4">
   

      <div class="panel panel-success">
        <div class="panel-heading" style="background-color:#3cb371;
           border-bottom: 2px solid yellowgreen;">
          <h4 class="panel-title"><h3 class="panel-title"style ="color: #fff;"><span class="glyphicon glyphicon-picture"></span>  Upload your Certificate of birth</h3><h4>
        </div>
         <div class="panel-body">
   <?php
if (isset($_POST['upld'])) {
  $name = $_FILES['doc']['name'];
  $size = $_FILES['document']['size'];
  $tmpT = $_FILES['document']['tmp_name'];
  $ext = explode(".", $name);
  $realext = strtolower(end($ext));
  $filenam = "Birth/certificate";
  $renme = str_replace("/", "", $filenam).".".$realext;
  echo $name;
  //echo $size."<br>";
 // echo $tmp."<br>";
  //echo $realext;
 // echo $rename;
  

 if (!empty($name)) {
    if ($realext =='png' || $realext == 'jpg') {
      if ($size<=2097152) {
        move_uploaded_file($tmpT, "images/".$renme);
        // mysql_query("INSERT INTO upload_image(passpord,primary_c,birth_c) VALUES('','','$renme')");
        echo "<div class ='alert alert-success'><strong> Yes</strong> Your document was uploaded!</div>";
      }
      else{
        echo "<div class ='alert alert-danger'><strong> Error:</strong>  Uploaded document must not be greater than 2MB</div>";
        
      }
    }
    else{
      echo "<div class ='alert alert-info'><strong> Something wrong!</strong> document must be in .doc or .docx extention</div>";
    }
  }
  else{
    echo "<div class ='alert alert-danger'><strong> Error:</strong> Dear User You must upload a document!</div>";
  }
}
?>
     
                  
            <input type="file" name="doc" class="form-control"/>
          <!-- <input type="submit" name="doc" class="btn btn-default btn-lg" value="Upload"style ="margin-top:7px;" />-->
            </div>
          </div>
      </div>
      </div>
      <button type="submit" name="upld"class ="btn btn-success btn-lg" style="background-color: #3cb371;">Upload</button>
      </div>
    </form>
    <a href="mydashboard.php"role ="button"class ="btn btn-primary btn-lg"style ="margin-left:170px; margin-top:-70px; background-color:#3cb371;">Next</a>
    <!-- ******begining of the footer****************-->
   <footer style="margin-top:70px;">
    <div class ="navbar navbar-inverse  navbar-fixed-bottom" style="height: 70px; border-top: 2px solid yellowgreen;">
        <div class="navbar navbar-brand"> 
        <p style ="color: #fff;">Copyright &#169; 2017 | <a href="http://gsu.edu.ng/" target="_blank" > By Nura muhammad sani</a> | All rights reserved.</p>
        </div>
        <div class="icons">
                <a href="www.facebook.com/mautech" title="www.facebook.com/mautech"
                style ="margin-top: 8px;float: right; font-size: 40px; padding: 0px 5px 0px 0px; ">
                <span class="fa fa-facebook-square" style="color: #fff;"></span></a>

                <a href="www.googleplus.com/mautech" title="www.googleplus.com/gme"
                style ="margin-top: 8px;float: right; font-size: 40px; padding: 0px 5px 0px 0px; ">
                <span class="fa fa-google-plus-square" style="color: #fff;"></span></a>

                <a href="www.twitter.com/@glga" title="www.twitter.com/@gme"
                style ="margin-top: 8px;float: right; font-size: 40px; padding: 0px 5px 0px 0px; ">
                <span class="fa fa-twitter-square" style="color: #fff;"></span></a>

                <a href="www.rss.com/gme" title="www.rss.com/gme"
                style ="margin-top: 8px;float: right; font-size: 40px; padding: 0px 5px 0px 0px; ">
                <span class="fa fa-rss-square" style="color: #fff;"></span></a>

                <a href="www.linkedin.com/gme" title="www.linkedlocl.com/gme"
                style ="margin-top: 8px;float: right; font-size: 40px; padding: 0px 5px 0px 0px; ">
                <span class="fa fa-linkedin-square" style="color: #fff;"></span></a>

                <a href="callto:+2347061992697" title="+2347061992697">
                <span class="fa fa-phone-square" style="color: #fff;margin-top: 12px;float: right; font-size: 40px; padding: 0px 5px 0px 0px;"></span></a>

                <a href="mailto:gme@gmail.com" title="gme@gmail.com">
                <span class="glyphicon glyphicon-phone-alt" style="color: #fff; margin-top: 10px;float: right; font-size: 40px; padding: 0px 5px 0px 0px;"></span></a>

                <a href="mailto:gme@gmail.com" title="gme@gmail.com">
                <span class="glyphicon glyphicon-envelope" style="color: #fff; margin-top: 12px;float: right; font-size: 40px; padding: 0px 5px 0px 0px;"></span></a>
            </div>
    </div>
 </footer>
 <!-- ************* End of the footer ****************-->
<?php
 require "projectconnection.php";

 if(isset($_POST['upld'])){
  $name =$_FILES['Certificate']['name'];
  $name = $_FILES['document']['name'];
   $name = $_FILES['doc']['name'];
  $qury = mysql_query("INSERT INTO upload_image (passpord, primary_C, birth_c) VALUES('$rename','$renam','$renme')");
  if( $qury){
    header("location:mydashboard.php");
  }else{
    echo "Error occour!";
  }
 }
 ?>
  </body>
</html>