<?php
session_start();
require "socialconnection.php";
//$userid=$_SESSION['userid'] ;

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<?php
require "socialconnection.php"; 
$date1 =date('d-m-y h:i:s');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Log in</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css"/>
<link href="css/mystyle.css" rel="stylesheet" type="text/css"/>
</head>

<body>
<div class="container">
	<div class="row">
	<div class="col-sm-12">
	<div class="panel panel-default" style="margin-top: 40px;">
<div class="panel-heading"style =background-color:#313636;height:80px;border-radius:4px; 0px; 25px; 0px;><h3 class="panel-title" style="color:#fff;margin-top: 10px; margin-left: 200px;">CHAT ROOM</h3></div>
<div class="panel-body">
	<form role ="form"enctype =""method="POST">
		<?php
		if(isset($_POST['bott'])){
			$coment =trim($_POST['coment']);
			$userid =$_SESSION['userid'];
			$userimage =$_SESSION['userimage'];
			$date1 =date('y-m-d h:i:s');
			
			echo $userid;
			if (!empty($coment)){
				$myqury =mysql_query("INSERT INTO comment_tbl VALUES('','$coment','$userid','$userimage','$date1')");
				if($myqury){
					echo "<div class ='alert alert-success'>successfully</div>";
				}else{
					echo "<div class ='alert alert-danger'>error</div>";
				}
			}
		}
			
		?>
		<input type="text
		" name="coment" placeholder="comments" class="form-control"><br>
		<button type="submit"name ="bott" class ="btn btn-primary btn-lg"style="margin-left:150px; margin-top:15px;">POST</button></form>
		<a href="login.php" role ="button" class="btn btn-primary btn-lg"style="margin-top:15px;">login</a><br><br>
		
			<ul class="media-list"style ="width:760px;">
			<?php
			$ql= mysql_query("SELECT * FROM comment_tbl ORDER BY coment_id DESC");
			for($i=0; $i<mysql_num_rows($ql); $i++){
				$coment =mysql_real_escape_string(trim(mysql_result($ql, $i,'comment')));
				$userid =mysql_result($ql, $i,'commentor');
				$userimage =mysql_result($ql, $i,'commenter_image');
				$comentdate =mysql_result($ql, $i,'comment_date');


				echo "
				<li class='media'style ='background-color: #09efdc;border-radius: 25px 0px 25px 0px'; width:50px;><hr>
					<img src='images/$userimage' class='media-object pull-left img-circle'
					 width='50px' height='50px'/>
					<div class='media_body'>
						<h3 class='media-heading'>$userid</h3>
						<p>$coment</p>
						<p align ='right'>$comentdate</p>
					
					</div>
					</li>
				";
			}
			?>
			
				
			</ul>
		</form>
		</div>
		</div>
		</div>
		</div>
	</div>
</body>
</html> 

