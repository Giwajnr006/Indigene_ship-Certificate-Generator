<?php
   session_start();
    ob_start();
    require "projectconnection.php";
    
    $serial_no= $_GET['id'];
    //approving 
    if (isset($_POST['approval'])) {
       $serial_no= $_GET['id'];
        
        $dateApprove = date("Y-m-d");
       $approve = mysql_query("UPDATE biodata2 SET approve = '1', approveDate = '$dateApprove' WHERE sn = '$serial_no'");
       header("location:approve.php");
    }
  
?>
<!DOCTYPE html>
<html>
<head>
    <title>approve or not approve</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <!--linking boostrap-->
    <link type="text/css" rel="stylesheet" href="css/bootstrap.min.css" />
    
    <!--- I copied from getboostrap.com-->
    <link rel="stylesheet" type="text/css" href="css/font-awesome.css">
    <link rel="stylesheet" type="text/css" href="css/npcprj.css">

    <link rel="icon" type="text/image" href="img/a1.jpeg">
    <!-- Latest compiled and minified CSS -->
    
</head>
<body style="background-image: url(images/80.png);background-size: cover;background-attachment: fixed;">
<!--%%%%%%%%%%%%HEADER %%%%%%%%%%%%%%%%%%%%%-->
<div class ="navbar navbar-default  navbar-fixed-top" style=" background-color:#2E8B57; height: 60px; border-bottom: 2px solid; color: yellow;">
    <div class="navbar navbar-brand">
        <a <href="index.html"><img src="img/a1.jpeg" width="65%" height="65%"   style="margin-top: -15px;float: left;" class="img-responsive img-circle"></a>
    </div>
    <p class="txtlogo" style="color:#fff; margin-top:25px; margin-left: -190px; font-size: 20px;">GOMBE LOCAL GOVERNMENT
    <a href="home.php" style="margin-left: 200px; color: #fff;"><span class="glyphicon glyphicon-log-out" style =" margin-top:0px; margin-left: 200px; color:#fff;"> </span> Logout</a>
    </p>
 </div>
    

</nav><nav class="navbar navbar-default navbar-fixed-top" role="navigation" style="background-color:#fff;margin-top: 60px; border-bottom: 2px solid; color: yellow; ma">
        <div class="container-fluid">
            <!--Brand and toggle get grouped-->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" 
                data-target="#col">
                    <span class="sr-only">toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                
                
            </div>
            <!--collect the nav links, forms and other content for toggle-->
            <div class="collapse navbar-collapse" id="col">
                <ul class="nav navbar-nav">
                    <li><a href="home.php">
                    <span class="glyphicon glyphicon-home"></span> Home
                    <span class="sr-only">(Current)</span></a></li>
                    
                </ul>
                
                <ul class="nav navbar-nav" style="margin-left: 0px;">
                    
                    <li class="dropdown active" style="margin-left: 80px;">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                    <span class="glyphicon glyphicon-user" style="height: 15px;"></span>&emsp;
                    WELCOME ADMIN!
                    <span class="caret"></span>
                        <ul class="dropdown-menu" role="menu">
                            <li role="presentation" class="dropdown-header" style="background-color: #2E8B57; height: 45px;"><label class="label" style="color:#fff; font-size: 15px;">Admin</label></li>
                            <li class="divider"></li>
                            
                            <li class="divider"></li>
                            <li><a href="home.php"><span class="glyphicon glyphicon-log-out"></span>&emsp;Logout</a></li>
                            <li class="divider"></li>
                            <li class="divider"></li>
                            <li><a href="adminhome.php"><span class="glyphicon glyphicon-dashboard" style="color: red;"></span>&emsp;Admin Dash Board</a></li>
                        </ul>
                    </li>
                </ul>
            </div> 
        </div>
    </nav>


     

<!--*********************END OF HEADER NAVIGATION**********************************************-->
<!--%%%%%%%%% LOGIN FORM %%%%%%%%%%%%%%%%%%-->
<div class="container" style="margin-top: 130px;">
    <div class="row">
    <div class=" col-sm-12 col-lg-12">
            <div class="login-panel panel panel-default" style="box-shadow: 2px 2px 8px 2px #BDBDBD; border-radius: 25px 25px 0px 0px;">
            <div class="well" style="background-color: #2E8B57; border-bottom: 2px solid yellow; font-size: 30px; color: #fff;  border-radius: 25px 25px 0px 0px;">Approve applicant <span style="font-size: 30px;color: #fff;float:right;" class="glyphicon glyphicon-user"></div>
                <div class="panel-body">
                
             
                    <div class="row">
                        <div class="col-sm-12 col-lg-12">
                            <div class="table-responsive">
                            <form class="form" role = "form" method ="post">
                                <table border="1" class=" table-condensed table table-hover table-striped" style="font-size: 11px; font-weight: 600;">
                                    <tr>
                                        <th>sn</th>
                                        <th>NAME</th>
                                        <th>dob</th>
                                        <th>gender</th>
                                        <th>ward</th>
                                        <th>phne No.</th>
                                        <th>tribe</th>
                                        <th>Nationality</th>
                                        <th>Religion</th>
                                        <th>email</th>
                                        <th>address</th>
                                        <th>CONTACT ADDRESS</th>
                                       
                                    </tr>
                     <?php
                     $serial_no = $_GET['id'];
                        $result = mysql_query("SELECT * FROM  biodata2 WHERE sn = '$serial_no'");
                        $rows = mysql_fetch_array($result);
                         $id =strtoupper(mysql_result($result,0,'id')); 
                           $fname = strtoupper(mysql_result($result,0, 'fname'));
                           $mname = strtoupper(mysql_result($result,0, 'mname'));
                           $lname = strtoupper(mysql_result($result,0, 'lname'));
                           $dob = strtoupper(mysql_result($result,0, 'dob'));
                           $gender = strtoupper(mysql_result($result,0, 'gender'));
                           $ward = strtoupper(mysql_result($result,0, 'ward'));
                           $phone = strtoupper(mysql_result($result,0, 'phoneNo'));
                           $tribe = strtoupper(mysql_result($result,0, 'tribe'));
                           $Nationality = strtoupper(mysql_result($result,0, 'Nationality'));
                           $state = strtoupper(mysql_result($result,0, 'state'));
                           $lga = strtoupper(mysql_result($result,0, 'lga'));
                           $Religion= strtoupper(mysql_result($result,0, 'religion'));
                           $email = strtoupper(mysql_result($result,0, 'email'));
                           $address = strtoupper(mysql_result($result,0, 'address'));
                           $caddress = strtoupper(mysql_result($result,0, 'caddress'));
                          
                   echo "<tr>
                   <td>$id</td>
                <td>$fname&emsp;$mname&emsp;$lname</td>
                <td>$dob</td>
                <td>$gender</td>
                <td>$ward</td>
                <td>$phone</td>
                <td>$tribe</td>
                <td>$Nationality <br>state:&emsp;$state <br>L.G.A&emsp;$lga </td>
                <td>$Religion</td>
                <td> $email</td>
                <td>$address</td>
                <td>$caddress</td>
                
            </tr>";
                

                                        
                ?>

<?php 
$phone = $_GET['id'];
echo $phone;
$seletCrd = mysql_query("SELECT * FROM upload_image WHERE sn = '$serial_no'");
for ($i=0; $i < mysql_num_rows($seletCrd); $i++) {
    $passport=mysql_result($seletCrd, $i,'passpord'); 
    $form = mysql_result($seletCrd, $i,'form');
    $primary_c = mysql_result($seletCrd, $i,'primary_c');
    $birth_c = mysql_result($seletCrd, $i,'birth_c');
   echo " <tr>
                                        <td colspan='9'>
                                <div class='panel panel-default' style ='width:100%;''>
                                <div class='panel-heading' style='background-color:#2E8B57; color:#fff; font-size: 15px; margin-left: 10px;'><span style='font-size: 30px;color: #fff;float:right;' class='glyphicon glyphicon-pencil'> </span>Identification Letter</div>
                                 <div class='panel-body'>
                                    <img src='images/$form' width='100%'>
                                      </div>
                                        </div>
                                        </td>

                                        <td colspan='5'>
                                     <div class='panel panel-default' style ='width:100%;'>
                                     <div class='panel-heading' style='background-color:#2E8B57; color:#fff; font-size: 15px; margin-left: 10px;''><span style='font-size: 30px;color: #fff;float:right;' class='glyphicon glyphicon-envelope'></span>Passport</div>
                                 <div class='panel-body'>
                                <img src='images/$passport' width='100%'>
                             </div>
                             </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan='7'>
                                            <div class='panel panel-default' style ='width:100%;'>
                                            <div class='panel-heading' style='background-color:#2E8B57; color:#fff; font-size: 15px; margin-left: 10px;'><span style='font-size: 30px;color: #fff;float:right;' class='glyphicon glyphicon-certificate'> </span>primary certificate</div>
                                            <div class='panel-body'>
                                            <img src='images/$primary_c'width='100%'>
                                        </div>
                                        </div>
                                     </td>

                                        <td colspan='7'>
                                            <div class='panel panel-default' style ='width:100%;'>
                                        <div class='panel-heading' style='background-color:#2E8B57; color:#fff; font-size: 15px; margin-left: 10px;'><span style='font-size: 30px;color: #fff;float:right;'' class='glyphicon glyphicon-certificate'> </span>Birth certificate</div>
                                        <div class='panel-body'>
                                         <img src='images/$birth_c' width='100%'>
                                        </div>
                                        </div>
                                        </td>
                                    </tr>";
}


    
                                   
            ?>
                                    <tr>
                                        <td colspan='7'>
                                            <input type="submit" class="btn btn-success btn-block btn-lg" name = "approval" value="Approve Applicant" />
                                        </td>
                                        <td colspan='7'>
                                            <a href="approve.php" class="btn btn-success btn-block btn-lg" role ="button">Not Approve</a>
                                        </td>


                                       
                                    </tr>

                                   
                                </table>
                                </form>
                            </div>
                        </div>
                        
                      </div>  
                    </div>
                </div>
            </div>
        </div>
    </div>

        
<!--%%%%%%%%% END LOGIN FORM %%%%%%%%%%%%%%%%%%-->

<!--%%%%%%%%% END LOGIN FORM %%%%%%%%%%%%%%%%%%-->

<!-- ******begining of the footer****************-->
   <div class="footer" style="margin-top:45px; background-color: #2E8B57;opacity: 0.9;">
    <div class ="navbar navbar-inverse  navbar-fixed-bottom" style="height: 50px; background-color: #2E8B57; border-top: 2px solid yellow;">
        <div class="navbar navbar-brand"> 
        <p> <marquee direction="left" style="color: yellow;">Welcome to Gombe local Government indigene online application. Copyright &#169; 2017 | <a href="http://Gombe.gme.ng/" target="_blank" style="color: yellow" >Gombe.gme.ng</a> | All rights reserved. powered by Briatek Computer Institute. Welcome to Gombe local Government indigene online application. Copyright &#169; 2017 | <a href="http://Gombe.gme.ng/" target="_blank" style="color: yellow" >Gombe.gme.ng</a> | All rights reserved. powered by Briatek Computer Institute.</marquee><b><a href = "#Top" class="bb" style="float: right;margin-top: 40px;">back to top</a></b><p>
       

             
    </div>
 </div>
 </div>
 
 
 <!-- ************* End of the footer ****************-->


<!---scripft -->
 <!-- jQuery -->
    
     <script src="js/jquery.min.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    

<script>
    $(function(){
        $('.nav-tabs a:first').tab('show');
    });
</script>
<script>
$(document).ready(function(){
    $('[data-toggle="popover"]').popover(); 
});
</script>
</body>
</html>