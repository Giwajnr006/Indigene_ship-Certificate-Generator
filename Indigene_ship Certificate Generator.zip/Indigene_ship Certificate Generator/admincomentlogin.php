<?php
 session_start();
require "connection.php"; 
$date1 =date('d-m-y h:i:s');

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Log in</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css"/>
    <style>
    	body{
    	 background-image: url(images/Lighthouse.jpg);
    	 background-repeat: no-repeat;
    	 background-color: transparent;
    	}
    </style>
</head>

<body id ="page">
<!--<ul class="cb-slideshow"> 
            <li><span>Image 01</span></li>
            <li><span>Image 02</span></li>
            <li><span>Image 03</span></li>
        </ul>
        
        <div class="container">

            <div class="codrops-top">
              
                <div class="clr"></div>
            </div>
        </div>-->
<div class ="navbar navbar-default  navbar-fixed-top" style="height: 60px; box-shadow:  2px 2px 5px 4px #222;opacity: 0.9;">
    <div class="navbar navbar-brand">
        <!--<a <href="index.html"><img src="img/a1.jpeg" width="65%" height="65%"   style="margin-top: -15px;float: left;" class="img-responsive img-circle"></a>-->
    </div>
    <p class="txtlogo" style="color:#3a6182; margin-top:25px; margin-left: -190px; font-size: 20px;">GOMBE LOCAL GOVERNMENT
    <a href="home.php" style="margin-left: 250px;"><span class="glyphicon glyphicon-log-out" style =" margin-top:0px; margin-left: 270px;"> </span> Logout</a>
    </p>
 
    </div>
<?php
	require "socialconnection.php";
	if (isset($_POST['boton'])) {
		$name =$_POST['nam'];
		$pass =$_POST['password'];
		if(!empty($name)and !empty($pass)){
			$_SESSION['userid'] =$name;
			header("location:MyHome.php");
		}else{
			echo "you must enter name and password";
		}
	}
	if (isset($_POST['logout'])) {
        session_unset();
        header("location:index.php");
    }
	?>
	


<div class="container"style="margin-top: 100px;">
		<div class="row">
			<div class="col-sm-4"></div>
			<div class="col-sm-4">
			
	<div class="panel panel-default" style="width:200; px; border: 4px solid; border-radius:6px; color: #afc0be;">
	<div class="well" style="background-color: #3a6182; color: #fff;font-style: italic;">WELC0ME ADMIN</div>
		<div class="panel-body">
			<form class="form" role ="form" enctype="multipart/form-data" method="POST">
				<input type="text" name="nam"placeholder =" Enter your name" style="margin-left:40px;margin-top:0px;"required>
				<input type="password" name="password"placeholder ="Enter password" style="margin-left:40px;margin-top: 20px;"required>
				<div class="well" style="margin-left: -17px; width:290px;height: 30px; background-color: #3a6182; margin-top: 50px;">
				<input  type="submit"value="Login"name ="boton"style="margin-left:10px; margin-top:-18px;" class="btn btn-default btn-sm" />
				<input type="reset" value ="reset"name ="boton"style="margin-left:10px; margin-top:-18px;" class="btn btn-default btn-sm" ></div>
			</form>
		</div>
	</div>


		</div>
	<div class="col-sm-4"></div>
</div>
</div>
</body>
</html>