
<!DOCTYPE html>
<html>
<head>
	<title>Biodata</title>
	<meta charset="utf-8">
  <link rel="icon" type="text/image" href="img/a1.jpeg">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
	<!--linking boostrap-->
	<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css">
	<!--linking custom CSS-->
	<link rel="stylesheet" type="text/css" href="css/biostyle.css">
  <link rel="stylesheet" type="text/css" href="css/font-awesome.css">
	<!--linking JS for boostrap-->
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<!--- I copied from getboostrap.com-->
	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
	<!-- jQuery library -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
	<!-- Latest compiled JavaScript -->
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
   
</head>
<body>
<!--header-->
<div class ="navbar navbar-default  navbar-fixed-top" style=" background-color:#3cb371; height: 60px; border-bottom: 2px solid; color: yellow;">
    <div class="navbar navbar-brand">
        <a <href="index.html"><img src="img/a1.jpeg" width="65%" height="65%"   style="margin-top: -15px;float: left;" class="img-responsive img-circle"></a>
    </div>
    <p class="txtlogo" style="color:#fff; margin-top:25px; margin-left: -190px; font-size: 20px;">GOMBE LOCAL GOVERNMENT
    <a href="home.php" style="margin-left: 200px; color: #fff;"><span class="glyphicon glyphicon-log-out" style =" margin-top:0px; margin-left: 200px; color:#fff;"> </span> Logout</a>
    </p>
 
    </div>
   
    <div class="container"style =" margin-top:70px;" class="navbar-condensed">
      <div class="row">
        <div class="col-sm-1">
          <!--<div class="panel panel-default">
            <div class="panel-heading"style ="background-color:#009d44;border-bottom: 2px solid white;">
            <h4 class="panel-title"style ="color:#fff;">Check your certificate<span class="glyphicon glyphicon-envelope"style ="float:right"></span></h4>
            </div>
            <div class="panel-body">
             <form role ="form" method="POST" action="uploadimage.php">
                <div class="form-group">
                  <div class="form-group input-group">
                   <input type="text" name="fname"placeholder="search"class="form-control">
                  <span class="input-group-addon">
                  <span class="glyphicon glyphicon-search"></span>
                  </span>
              </div>
                </div>
            </div>
          </div>-->
        </div>
          <div class="col-sm-10">
            
            <div class="panel panel-default" style="">
            <div class="panel-heading"style ="background-color:#3cb371; border-bottom: 2px solid white;">
              <h4 class="panel-title"style ="color:#fff;"> Registration form<span class="glyphicon glyphicon-pencil" style="float: right;font-size: 25px;"></span> </h4>
            </div>
            <div class="panel-body" style="background-color: #F8F8F8;">
            <?php
require"projectconnection.php";
$date1 =date('d-m-y h:i:s');
if(isset($_POST['sumit'])){
  $fname =mysql_real_escape_string($_POST['fname']);
  $mname =mysql_real_escape_string($_POST['mname']);
  $lname =mysql_real_escape_string($_POST['lname']);
  $dob =mysql_real_escape_string($_POST['dob']);
  $gender =mysql_real_escape_string($_POST['gender']);
  $mstatus =mysql_real_escape_string($_POST['mstatus']);
  $ward =mysql_real_escape_string($_POST['ward']);
  $phone =mysql_real_escape_string($_POST['phone']);
  $tribe =mysql_real_escape_string($_POST['tribe']);
  $nationality =mysql_real_escape_string($_POST['nationality']);
  $state =mysql_real_escape_string($_POST['state']);
  $lga =mysql_real_escape_string($_POST['lga']);
  $caddress =$_POST['caddress'];
  $files=$_FILES['files']['name'];
  $extended =explode(".", ($files));
    $imagextention =strtolower(end($extended ));
    $finalName ="passport";
    $rename =str_replace("", "", $finalName).".".$imagextention;
    $qury =mysql_query("SELECT * FROM biodata WHERE phone ='$phone'");
    if( $qury){
      $num =mysql_num_rows($qury);
      if($num==0){
        // inserting data into a database
  $sql =mysql_query("INSERT INTO biodata(fname, mname, lname, dob, gender, mstatus, ward, phone, tribe, nationality, state, lga,caddress, files) VALUES('$fname','$mname','$lname','$dob','$gender','$mstatus','$ward','$phone','$tribe','$nationality','$state','$lga','$caddress','$rename')");
    if($sql){
      header("location:uploadimage.php");
    }
      else
      {
       echo "<div class='alert alert-success'><strong>Yes!</strong>your biodata have already exist</div>"; 
      }
   }
   
}
  //if($sql ==1){
   // echo "<div class='alert alert-success'><strong>Yes!</strong>your biodata have registered succeessfully</div>";
  //}
 // else{
   // echo "<div class='alert alert-danger'><strong>Error!</strong> Please register again.</div>";
  //}
    
    $sql =mysql_query("UPDATE * FROM Biodata");
}
?>
              <form role ="form" method="post">
              <div class="row">
                <div class="col-sm-4 col-lg-4">
                  <div class="form-group">
                  <label for="fname">First Name:</label>
                    <div class="form-group input-group">
                      <span class="input-group-addon">
                      <span class="glyphicon glyphicon-user" style="color: #3cb371;"></span>
                      </span>
                      <input type="text" name="fname"placeholder="First Name"class="form-control" required>
                    </div>
                    </div>
                </div>

                <div class="col-sm-4 col-lg-4">
                  <div class="form-group">
                  <label for="fname">middle Name:</label>
                    <div class="form-group input-group">
                      <span class="input-group-addon">
                      <span class="glyphicon glyphicon-user" style="color: #3cb371;"></span>
                      </span>
                      <input type="text" name="mname"placeholder="Middle Name"class="form-control" required>
                    </div>
                    </div>
                </div>

                <div class="col-sm-4 col-lg-4">
                  <div class="form-group">
                  <label for="fname">Last Name:</label>
                    <div class="form-group input-group">
                      <span class="input-group-addon">
                      <span class="glyphicon glyphicon-user" style="color: #3cb371;"></span>
                      </span>
                      <input type="text" name="lname"placeholder="Last Name"class="form-control" required>
                    </div>
                    </div>
                </div>
              </div>

              <div class="row">
              <div class="col-sm-4 col-lg-4">
                  <div class="form-group">
                  <label for="fname">dob:</label>
                    <div class="form-group input-group">
                      <span class="input-group-addon">
                      <span class="glyphicon glyphicon-tent" style="color: #3cb371;"></span>
                      </span>
                      <input type="Date" name="dob" class="form-control" width="40px" required>
                    </div>
                    
                    </div>
                </div>
                <div class="col-sm-4 col-lg-4">
                  <div class="form-group">
                  <label for="fname">Gender:</label>
                    <div class="form-group input-group">
                      <span class="input-group-addon">
                      <span class="glyphicon glyphicon-apple" style="color: #3cb371;"></span>
                      </span>
                   
                    <select name="gender" class="form-control" required>
                      <option>Male</option>
                      <option>Female</option>
                    </select>
                    </div>
                  </div>
                </div>

                <div class="col-sm-4 col-lg-4">
                  <div class="form-group">
                  <label for="fname">Marital status:</label>
                    <div class="form-group input-group">
                      <span class="input-group-addon">
                      <span class="glyphicon glyphicon-leaf" style="color: #3cb371;"></span>
                      </span>
                   
                    <select name="mstatus" class="form-control" required>
                      <option>single</option>
                      <option>married</option>
                      <option>divorce</option>
                    </select>
                    </div>
                  </div>
                </div>
              </div>

              <div class="row">
                <div class="col-sm-4 col-lg-4">
                  <div class="form-group">
                  <label for="ward">Enter your ward</label>
                    <div class="form-group input-group">
                      <span class="input-group-addon">
                      <span class="glyphicon glyphicon-home" style="color: #3cb371;"></span>
                      </span>
                   
                    <input type="text" name="ward"class="form-control"placeholder="Enter your ward " required>
                    </div>
                  </div>
                </div>

                <div class="col-sm-4 col-lg-4">
                  <div class="form-group">
                  <label for="fname"> your phone no:</label>
                    <div class="form-group input-group">
                      <span class="input-group-addon">
                      <span class="glyphicon glyphicon-phone" style="color: #3cb371;"></span>
                      </span>
                   
                    <input type="text" name="phone"class="form-control"placeholder="Enter phone no" required>
                    </div>
                  </div>
                </div>

                <div class="col-sm-4 col-lg-4">
                  <div class="form-group">
                  <label for="fname">Select your tribe:</label>
                    <div class="form-group input-group">
                      <span class="input-group-addon">
                      <span class="glyphicon glyphicon-list" style="color: #3cb371;"></span>
                      </span>
                     <select name="tribe" class="form-control" required>
                      <option>Select tribe:</option>
                      <option>hausa</option>
                      <option>fulani</option>
                      <option>kanuri</option>
                      <option>bolewa</option>
                      <option>terawa</option>
                      <option>yarabawa</option>
                      <option></option>
                    </select>
                    </div>
                    
                    </div>
                </div>
            </div>
              <div class="row">
                <div class="col-sm-4 col-lg-4">
                  <div class="form-group">
                  <label for="fname">Nationality:</label>
                    <div class="form-group input-group">
                      <span class="input-group-addon">
                      <span class="glyphicon glyphicon-flag" style="color:#3cb371;"></span>
                      </span>
                   
                    <select name="nationality" class="form-control" required>
                      <option>Nigeria</option>
                      <option>Niger</option>
                       <option>Camaroon</option>
                        <option>Ghana</option>
                    </select>
                    </div>
                  </div>
                </div>

                <div class="col-sm-4 col-lg-4">
                  <div class="form-group">
                  <label for="fname">State:</label>
                    <div class="form-group input-group">
                      <span class="input-group-addon">
                      <span class="glyphicon glyphicon-list" style="color: #3cb371;"></span>
                      </span>
                   
                    <select name="state" class="form-control" required>
                      <option>Gombe</option>
                      <option>Kano</option>
                      <option>Bauchi</option>
                      <option>Maiduguri</option>
                      <option>Yobe</option>
                      <option>Yola</option>
                    </select>
                    </div>
                  </div>
                </div>

                <div class="col-sm-4 col-lg-4">
                  <div class="form-group">
                  <label for="fname">Select your Local :</label>
                    <div class="form-group input-group">
                      <span class="input-group-addon">
                      <span class="glyphicon glyphicon-list" style="color: #3cb371;"></span>
                      </span>
                     <select name="lga" class="form-control" required>
                      <option>Select your local:</option>
                      <option>dukku</option>
                      <option>Nafada</option>
                      <option>Gombe</option>
                      <option>Y/Deba</option>
                      <option>Kaltungo</option>
                      <option>Billiri</option>
                      <option>shongom</option>
                      <option>Funakaye</option>
                      <option>Balagga</option>
                      <option>Akko</option>
                      <option>Kawmi</option>

                    </select>
                    </div>
                    
                    </div>
                </div>
                </div>
                <div class="row">
                
                <div class="col-sm-8 col-lg-8">
                  <div class="form-group">
                  <label for="email">Contact address:</label>
                    <div class="form-group input-group">
                      <span class="input-group-addon">
                      <span class="glyphicon glyphicon-home" style="color: #3cb371;"></span>
                      </span>
                   
                    <TEXTAREA COLS=50 ROWS=2 name="caddress"class="form-control"placeholder="Enter your address" required></TEXTAREA>
                 </div>
              </div>
            </div>
            <div class="col-sm-4 col-lg-4">
                  <div class="form-group">
                  <label for="fname"> upload passport:</label>
                    <div class="form-group input-group">
                      <span class="input-group-addon">
                      <span class="glyphicon glyphicon-phone" style="color: #3cb371;"></span>
                      </span>
                   
                    <input type="file" name="files"class="form-control"placeholder="upload passport" required>
                    </div>
                  </div>
                </div>
        </div>
          
        <div class ="row">
            <div class="col-sm-3 col-lg-3">
                <button type="Reset" class="btn btn-danger btn-lg"style ="margin-left:30px; backgroucolor:#3cb371;">
                <span class="glyphicon glyphicon-trash"> Reset</span> 
                </button>
            </div>
                &nbsp;&nbsp;
            <div class="col-sm-3 col-lg-3">
                  <input type="submit" name="sumit" class="btn btn-primary btn-lg"style ="margin-left:30px; background-color:#3cb371;" value="Next" />
            </div>
            <div class="col-sm-3 col-lg-3">

            </div>
      </div>
    </form>

    <div class ="row">
        <div class="col-sm-3 col-lg-3">  
        </div>
      </div>
      </div>
          </div>
          </div>

          <div class="col-sm-1"></div>
      </div>
    </div>


 <!-- ******begining of the footer****************-->
   <footer style="margin-top:40px;">
    <div class ="navbar navbar-inverse  navbar-fixed-bottom" style="height: 25px; border-top: 2px solid yellowgreen;">
        <div class="navbar navbar-brand"> 
        <p style ="color: #fff;">Copyright &#169; 2017 | <a href="http://gsu.edu.ng/" target="_blank" >By Nura muhammad sani</a> | All rights reserved.</p>
        </div>
        <div class="icons">
                <a href="www.facebook.com/mautech" title="www.facebook.com/mautech"
                style ="margin-top: 8px;float: right; font-size: 20px; padding: 0px 5px 0px 0px; ">
                <span class="fa fa-facebook-square" style="color: #fff;"></span></a>

                <a href="www.googleplus.com/mautech" title="www.g2ogleplus.com/gme"
                style ="margin-top: 8px;float: right; font-size: 20px; padding: 0px 5px 0px 0px; ">
                <span class="fa fa-google-plus-square" style="color: #fff;"></span></a>

                <a href="www.twitter.com/@glga" title="www.twitter.com/@gme"
                style ="margin-top: 8px;float: right; font-size: 20px; padding: 0px 5px 0px 0px; ">
                <span class="fa fa-twitter-square" style="color: #fff;"></span></a>

                <a href="www.rss.com/gme" title="www.rss.com/gme"
                style ="margin-top: 8px;float: right; font-size: 20px; padding: 0px 5px 0px 0px; ">
                <span class="fa fa-rss-square" style="color: #fff;"></span></a>

                <a href="www.linkedin.com/gme" title="www.linkedlocl.com/gme"
                style ="margin-top: 8px;float: right; font-size: 20px; padding: 0px 5px 0px 0px; ">
                <span class="fa fa-linkedin-square" style="color: #fff;"></span></a>

                <a href="callto:+2347061992697" title="+2347061992697">
                <span class="fa fa-phone-square" style="color: #fff;margin-top: 12px;float: right; font-size: 20px; padding: 0px 5px 0px 0px;"></span></a>

                <a href="mailto:gme@gmail.com" title="gme@gmail.com">
                <span class="glyphicon glyphicon-phone-alt" style="color: #fff; margin-top: 10px;float: right; font-size: 20px; padding: 0px 5px 0px 0px;"></span></a>

                <a href="mailto:gme@gmail.com" title="gme@gmail.com">
                <span class="glyphicon glyphicon-envelope" style="color: #fff; margin-top: 12px;float: right; font-size: 20px; padding: 0px 5px 0px 0px;"></span></a>
                <p> <marquee style="color: #fff;">powered by Briatek Computer Institute</marquee><p>
             <b><a href = "#Top" class="bb" style="float: right;margin-top: 40px;">back to top</a></b>
            </div>

    </div>
 </footer>
 <!-- ************* End of the footer ****************-->
</body>
</html>