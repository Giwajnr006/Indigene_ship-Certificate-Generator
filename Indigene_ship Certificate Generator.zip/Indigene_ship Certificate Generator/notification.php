<?php
session_start();
ob_start();
require "projectconnection.php";

$session = $_SESSION['serial_no'];
$qury = mysqli_query($connection, "SELECT * FROM sign_up WHERE sn ='$session'");
if (!$qury) {
    die("Query failed: " . mysqli_error($connection));
}
$result = mysqli_fetch_array($qury);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Notification</title>
    <link rel="icon" type="image/jpeg" href="img/a1.jpeg">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Linking Bootstrap -->
    <link type="text/css" rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Linking custom CSS -->
    <link rel="stylesheet" type="text/css" href="css/font-awesome.css">
    <link rel="stylesheet" type="text/css" href="css/mystyle.css">
    <!-- Linking JS for Bootstrap -->
    <script type="text/javascript" src="js/jquery-1.11.1.js"></script>
    <script type="text/javascript" src="js/jquery.custom-slider.js"></script>
    <script>
        $(document).ready(function(){
            $(".slider").customslider({ height: "100px", width: "100%", speed: 700 });
        });
    </script>
</head>
<body style="background-image: url(images/80.png);background-size: cover;background-attachment: fixed;">

<!-- Header -->
<div class="navbar navbar-default navbar-fixed-top" style="background-color:#3cb371; height: 60px; border-bottom: 2px solid; color: yellow;">
    <div class="navbar-brand">
        <a href="index.html"><img src="img/a1.jpeg" width="65%" height="65%" style="margin-top: -15px; float: left;" class="img-responsive img-circle"></a>
    </div>
    <p class="txtlogo" style="color:#fff; margin-top:25px; margin-left: -190px; font-size: 20px;">LOCAL GOVERNMENT
        <a href="home.php" style="margin-left: 200px; color: #fff;"><span class="glyphicon glyphicon-log-out" style="margin-top:0px; margin-left: 200px; color:#fff;"> </span> Logout</a>
    </p>
</div>

<nav class="navbar navbar-default navbar-static-top" role="navigation" style="background-color:#fff; margin-top: -3px; border-bottom: 2px solid; color: yellow;">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#col">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
        </div>
        <div class="collapse navbar-collapse" id="col">
            <ul class="nav navbar-nav">
                <li><a href="home.php"><span class="glyphicon glyphicon-home"></span> Home <span class="sr-only">(Current)</span></a></li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                        <span class="glyphicon glyphicon-user"></span> WELCOME <?php echo strtoupper($result['fname']); ?><span class="caret"></span></a>
                    <ul class="dropdown-menu" role="menu">
                        <li><a href="home.php">Logout</a></li>
                        <li class="divider"></li>
                        <li><a href="create_acaunt.php"></a></li>
                        <li class="divider"></li>
                        <li><a href="biodata"></a></li>
                        <li class="divider"></li>
                        <li class="divider"></li>
                        <li><a href="#"></a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>

<div class="container" style="margin-top: 120px;">
    <div class="row">
        <div class="col-sm-2 col-xs-2 ol-md-2 col-lg-2"></div>
        <div class="col-sm-8 col-xs-8 ol-md-8 col-lg-8">
            <div class="panel panel-default">
                <div class="well" style="background-color: #2E8B57; color: #fff; font-style: italic;">
                    WELCOME <?php echo strtoupper($result['fname']); ?>
                    <span class="glyphicon glyphicon-asterisk" style="margin-top: -10px; float: right; font-size: 35px; color: #fff;"> </span>
                </div>
                <div class="panel-body">
                    <p style="font-weight: 200; color: #000;">
                        <?php
                        $qury = mysqli_query($connection, "SELECT * FROM biodata2 WHERE sn ='$session' AND approve='1'");
                        if (mysqli_num_rows($qury) > 0) {
                            while ($row = mysqli_fetch_array($qury)) {
                                $fname = strtoupper($row['fname']);
                                $mname = strtoupper($row['mname']);
                                $lname = strtoupper($row['lname']);
                                echo "<div class='alert alert-success'><strong>Hello,&emsp;</strong>$fname&emsp;$mname&emsp;$lname your application is successfully approved and your indigene letter is ready for collection at Gombe Local Government. Thank you</div>";
                            }
                        } else {
                            echo "<div class='alert alert-danger'><strong>Hello,&emsp;</strong> your application is yet to be approved. Please try again later. Thank you.</div>";
                        }
                        ?>
                    </p>
                    <a href="mydashboard.php" role="button" class="btn btn-primary btn-lg" style="margin-left: 500px; margin-top: -10px; background-color: #3cb371;">Back</a>
                </div>
            </div>
        </div>
        <div class="col-sm-2 col-xs-2 ol-md-2 col-lg-2"></div>
    </div>
</div>

<!-- Footer -->
<div class="footer" style="margin-top: 45px; background-color: #2E8B57; opacity: 0.9;">
    <div class="navbar navbar-inverse navbar-fixed-bottom" style="height: 50px; background-color: #2E8B57; border-top: 2px solid yellow;">
        <div class="navbar-brand">
            <p>
                <marquee direction="left" style="color: yellow;">
                    Welcome to indigeneship online application.
                    Copyright &#169; 2018 | <a href="http://Gombe.gme.ng/" target="_blank" style="color: yellow">Gombe.gme.ng</a> | All rights reserved.
                
                    Welcome to indigeneship online application.
                    Copyright &#169; 2024 | <a href="http://Gombe.gme.ng/" target="_blank" style="color: yellow">Gombe.gme.ng</a> | All rights reserved.
                </marquee>
                <b><a href="#Top" class="bb" style="float: right; margin-top: 40px;">Back to top</a></b>
            </p>
        </div>
    </div>
</div>

<!-- Linking Bootstrap JS -->
<script type="text/javascript" src="js/bootstrap.min.js"></script>
</body>
</html>
