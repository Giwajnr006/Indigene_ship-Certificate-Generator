-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 28, 2018 at 08:57 AM
-- Server version: 5.5.27
-- PHP Version: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `myproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `biodata`
--

CREATE TABLE IF NOT EXISTS `biodata` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(100) NOT NULL,
  `mname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `dob` date NOT NULL,
  `gender` varchar(100) NOT NULL,
  `mstatus` varchar(100) NOT NULL,
  `ward` varchar(100) NOT NULL,
  `phone_no` int(45) NOT NULL,
  `tribe` varchar(45) NOT NULL,
  `nationality` varchar(45) NOT NULL,
  `state` varchar(45) NOT NULL,
  `lga` varchar(45) NOT NULL,
  `caddress` varchar(300) NOT NULL,
  `comdate` date NOT NULL,
  `passport` varchar(300) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=24 ;

--
-- Dumping data for table `biodata`
--

INSERT INTO `biodata` (`id`, `fname`, `mname`, `lname`, `dob`, `gender`, `mstatus`, `ward`, `phone_no`, `tribe`, `nationality`, `state`, `lga`, `caddress`, `comdate`, `passport`) VALUES
(3, 'abubakar', 'sadiq', 'muhammad', '1994-01-06', 'Male', 'single', 'dawaki quaters', 2147483647, 'hausa', 'Nigeria', 'Gombe', 'Kaltungo', '', '0000-00-00', ''),
(4, 'nura', 'muhammad', 'sani', '1987-01-01', 'Male', 'single', 'tunfure', 2147483647, 'hausa', 'Nigeria', 'Gombe', 'Kaltungo', '', '0000-00-00', ''),
(5, 'fatima', 'muhammad', 'bello', '1997-02-12', 'Male', 'single', 'fatima@gmail.com', 2147483647, 'fulani', 'Nigeria', 'Gombe', 'dukku', 'tunfure investment quarters', '0000-00-00', ''),
(6, 'yusuf ', 'sulaiman', 'ali', '1994-03-06', 'Male', 'single', 'yusuf111@gmail.com', 2147483647, 'kanuri', 'Nigeria', 'Gombe', 'Kawmi', 'tudun wada shamaki word', '0000-00-00', ''),
(9, 'nura', 'muhammad', 'sani', '0993-09-03', 'Male', 'single', 'nnnn@gmail.com', 2147483647, 'fulani', 'Nigeria', 'Gombe', 'Y/Deba', 'tunfure investiment quarters', '0000-00-00', ''),
(11, 'nura', 'muhammad', 'sani', '1993-09-30', 'Male', 'single', 'nuramuhammad131@gmail.com', 2147483647, 'fulani', 'Nigeria', 'Gombe', 'Y/Deba', 'shamaki word', '0000-00-00', ''),
(12, 'nura', 'muhammad', 'sani', '1993-01-09', 'Male', 'single', 'nnnn@gmail.com', 2147483647, 'fulani', 'Nigeria', 'Gombe', 'Y/Deba', 'nnnn', '0000-00-00', ''),
(15, 'nura', 'muhammad', 'sani', '2017-10-04', 'Male', 'single', 'www', 2147483647, 'fulani', 'Nigeria', 'Gombe', 'Select your local:', 'nnnnn', '0000-00-00', ''),
(16, 'nura', 'muhammad', 'sani', '1992-11-04', 'Male', 'single', 'rrr', 2147483647, 'yarabawa', 'Nigeria', 'Gombe', 'Gombe', 'hhhhh', '0000-00-00', ''),
(17, 'fatima', 'muhammad', 'bello', '1997-12-11', 'Male', 'single', 'dawaki', 2147483647, 'fulani', 'Nigeria', 'Gombe', 'Y/Deba', 'tunfure investment quaters', '0000-00-00', ''),
(18, '', '', '', '0000-00-00', 'Male', 'single', '', 0, 'Select tribe:', 'Nigeria', 'Gombe', 'Select your local:', '', '0000-00-00', ''),
(19, 'sadiqu', 'kabir', 'abbas', '1996-02-03', 'Male', 'single', 'dawaki ', 2147483647, 'bolewa', 'Nigeria', 'Yobe', 'Gombe', 'abuja quaters', '0000-00-00', ''),
(20, 'salis', 'adamu', 'muhammad', '1994-01-09', 'Male', 'married', 'shamaki', 2147483647, 'hausa', 'Nigeria', 'Gombe', 'Gombe', 'shongo estate', '0000-00-00', ''),
(21, 'nura', 'muhammad', 'kabir', '1997-02-09', 'Male', 'married', 'malam inna', 2147483647, 'fulani', 'Nigeria', 'Gombe', 'Gombe', 'government residence areas i.e GRA', '0000-00-00', ''),
(22, 'nura', 'muhammad', 'sani', '1995-10-09', 'Male', 'married', 'SHAMAKI', 2147483647, 'hausa', 'Nigeria', 'Gombe', 'Gombe', 'FEDERAL LOWCOST', '0000-00-00', ''),
(23, 'sadiqu', 'ALHASAN', 'ABDULLAHI', '1998-02-09', 'Male', 'single', 'SHAMAKI', 2147483647, 'fulani', 'Nigeria', 'Gombe', 'Gombe', 'ABUJA', '0000-00-00', '');

-- --------------------------------------------------------

--
-- Table structure for table `biodata2`
--

CREATE TABLE IF NOT EXISTS `biodata2` (
  `id` int(200) NOT NULL AUTO_INCREMENT,
  `sn` varchar(700) NOT NULL,
  `fname` varchar(300) NOT NULL,
  `mname` varchar(300) NOT NULL,
  `lname` varchar(300) NOT NULL,
  `dob` varchar(200) NOT NULL,
  `gender` varchar(300) NOT NULL,
  `mstatus` varchar(300) NOT NULL,
  `ward` varchar(300) NOT NULL,
  `phoneNo` varchar(200) NOT NULL,
  `tribe` varchar(300) NOT NULL,
  `nationality` varchar(300) NOT NULL,
  `state` varchar(300) NOT NULL,
  `lga` varchar(200) NOT NULL,
  `religion` varchar(300) NOT NULL,
  `email` varchar(300) NOT NULL,
  `address` varchar(300) NOT NULL,
  `caddress` varchar(300) NOT NULL,
  `comdate` varchar(200) NOT NULL,
  `approve` int(11) NOT NULL DEFAULT '0',
  `approveDate` varchar(700) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=39 ;

--
-- Dumping data for table `biodata2`
--

INSERT INTO `biodata2` (`id`, `sn`, `fname`, `mname`, `lname`, `dob`, `gender`, `mstatus`, `ward`, `phoneNo`, `tribe`, `nationality`, `state`, `lga`, `religion`, `email`, `address`, `caddress`, `comdate`, `approve`, `approveDate`) VALUES
(11, '950780', 'fatima', 'muhammad', 'sani', '1999-09-08', 'Male', 'single', 'hh', '0906754', 'fulani', 'Nigeria', 'Gombe', 'Gombe', 'Islam', 'mll@m', 'mm,kk', 'hhhhgf', '2017-10-20', 1, '2017-10-28'),
(12, '788407', 'umar', 'abdullahi', 'sambo', '2017-10-18', 'Male', 'married', 'SHAMAKI', '08032771517', 'kanuri', 'Nigeria', 'Gombe', 'Akko', 'Islam', 'umarictgsu', 'tudun wada', 'tudun wada', '2017-10-27', 1, '2017-10-28'),
(13, '528370', 'fatima', 'abubakar', 'sadiq', '1999-02-09', 'Female', 'single', 'dawaki', '08176908707', 'fulani', 'Nigeria', 'Gombe', 'Gombe', 'Islam', 'abubakar@gmail.com', 'asdfghjkl', 'rtyuifghj', '2017-10-28', 1, '2017-10-28'),
(14, '749299', 'musa', 'usman', 'bello', '2017-10-11', 'Male', 'single', 'dd', '08076588790', 'fulani', 'Nigeria', 'Gombe', 'Gombe', 'Islam', 'musa@gmail.com', 'DFGHJK', 'OIUHG', '2017-10-28', 1, '2017-10-28'),
(15, '459195', 'shanono', 'usman', 'garba', '2017-10-05', 'Male', 'married', 'jjj', '0908765897876', 'hausa', 'Nigeria', 'Gombe', 'Gombe', 'Islam', 'SHANONO@GMAIL.COM', 'JJKJJKJK', 'KIUYTR', '2017-10-28', 1, '2017-10-28'),
(17, '761015', 'husaini', 'muhammad', 'sani', '1996-08-04', 'Male', 'married', 'bomala', '098067895400', 'fulani', 'Nigeria', 'Gombe', 'Gombe', 'Islam', 'husaina@gmail.com', 'bcj', 'bcj', '2017-10-30', 1, '2017-10-30'),
(18, '563734', 'muhammad', 'adamu', 'jalo', '2017-10-18', 'Male', 'single', 'shamaki', '0300860984', 'fulani', 'Ghana', 'Gombe', 'Gombe', 'Islam', 'mn@gmacom', 'drwgb', 'qwsdcvkjb', '2017-10-31', 1, '2017-11-24'),
(19, '850414', 'SADIYA', 'salisu', 'AHMAD', '1997-09-08', 'Female', 'single', 'SHAMAKI', '08067890234', 'fulani', 'Nigeria', 'Gombe', 'Gombe', 'Islam', 'uuu', 'shamaki', 'jauro kuna', '2017-11-01', 1, '2017-11-01'),
(20, '969157', 'SADIYA', 'IBRAHIM', 'sale', '2017-11-08', 'Female', 'single', 'SHAMAKI', '08076589757', 'hausa', 'Nigeria', 'Gombe', 'Gombe', 'Islam', 'ssss@gmail.com', 'BCJ', 'bcj', '2017-11-03', 1, '2017-12-02'),
(21, '940401', 'abdulhamid', 'adamu', 'musa', '2017-11-09', 'Male', 'single', 'hammmadu kafi', '08032771514', 'fulani', 'Nigeria', 'Gombe', 'Gombe', 'Islam', 'adamu@gmail.com', 'dfghj', 'cdfvghjk', '2017-11-03', 1, '2017-12-02'),
(22, '255306', 'amina', 'yusuf', 'ali', '2017-11-08', 'Male', 'married', 'SHAMAKI', '056780964546', 'fulani', 'Nigeria', 'Gombe', 'Gombe', 'Islam', 'aya@gmail.com', 'shamaki', 'bomala', '2017-11-04', 1, '2017-11-05'),
(23, '458312', 'aishatu ', 'adamu', 'BALA', '2017-11-13', 'Female', 'single', 'shamaki0', '08199789098', 'kanuri', 'Nigeria', 'Gombe', 'Gombe', 'Islam', 'aab@gmail.com', 'by fast', ' by fast', '2017-11-04', 1, '2017-11-08'),
(24, '813525', 'asdf', 'edrty', 'dfgh', '2017-11-15', 'Female', 'married', 'SHAMAKI', '09808754266', 'fulani', 'Nigeria', 'Gombe', 'dukku', 'Islam', 'fmb@gmail.com', 'wertyu', 'cfghjkjhg', '2017-11-07', 1, '2017-11-07'),
(25, '721425', 'kalil', 'adamu', 'jalo', '2017-11-09', 'Male', 'single', 'SHAMAKI', '087654345678', 'fulani', 'Nigeria', 'Gombe', 'Gombe', 'Islam', '000089786543', 'ASDFGHJK', 'WSEDRTYUI', '2017-11-08', 1, '2017-11-08'),
(26, '203839', 'hafsat', 'muhammad', 'SANI', '1927-12-03', 'Female', 'single', 'shamaki', '07061992697', 'fulani', 'Nigeria', 'Gombe', 'Gombe', 'Islam', 'NNNN', 'WWWW', 'HHHHJ', '2017-12-02', 1, '2017-12-02'),
(27, '908006', 'francis', 'mamudu', 'i', '2017-12-04', 'Male', 'married', 'dfghj', '2345678967', 'hausa', 'Nigeria', 'Gombe', 'Gombe', 'Christianity', 'WERTYUIOP', 'QWERTYUIOL', 'DFGHJL', '2017-12-03', 1, '2017-12-03'),
(28, '560524', 'maryam', 'mukutar', 'muhammad', '2017-12-04', 'Female', 'single', 'SHAMAKI', '34567890-56789', 'hausa', 'Nigeria', 'Gombe', 'Gombe', 'Select Religion', 'wertyu', 'qwertyuio', '3e4r5tyu8i', '2017-12-03', 1, '2017-12-03'),
(29, '293479', 'abubakar', 'IBRAHIM', 'muhammad', '2017-12-14', 'Male', 'single', 'SHAMAKI', '09087656555', 'fulani', 'Nigeria', 'Gombe', 'Gombe', 'Islam', 'aim@mail.com', 'adfadfghj', 'adfghsstaj', '2017-12-04', 0, ''),
(30, '529467', 'ali', 'isa', 'gombe', '2017-12-14', 'Male', 'single', 'dawaki ', '98706663566', 'fulani', 'Nigeria', 'Gombe', 'Gombe', 'Islam', 'aig', 'wertyui', 'ertyui', '2017-12-04', 1, '2018-07-26'),
(31, '219087', 'mansir', 'alhaji', 'junaidu', '1999-09-01', 'Male', 'married', 'kuri', '0808890989', 'fulani', 'Nigeria', 'Gombe', 'Y/Deba', 'Islam', 'maj@gmail.com', 'kuri', 'kuri11', '2018-03-18', 1, '2018-03-18'),
(32, '346310', 'm', 'u', 'a', '2018-04-05', 'Male', 'single', 'shamaki', '0909888', 'hausa', 'Nigeria', 'Gombe', 'Gombe', 'Islam', 'werrr@gmail.com', 'sdfghjkfghjk', 'rtytiuolj;gfj', '2018-04-14', 1, '2018-04-14'),
(33, '659205', 'asiya', 'IBRAHIM', '', '1998-07-05', 'Female', 'single', 'tudun wada', '8012566551', 'bolewa', 'Nigeria', 'Gombe', 'dukku', 'Islam', 'ai@gmail.com', 'tunwada', 'tudunwa', '2018-07-18', 1, '2018-07-18'),
(34, '377072', 'adam', 'bala', 'adam', '2018-07-06', 'Male', 'single', 'sss', '567890-', 'hausa', 'Nigeria', 'Gombe', 'Gombe', 'Islam', 'aba@gmail.com', 'qqqqqwer', 'qqer', '2018-07-26', 1, '2018-07-26'),
(35, '373060', 'abubakar', 'zambok', 'yu', '2018-07-11', 'Male', 'single', 'shamaki', '07083772483', 'fulani', 'Nigeria', 'Gombe', 'Gombe', 'Islam', 'wertyu', 'wertyuio', 'wertyuio', '2018-07-27', 1, '2018-07-27'),
(36, '508468', 'musa', 'sani', 'HJK', '2018-07-04', 'Female', 'married', 'hammmadu kafi', '07061992697', 'fulani', 'Nigeria', 'Gombe', 'Y/Deba', 'Islam', 'sdfghj@gmail.com', 'wwerrty', 'awwwww', '2018-07-29', 0, ''),
(37, '730493', 'awwal', 'muhammad', 'yusuf', '2018-08-08', 'Male', 'single', 'shamaki', '677890', 'fulani', 'Niger', 'Gombe', 'dukku', 'Islam', 'nuramuhammad131@gmail.com', 'wertyui', 'fghj', '2018-08-06', 1, '2018-08-06'),
(38, '187682', 'haruna', 'ahmed', '', '2018-08-09', 'Male', 'married', 'SHAMAKI', '567890-', 'fulani', 'Camaroon', 'Maiduguri', 'Balagga', 'Islam', 'nnnn@gmail.com', 'werty', 'wertgh', '2018-08-06', 1, '2018-08-06');

-- --------------------------------------------------------

--
-- Table structure for table `cantact_tbl`
--

CREATE TABLE IF NOT EXISTS `cantact_tbl` (
  `id` int(200) NOT NULL AUTO_INCREMENT,
  `name` varchar(300) NOT NULL,
  `email` varchar(300) NOT NULL,
  `phone` int(200) NOT NULL,
  `message` varchar(300) NOT NULL,
  `comdate` varchar(300) NOT NULL,
  `active_flag` enum('1','0') NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `cantact_tbl`
--

INSERT INTO `cantact_tbl` (`id`, `name`, `email`, `phone`, `message`, `comdate`, `active_flag`) VALUES
(1, 'nura m sani', 'nuramuhammad131@gmail.com', 2147483647, 'assalamu alaikum', '2017-10-04 09:37:21', '1'),
(3, 'fatima muhammad', 'fatima@gmail.com', 2147483647, 'i was apply since last two weeks but there no any information', '04-10-17 10:01:19', '1'),
(4, 'musa', 'musamuhammadjamari@gmail.com', 2147483647, 'why this site?', '03-11-17 06:16:39', '1'),
(5, 'nura m sani', 'nnnn@gmail.com', 890878907, 'how', '05-11-17 06:44:32', '1'),
(6, 'hafsat muhammad sani', 'hafsat@gmail.com', 80786543, 'how long should it before it ready for collection', '02-12-17 10:03:29', '1'),
(7, 'sani yahaya', 'saniy@gmail.com', 2147483647, 'sghjklijniujhb', '02-12-17 10:05:57', '1'),
(8, 'nura m sani', 'yyy@gmail.com', 2147483647, 'hjkllkjkl', '02-12-17 10:07:22', '1'),
(9, 'aisha abdulhamid', 'aab@gmail.com', 903468796, 'rtyuiop', '02-12-17 10:09:45', '1'),
(10, 'NNNN', 'NNNN', 2147483647, 'rhgjjf', '02-12-17 10:13:54', '1'),
(11, 'sdfghjk', 'sdfghj', 0, 'sdfghjikol', '02-12-17 10:15:03', '1'),
(12, 'nura m sani', 'nuramuhammad131@gmail.com', 2147483647, 'i did not see anything', '18-03-18 05:28:31', '1'),
(13, 'asiya', 'ibrahim', 2147483647, 'i have been since but there is no request', '13-08-18 07:39:50', '1');

-- --------------------------------------------------------

--
-- Table structure for table `complent_tbl`
--

CREATE TABLE IF NOT EXISTS `complent_tbl` (
  `comment_id` int(200) NOT NULL AUTO_INCREMENT,
  `comment` varchar(300) NOT NULL,
  `commentor` varchar(300) NOT NULL,
  `comment_date` varchar(300) NOT NULL,
  `active_flag` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`comment_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `complent_tbl`
--

INSERT INTO `complent_tbl` (`comment_id`, `comment`, `commentor`, `comment_date`, `active_flag`) VALUES
(1, 'hy', 'nura muhammad sani', '01-10-17 08:06:25', 1);

-- --------------------------------------------------------

--
-- Table structure for table `sign_up`
--

CREATE TABLE IF NOT EXISTS `sign_up` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sn` varchar(700) NOT NULL,
  `fname` varchar(300) NOT NULL,
  `mname` varchar(300) NOT NULL,
  `lname` varchar(300) NOT NULL,
  `uname` varchar(300) NOT NULL,
  `password` varchar(300) NOT NULL,
  `cpassword` varchar(300) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=57 ;

--
-- Dumping data for table `sign_up`
--

INSERT INTO `sign_up` (`id`, `sn`, `fname`, `mname`, `lname`, `uname`, `password`, `cpassword`) VALUES
(23, '432472', 'abubakar', 'muhammad', 'sadiq', 'amsadeeq', '12345', '12345'),
(24, '146568', 'aishatu ', 'babayo', 'musa', 'ug11/cssc/1013', '222', '222'),
(25, '950780', 'maryam', 'muhammad', 'kabib', 'maryam112', '999', '999'),
(26, '788407', 'umar', 'Abdullahi', 'Sambo', '', 'umar', 'umar'),
(27, '128832', 'fateemah', 'Abubkar', 'sadeeq', 'fateenah', 'amsadeeq', 'amsadeeq'),
(28, '528370', 'fatma  ', 'bubakar', 'sadiq', 'kko', '000', '000'),
(29, '749299', 'musa', 'usman', 'bello', 'musa11', '432', '432'),
(30, '459195', 'usman', 'shanono', 'garba', 'shanono', '1010', '1010'),
(31, '210634', 'nura', 'muhammad', 'sani', 'SANI6166', 'NURA61', 'NURA61'),
(32, '761015', 'husaini', 'muhammad', 'sani', 'husaini11', 'husaini12', 'husaini12'),
(33, '563734', 'muhammad', 'adamu', 'jalo', 'jalo', 'jalo', 'jalo'),
(34, '850414', 'SADIYA', 'salisu', 'AHMAD', 'SSA', 'SSA', 'SSA'),
(35, '969157', 'sadiqu', 'IBRAHIM', 'sale', 'sdy', 'sdy', 'sdy'),
(36, '272293', '', '', '', '', '', ''),
(37, '940401', 'abdulhamid', 'adam', '', 'adamu11', 'ad', 'ad'),
(38, '255306', 'amina', 'yususu', 'ali', 'aya', 'aya', 'aya'),
(39, '458312', 'aishatu ', 'adamu', 'BALA', 'AAB', 'AAB', 'AAB'),
(40, '813525', 'fatima', 'm', 'bello', 'fmb', 'fmb', 'fmb'),
(41, '779927', 'muhammad', 'A', 'jalo', 'maj', 'maj', 'maj'),
(42, '721425', 'kalil', 'adamu', 'jalo', 'kaj', 'kaj', 'kaj'),
(43, '203839', 'hafsat ', 'muhammad', 'sani', 'hms', 'hms', 'hms'),
(44, '908006', 'mamudu', 'francis', 'i', 'faso', 'faso', 'faso'),
(45, '560524', 'maryam', 'mukatar', 'muhammad', 'mmm', 'mmm', 'mmm'),
(46, '293479', 'abubakar', 'IBRAHIM', 'muhammad', 'aim', 'aim', 'aim'),
(47, '529467', 'ali', 'isa', 'gombe', 'aig', 'aig', 'aig'),
(48, '219087', 'mansir', 'alhaji', 'jnaidu', 'maj', 'maj1', 'maj1'),
(49, '346310', 'muhammad', 'usman', 'ABDULLAHI', 'mua', 'asamau', 'asamau'),
(50, '659205', 'asiya', 'IBRAHIM', '', 'ib', 'ib', 'ib'),
(51, '377072', 'adam', 'bala', 'adam', 'aba', 'aba', 'aba'),
(52, '373060', 'abubakar', 'zambok', '', 'az', 'az', 'az'),
(53, '508468', 'musa', 'sani', 'HJK', 'ms', 'ms', 'ms'),
(54, '730493', 'awwal', 'muhammad', 'yusuf', 'amy', 'amy', 'amy'),
(55, '187682', 'haruna', 'ahmed', '', 'ha', 'ha', 'ha'),
(56, '537920', 'sani', 'muhammad', 'babayo', '', '1050', '1050');

-- --------------------------------------------------------

--
-- Table structure for table `upload_image`
--

CREATE TABLE IF NOT EXISTS `upload_image` (
  `id` int(200) NOT NULL AUTO_INCREMENT,
  `sn` varchar(700) NOT NULL,
  `passpord` varchar(300) NOT NULL,
  `form` varchar(700) NOT NULL,
  `primary_c` varchar(300) NOT NULL,
  `birth_c` varchar(300) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=57 ;

--
-- Dumping data for table `upload_image`
--

INSERT INTO `upload_image` (`id`, `sn`, `passpord`, `form`, `primary_c`, `birth_c`) VALUES
(8, '', 'yourpassport.', '', 'pirmarycertificate.', 'Birthcertificate.'),
(10, '', 'yourpassport.png', '', 'pirmarycertificate.jpg', 'Birthcertificate.jpg'),
(11, '', 'yourpassport.png', '', 'pirmarycertificate.jpg', 'Birthcertificate.jpg'),
(12, '', 'yourpassport.jpg', '', 'pirmarycertificate.jpg', 'Birthcertificate.jpg'),
(13, '', 'yourpassport.jpg', '', 'pirmarycertificate.jpg', 'Birthcertificate.jpg'),
(14, '', 'yourpassport.jpg', '', 'pirmarycertificate.jpg', 'Birthcertificate.jpg'),
(15, '', 'yourpassport.png', '', 'pirmarycertificate.jpg', 'Birthcertificate.jpg'),
(16, '', 'yourpassport.png', '', 'pirmarycertificate.jpg', 'Birthcertificate.jpg'),
(17, '146568', 'yourpassport.png', '', 'pirmarycertificate.jpg', 'Birthcertificate.jpg'),
(19, '788407', 'yourpassport.jpg', 'identificationLetter.jpg', 'pirmarycertificate.jpg', 'Birthcertificate.jpg'),
(20, '528370', 'yourpassport.jpg', 'identificationLetter.png', 'pirmarycertificate.jpg', 'Birthcertificate.jpg'),
(21, '749299', 'yourpassport.jpg', 'identificationLetter.jpg', 'pirmarycertificate.jpg', 'Birthcertificate.jpg'),
(22, '749299', 'IMG-20170729-WA0005.jpg.jpg', 'form2.png.png', '07 001.jpg.jpg', '05 001.jpg.jpg'),
(26, '210634', '01 001.jpg.jpg', '02 001.jpg.jpg', '04 001.jpg.jpg', '05 001.jpg.jpg'),
(27, '761015', '20170820_121210.jpg.jpg', 'form2.png.png', '07 001.jpg.jpg', '03 001.jpg.jpg'),
(28, '563734', 'IMG-20170705-WA0003.jpg.jpg', 'form2.png.png', '07 001.jpg.jpg', '03 001.jpg.jpg'),
(29, '850414', 'DSC_0000704.jpg.jpg', 'form2.png.png', '07 001.jpg.jpg', '05 001.jpg.jpg'),
(31, '969157', 'DSC_0000085.jpg.jpg', 'form2.png.png', '07 001.jpg.jpg', '05 001.jpg.jpg'),
(33, '255306', 'DSC_0000014.jpg.jpg', 'form2.png.png', '07 001.jpg.jpg', '05 001.jpg.jpg'),
(35, '458312', 'SHAHID.JPG.jpg', 'form2.png.png', '07 001.jpg.jpg', '05 001.jpg.jpg'),
(36, '813525', 'DSC_0000261.jpg.jpg', 'form2.png.png', '07 001.jpg.jpg', '05 001.jpg.jpg'),
(37, '721425', 'SHAHID.JPG.jpg', 'form2.png.png', '07 001.jpg.jpg', '05 001.jpg.jpg'),
(38, '721425', '20170711_074451.jpg.jpg', '.', '.', '.'),
(39, '203839', '2017-03-11 16.22.18-1.jpg.jpg', 'form2.png.png', '07 001.jpg.jpg', '05 001.jpg.jpg'),
(40, '908006', 'SHAHID.JPG.jpg', 'form2.png.png', '07 001.jpg.jpg', '05 001.jpg.jpg'),
(41, '908006', 'SHAHID.JPG.jpg', 'form2.png.png', '07 001.jpg.jpg', '05 001.jpg.jpg'),
(42, '560524', 'SHAHID.JPG.jpg', 'form2.png.png', '07 001.jpg.jpg', '05 001.jpg.jpg'),
(43, '560524', '2017-03-11 16.22.18-1.jpg.jpg', '.', '.', '.'),
(44, '293479', 'IMG-20170705-WA0003.jpg.jpg', 'form2.png.png', '07 001.jpg.jpg', '05 001.jpg.jpg'),
(45, '529467', 'IMG-20151211-WA0001.jpg.jpg', 'form2.png.png', '07 001.jpg.jpg', '05 001.jpg.jpg'),
(46, '219087', '20170711_074456.jpg.jpg', 'IMG_20180103_115444.jpg.jpg', '20170710_182716.jpg.jpg', '20170815_123320.jpg.jpg'),
(47, '346310', '20170708_174540.jpg.jpg', '20170711_074451.jpg.jpg', '20170711_074456.jpg.jpg', '20170816_170503.jpg.jpg'),
(48, '659205', 'DSC_0000067.jpg.jpg', 'form2.png.png', '07 001.jpg.jpg', '05 001.jpg.jpg'),
(49, '377072', 'SHAHID.JPG.jpg', 'form2.png.png', '07 001.jpg.jpg', '05 001.jpg.jpg'),
(50, '373060', 'SHAHID.JPG.jpg', 'form2.png.png', '07 001.jpg.jpg', '05 001.jpg.jpg'),
(51, '508468', 'SHAHID.JPG.jpg', '04 001.jpg.jpg', '07 001.jpg.jpg', '05 001.jpg.jpg'),
(52, '508468', 'SHAHID.JPG.jpg', 'form2.png.png', '07 001.jpg.jpg', '05 001.jpg.jpg'),
(53, '508468', 'SHAHID.JPG.jpg', 'form2.png.png', '07 001.jpg.jpg', '05 001.jpg.jpg'),
(54, '730493', 'SHAHID.JPG.jpg', 'form2.png.png', '07 001.jpg.jpg', '05 001.jpg.jpg'),
(55, '730493', '20170711_075957.jpg.jpg', 'form2.png.png', '07 001.jpg.jpg', '05 001.jpg.jpg'),
(56, '187682', '20170711_074451.jpg.jpg', 'form2.png.png', '07 001.jpg.jpg', '05 001.jpg.jpg');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
