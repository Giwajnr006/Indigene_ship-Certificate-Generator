<?php
require "connection.php";
$date1 =date('d-m-y h:i:s');
?>
<!DOCTYPE html>
<html>
<head>
    <title>home page</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <link rel="icon" type="text/image" href="img/a1.jpeg">
    <meta name="viewport" content="=device-, initial-scale=1.0"> 
    <!--linking boostrap-->
    <link type="text/css" rel="stylesheet" href="css/bootstrap.min.css">
    <!--linking custom CSS-->
  <link rel="stylesheet" type="text/css" href="css/font-awesome.css">
    <link rel="stylesheet" type="text/css" href="css/mystyle.css">
    <!--linking JS for boostrap-->
  <link rel="shortcut icon" href="../favicon.ico"> 

<style>
  .carousel-inner > .item > img,
  .carousel-inner > .item > a > img {
   width: 80   height: 110%;
      margin: auto;
  }
  </style>
    <!--slider-->
    <link rel="stylesheet" type="text/css" href="css/custom-slider.css"/>
    <script type="text/javascript" src="js/jquery-1.11.1.js"></script>
    <script type="text/javascript" src="js/jquery.custom-slider.js"></script>
    <script>
        $(document).ready(function(){
            $(".slider").customslider({ height:"px", : "%", speed:700 })
        });
    </script>
</head>
<body  style="background-image: url(img/bgg.jpg);background-size: cover;background-attachment: fixed;">
       
<!--header-->
<div class ="navbar navbar-default  navbar-fixed-top" style=" background-color:#2E8B57; height: 60px; border-bottom: 2px solid; color: yellow;">
    <div class="navbar navbar-brand">
        <a <href="index.html"><img src="img/a1.jpeg" width="65%" height="65%"   style="margin-top: -15px;float: left;" class="img-responsive img-circle"></a>
    </div>
    <p class="txtlogo" style="color:#fff; margin-top:25px; margin-left: -190px; font-size: 20px;">GOMBE LOCAL GOVERNMENT

    <img src="img/sarki.jpeg" class=" img-circle" width="40px" height="40px" style="margin-left: 200px; margin-top: -20px;">
    <ul class="nav nav-pills" style="margin-left: 200px; margin-top:-30px;">
        <li><a href="www.facebook.com" ><img src="images/facebook.png"></span></a> </li>
       </li> <a href="www.twitter.com" ><img src="images/twitter.png"></a> </li>
       <li> <a href="www.rss.com" ><img src="images/rss.png"></a> </li>
        <li><a href="www.google.com" ><img src="images/twitter.png"></a> </li>
            </ul>
    
    </p>
 
    <nav class="navbar navbar-default navbar-static-top" role="navigation" style="background-color:#fff;margin-top: -3px;">
        <div class="container-fluid">
            <!--Brand and toggle get grouped-->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" 
                data-target="#col">
                    <span class="sr-only">toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                
                
            </div>
            <!--collect the nav links, forms and other content for toggle-->
            <div class="collapse navbar-collapse" id="col">
                <ul class="nav navbar-nav">
                    <li><a href="home.php">
                    <span class="glyphicon glyphicon-home"></span> Home
                    <span class="sr-only">(Current)</span></a></li>
                    <li><a href="contact.php"><span class="glyphicon glyphicon-glass">
                    </span> Contact Us</a></li>
                    <li class="dropdown" >
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                    <span class="glyphicon glyphicon-user">
                    </span> user site<span class="caret"></span></a>
                        <ul class="dropdown-menu" role="menu">
                            <li><a href="login.php">login</a></li>
                            <li class="divider"></li>
                            <li><a href="create_acaunt.php">sign up </a></li>
                            <li class="divider"></li>
                            <li><a href="biodata">Registration form </a></li>
                            <li class="divider"></li>
                            <li class="divider"></li>
                            <li><a href="#">check approve</a></li>
                        </ul>
                    </li>
                    <li><a href="home.php" style=""><span class="glyphicon glyphicon-log-out" style =""> </span> Logout</a></li>
                </ul>
                
            </div> 
        </div>
    </nav>
</div>
