<?php
    require 'projectconnection.php';

    if (isset($_POST['comment'])) {
        $name = $_POST['name'];
        $email = $_POST['email'];
        $phone = $_POST['phone'];
        $mssge = $_POST['comm'];
        $comdate = date("d-m-y h:i:s");

        $comment = mysql_query("INSERT INTO cantact_tbl(name, email, phone, message, comdate) VALUES ('$name','$email','$phone','$mssge','$comdate')");
        
        if ($comment) {
            $mss = "<div  class ='alert alert-success' style = 'font-size:15px; margin: 0px 65px 20px 65px;'>Your Comment has successfuly sent !</div>";
        }
    }

?>
<!DOCTYPE html>
<html>
<head>
    <title>Contact</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <link rel="icon" type="text/image" href="img/a1.jpeg"> 
    <!--linking boostrap-->
    <link type="text/css" rel="stylesheet" href="css/bootstrap.min.css" />
    
    <!--- I copied from getboostrap.com-->
    <link rel="stylesheet" type="text/css" href="css/font-awesome.css">
    <link rel="stylesheet" type="text/css" href="css/npcprj.css">

    <link rel="icon" href="img/logomautech.png">
    <!-- Latest compiled and minified CSS -->
    
</head>
<body style="background-image: url(images/80.png);background-size: cover;background-attachment: fixed;">
<!--*********************HEADER NAVIGATION**********************************************-->
        <div class ="navbar navbar-default  navbar-fixed-top" style=" background-color:#2E8B57; height: 60px; border-bottom: 2px solid; color: yellow;">
    <div class="navbar navbar-brand">
        <a <href="index.html"><img src="img/a1.jpeg" width="65%" height="65%"   style="margin-top: -15px;float: left;" class="img-responsive img-circle"></a>
    </div>
    <p class="txtlogo" style="color:#fff; margin-top:25px; margin-left: -190px; font-size: 20px;">GOMBE LOCAL GOVERNMENT
    <a href="mydashboard.php" style="margin-left: 200px; color: #fff;"><span class="glyphicon glyphicon-log-out" style =" margin-top:0px; margin-left: 200px; color:#fff;"> </span> Logout</a>
    </p>
 
    </div>
<nav class="navbar navbar-default navbar-static-top" role="navigation" style="background-color:#fff;margin-top: 50px;">
        <div class="container-fluid">
            <!--Brand and toggle get grouped-->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" 
                data-target="#col">
                    <span class="sr-only">toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
             </div>
            <!--collect the nav links, forms and other content for toggle-->
            

        </div>
    </nav>

<!--*********************END OF HEADER NAVIGATION**********************************************-->

<!--%%%%%%%%% CONTACT FORM %%%%%%%%%%%%%%%%%%-->
 <?php
                if (isset($mss)) {
                    echo $mss;
                }
            ?>

<div class="container">
    <div class="row">
        <div class="col-lg-offset-2 col-lg-6">
         
            <div class="panel panel-default" style="background-color: #9dd2a8;opacity:1; margin-bottom: 110px;margin-top: 0px;border-radius: 20px; width: 50%; margin-left: 180PX;">
            <div class="panel-heading" style="color: #fff;font-size: 30px;border-radius: 20px 20pX 0pX 0pX;background-color: #3cb371;">
                <p >CONTACT FORM</p>
            </div>
           
                <div class="panel-body">
                   <form method="post" class="form" role= "form">
                        <div class="form-group input-group">
                            <label class="label" style="font-size: 20px;color: #000;"></label>
                            <input type="text" name="name" class="form-control inputs" placeholder="Your Name" size="50%" required />
                        </div>
                        <div class="form-group input-group">
                            <label class="label" style="font-size: 20px;color: #000;"></label>
                            <input type="text" name="email" placeholder=" Your Email" class="form-control inputs" size="50%" required />
                        </div>
                        <div class="form-group input-group">
                            <label class="label" style="font-size: 20px;color: #000;"></label>
                            <input type="text" name="phone"placeholder=" Your Phone No." class="form-control inputs" size="50%" required />
                        </div>
                        <div class="form-group input-group">
                            <label class="label" style="font-size: 20px;color: #000;"></label>
                            <textarea cols="45" name="comm" rows="8" placeholder ="Write your complaints"class="form-control" style="border-radius: 40px;"></textarea>
                        </div>
                        <div class="form-group input-group">
                            <input type="submit" name="comment" class="btn btn-lg btn-outline btn-default" value="Send Message" style="background-color:#3cb371;color: #fff;">
                        </div>
                        <a href="#top" class ="btn btn-info btn-lg"style="float: right;color: #fff; background-color:#3cb371; margin-top:-0px; font-size: 13px;"role="button"> Back to top</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
</div>
<!--%%%%%%%%% END CONTACT FORM %%%%%%%%%%%%%%%%%%-->

<!--%%%%%%%%% FOOTER  %%%%%%%%%%%%%%%%%%
<div class="navbar navbar-inverse navbar-fixed-bottom" style="background-color:; height: 35px;  border-top: 2px solid yellow;">
            
            <div class="navbar-header">
                <div class="navbar-brand">
                    <marquee style="color: #fff;">powered by Briatek Computer Institute</marquee>
                </div>
            </div>
        </div>-->
<!--%%%%%%%%% END OF FOOTER  %%%%%%%%%%%%%%%%%%-->


<!---scripft -->
 <!-- jQuery -->
    
     <script src="js/jquery.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    

<script>
    $(function(){
        $('.nav-tabs a:first').tab('show');
    });
</script>
<script>
$(document).ready(function(){
    $('[data-toggle="popover"]').popover(); 
});
</script>
</body>
</html>