<?php
session_start();
require "projectconnection.php";

// Ensure the session variable is set
if (!isset($_SESSION['serial_no'])) {
    die("Session not set. Please log in.");
}

$session = $_SESSION['serial_no'];
$qury = mysqli_query($connection, "SELECT * FROM sign_up WHERE sn = '$session'");

if (!$qury) {
    die("Query failed: " . mysqli_error($connection));
}

$result = mysqli_fetch_array($qury);
$fname = ($result['fname']);
$mname = ($result['mname']);
$lname = ($result['lname']);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Print Form</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="icon" type="image/jpeg" href="img/a1.jpeg">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Linking Bootstrap -->
    <link type="text/css" rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Linking custom CSS -->
    <link rel="stylesheet" type="text/css" href="css/mystyle.css">
    <!-- Linking JS for Bootstrap -->
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
</head>
<body style="background-image: url(images/80.png);background-size: cover;background-attachment: fixed;">
<div class="navbar navbar-default navbar-fixed-top" style="background-color:#3cb371; height: 60px; border-bottom: 2px solid; color: yellow;">
    <div class="navbar-brand">
        <a href="index.html"><img src="img/a1.jpeg" width="65%" height="65%" style="margin-top: -15px; float: left;" class="img-responsive img-circle"></a>
    </div>
    <p class="txtlogo" style="color:#fff; margin-top:25px; margin-left: -190px; font-size: 20px;">
        INDGENE APPLICATION
        <a href="mydashboard.php" style="margin-left: 200px; color: #fff;">
            <span class="glyphicon glyphicon-log-out" style="margin-top:0px; margin-left: 200px; color:#fff;"></span> Logout
        </a>
    </p>
</div>

<div class="container" style="margin-top: 70px;">
    <div class="row">
        <div class="col-sm-3"></div>
        <div class="col-sm-6">
            <div class="panel panel-default">
                <div class="panel-body">
                    <form role="form" method="POST" action="biodata.php">
                        <table class="table">
                            <tr>
                                <th><img src="images/flag.jpeg" width="60" style="margin-left: 200px;"></th>
                            </tr>
                            <tr>
                                <th>
                                    <p style="margin-left: 140px; font-size: 17px;">GOMBE LOCAL GOVERNMENT</p>
                                    <p style="font-size: 18px; margin-left: 190px;">GOMBE STATE</p>
                                    <p style="margin-left: 175px; font-size: 15px;">OF NIGERIA.</p>
                                    <p style="font-size: 16px; margin-left: 130px;">IDENTIFICATION LETTER.</p>
                                </th>
                            </tr>
                            <tr>
                                <td>
                                    <p style="font-size: 15px;">
                                        This is to certify that the bearer whose name <?php echo "<span style='color:red'>$fname $mname $lname</span>" ?> is an indigene of ................ district local government of state, he was born and bred at .................................. local government. Therefore any alteration suspected or discovered renders this form invalid and hence should not be signed.
                                    </p>
                                    <p style="font-size: 20px;">
                                        <br>
                                        <br>
                                        <br>
                                        Applicant's signature............................Date.................
                                        <br>District head's stamp, signature and date................................
                                    </p>
                                </td>
                            </tr>
                        </table>
                        <button type="submit" class="btn btn-primary" name="bott" style="background-color: #3cb371;" onclick="window.print();">
                            <span class="glyphicon glyphicon-print"></span> Print
                        </button>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-sm-3"></div>
    </div>
</div>

<!-- Footer -->
<div class="footer" style="margin-top: 45px; background-color: #2E8B57; opacity: 0.9;">
    <div class="navbar navbar-inverse navbar-fixed-bottom" style="height: 50px; background-color: #2E8B57; border-top: 2px solid red;">
        <div class="navbar-brand">
            <p style="color: #fff;">
                Copyright &#169; 2024 | <a href="http://gsu.edu.ng/" target="_blank">app.edu.ng</a> | All rights reserved.
            </p>
        </div>
    </div>
</div>
</body>
</html>
