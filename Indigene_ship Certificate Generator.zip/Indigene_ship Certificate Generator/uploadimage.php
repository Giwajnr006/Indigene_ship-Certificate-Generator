<?php
session_start();
ob_start();
require "projectconnection.php"; // Ensure this path is correct and the file exists

// Check if the session variable is set
if (!isset($_SESSION['serial_no'])) {
    header("Location: login.php");
    exit;
}

$session = $_SESSION['serial_no'];

// Use mysqli to query the database
$qury = mysqli_query($connection, "SELECT * FROM sign_up WHERE sn ='$session'");
$result = mysqli_fetch_array($qury);

if (isset($_POST['upld'])) {
    // Handle passport upload
    $passportName = $_FILES['Certificate']['name'];
    $passportSize = $_FILES['Certificate']['size'];
    $passportTmpName = $_FILES['Certificate']['tmp_name'];
    $passportNameParts = explode(".", $passportName); // Explode once
    $passportExtension = strtolower(end($passportNameParts)); // Use end() with variable

    $passportRename = str_replace("/", "", $passportName).".".$passportExtension;

    if (!empty($passportName) && ($passportExtension == 'jpg' || $passportExtension == 'png') && $passportSize <= 2097152) {
        move_uploaded_file($passportTmpName, "images/" . $passportRename);
        $passportUpload = true;
    } else {
        $passportUpload = false;
    }

    // Handle identification letter upload
    $idLetterName = $_FILES['form']['name'];
    $idLetterSize = $_FILES['form']['size'];
    $idLetterTmpName = $_FILES['form']['tmp_name'];
    $idLetterNameParts = explode(".", $idLetterName); // Explode once
    $idLetterExtension = strtolower(end($idLetterNameParts)); // Use end() with variable

    $idLetterRename = str_replace("/", "", $idLetterName).".".$idLetterExtension;

    if (!empty($idLetterName) && ($idLetterExtension == 'jpg' || $idLetterExtension == 'png') && $idLetterSize <= 2097152) {
        move_uploaded_file($idLetterTmpName, "images/" . $idLetterRename);
        $idLetterUpload = true;
    } else {
        $idLetterUpload = false;
    }

    // Handle primary certificate upload
    $primaryCertName = $_FILES['document']['name'];
    $primaryCertSize = $_FILES['document']['size'];
    $primaryCertTmpName = $_FILES['document']['tmp_name'];
    $primaryCertNameParts = explode(".", $primaryCertName); // Explode once
    $primaryCertExtension = strtolower(end($primaryCertNameParts)); // Use end() with variable

    $primaryCertRename = str_replace("/", "", $primaryCertName).".".$primaryCertExtension;

    if (!empty($primaryCertName) && ($primaryCertExtension == 'jpg' || $primaryCertExtension == 'png') && $primaryCertSize <= 2097152) {
        move_uploaded_file($primaryCertTmpName, "images/" . $primaryCertRename);
        $primaryCertUpload = true;
    } else {
        $primaryCertUpload = false;
    }

    // Handle birth certificate upload
    $birthCertName = $_FILES['doc']['name'];
    $birthCertSize = $_FILES['doc']['size'];
    $birthCertTmpName = $_FILES['doc']['tmp_name'];
    $birthCertNameParts = explode(".", $birthCertName); // Explode once
    $birthCertExtension = strtolower(end($birthCertNameParts)); // Use end() with variable

    $birthCertRename = str_replace("/", "", $birthCertName).".".$birthCertExtension;

    if (!empty($birthCertName) && ($birthCertExtension == 'jpg' || $birthCertExtension == 'png') && $birthCertSize <= 2097152) {
        move_uploaded_file($birthCertTmpName, "images/" . $birthCertRename);
        $birthCertUpload = true;
    } else {
        $birthCertUpload = false;
    }

    // Insert into database if all uploads are successful
    if ($passportUpload && $idLetterUpload && $primaryCertUpload && $birthCertUpload) {
        $query = "INSERT INTO upload_image (sn, passport, form, primary_C, birth_c) VALUES ('$session', '$passportRename', '$idLetterRename', '$primaryCertRename', '$birthCertRename')";
        mysqli_query($connection, $query);
        echo "<div class ='alert alert-success'>Your documents were uploaded successfully!</div>";
    } else {
        echo "<div class ='alert alert-danger'><strong>Error:</strong> One or more document uploads failed!</div>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Upload Image</title>
    <link rel="icon" type="image/jpeg" href="img/a1.jpeg">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Linking Bootstrap -->
    <link type="text/css" rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Linking custom CSS -->
    <link rel="stylesheet" type="text/css" href="css/font-awesome.css">
    <link rel="stylesheet" type="text/css" href="css/mystyle.css">
    <!-- Linking JS for Bootstrap -->
    <link rel="stylesheet" type="text/css" href="css/custom-slider.css"/>
    <script type="text/javascript" src="js/jquery-1.11.1.js"></script>
    <script type="text/javascript" src="js/jquery.custom-slider.js"></script>
    <script>
        $(document).ready(function(){
            $(".slider").customslider({ height:"100px", width: "100%", speed:700 });
        });
    </script>
</head>
<body style="background-image: url(images/80.png);background-size: cover;background-attachment: fixed;">

<!-- Header -->
<div class="navbar navbar-default navbar-fixed-top" style="background-color:#3cb371; height: 60px; border-bottom: 2px solid; color: yellow;">
    <div class="navbar navbar-brand">
        <a href="index.html"><img src="img/a1.jpeg" width="65%" height="65%" style="margin-top: -15px; float: left;" class="img-responsive img-circle"></a>
    </div>
    <p class="txtlogo" style="color:#fff; margin-top:25px; margin-left: -190px; font-size: 20px;">INDIGENE APPLICATION
    <a href="home.php" style="margin-left: 200px; color: #fff;"><span class="glyphicon glyphicon-log-out" style="margin-top:0px; margin-left: 200px; color:#fff;"></span> Logout</a>
    </p>
</div>

<nav class="navbar navbar-default navbar-static-top" role="navigation" style="background-color:#fff; margin-top: -3px; border-bottom: 2px solid; color: yellow;">
    <div class="container-fluid">
        <!-- Brand and toggle get grouped -->
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#col">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
        </div>
        <!-- Collect the nav links, forms, and other content for toggle -->
        <div class="collapse navbar-collapse" id="col">
            <ul class="nav navbar-nav">
                <li><a href="home.php"><span class="glyphicon glyphicon-home"></span> Home <span class="sr-only">(Current)</span></a></li>
                <li><a href="contact.php"><span class="glyphicon glyphicon-glass"></span> Biodata</a></li>
                <li class="dropdown">
                    <a href="biodata2.php" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                    <span class="glyphicon glyphicon-user"></span> YOU ARE WELCOME <?php echo strtoupper($result['fname']); ?><span class="caret"></span></a>
                    <ul class="dropdown-menu" role="menu">
                        <li><a href="mydashboard.php">Dashboard</a></li>
                        <li class="divider"></li>
                        <li class="divider"></li>
                        <li><a href="biodata2.php">Registration form </a></li>
                        <li class="divider"></li>
                        <li class="divider"></li>
                    </ul>
                </li>
            </ul>
        </div> 
    </div>
</nav>

<div class="container-fluid">
    <form method="post" enctype="multipart/form-data" action="uploadimage.php">
        <div class="row">
            <div class="col-sm-2 col-lg-2"></div>
            <div class="col-sm-4 col-lg-4">
                <div class="panel panel-success" style="margin-top: 50px;">
                    <div class="panel-heading" style="background-color:#3cb371; border-bottom: 2px solid yellowgreen;">
                        <h4 class="panel-title"><h3 class="panel-title" style="color: #fff;"><span class="glyphicon glyphicon-picture"></span> Upload your Certificate</h3></h4>
                    </div>
                    <div class="panel-body">
                        <div class="col-lg-12">
                            <input type="file" name="Certificate" />
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-4 col-lg-4">
                <div class="panel panel-success" style="margin-top: 50px;">
                    <div class="panel-heading" style="background-color:#3cb371; border-bottom: 2px solid yellowgreen;">
                        <h4 class="panel-title"><h3 class="panel-title" style="color: #fff;"><span class="glyphicon glyphicon-paperclip"></span> Upload your identification letter</h3></h4>
                    </div>
                    <div class="panel-body">
                        <div class="col-lg-12">
                            <input type="file" name="form" />
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-2 col-lg-2"></div>
        </div>
        <div class="row">
            <div class="col-sm-2 col-lg-2"></div>
            <div class="col-sm-4 col-lg-4">
                <div class="panel panel-success" style="margin-top: 10px;">
                    <div class="panel-heading" style="background-color:#3cb371; border-bottom: 2px solid yellowgreen;">
                        <h4 class="panel-title"><h3 class="panel-title" style="color: #fff;"><span class="glyphicon glyphicon-paperclip"></span> Upload Primary Certificate</h3></h4>
                    </div>
                    <div class="panel-body">
                        <div class="col-lg-12">
                            <input type="file" name="document" />
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-4 col-lg-4">
                <div class="panel panel-success" style="margin-top: 10px;">
                    <div class="panel-heading" style="background-color:#3cb371; border-bottom: 2px solid yellowgreen;">
                        <h4 class="panel-title"><h3 class="panel-title" style="color: #fff;"><span class="glyphicon glyphicon-picture"></span> Upload Birth Certificate</h3></h4>
                    </div>
                    <div class="panel-body">
                        <div class="col-lg-12">
                            <input type="file" name="doc" />
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-2 col-lg-2"></div>
        </div>
        <div class="row">
            <div class="col-sm-4 col-lg-4"></div>
            <div class="col-sm-4 col-lg-4">
                <div class="panel panel-success" style="margin-top: 10px;">
                    <div class="panel-heading" style="background-color:#3cb371; border-bottom: 2px solid yellowgreen;">
                        <h4 class="panel-title"><h3 class="panel-title" style="color: #fff;"><span class="glyphicon glyphicon-paperclip"></span> Submit</h3></h4>
                    </div>
                    <div class="panel-body">
                        <div class="col-lg-12">
                            <input type="submit" name="upld" class="btn btn-lg btn-success" value="Submit" />
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-4 col-lg-4"></div>
        </div>
    </form>
</div>

<!-- Linking Bootstrap JS -->
<script type="text/javascript" src="js/bootstrap.min.js"></script>
</body>
</html>
