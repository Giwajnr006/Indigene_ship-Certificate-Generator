<?php
require "projectconnection.php";
$date1 =date('d-m-y h:i:s');
?>
<!DOCTYPE html>
<html>
<head>
	<title>mautech.edu.ng</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
	<!--linking boostrap-->
	<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css">
	<!--linking custom CSS-->
	<!--<link rel="stylesheet" type="text/css" href="style.css">
	linking JS for boostrap-->
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
</head>
<body style="background-color: #45B8AC;">
<!--header-->
<div class ="navbar navbar-default  navbar-fixed-top" style="height: 60px; background-color: #3cb371;">
    <div class="navbar navbar-brand">
        <a <href="index.html"><img src="img/a1.jpeg" width="65%" height="65%"   style="margin-top: -15px;float: left;" class="img-responsive img-circle"></a>
    </div>
    <p class="txtlogo" style="color:#fff; margin-top:25px; margin-left: -20px; font-size: 20px;">GOMBE LOCAL GOVERNMENT</p>
    <?php echo "<a style ='float:right;margin-top:-30px; margin-right:10px;color:#fff;'>".$date1."</a>"; ?>
    </div>

<div class="container">
        <div class="row">
            <div class="col-md-offset-3 col-md-4 col-md-offset-3 col-xs-11">
                <div class="login-panel panel panel-default" style="margin-top: 100px;">
                    <div class="panel-heading" style="background-color:#3cb371; height: 4em">
                        <h3 class="panel-title" style="font-size: 20px; color: #fff;">LOGIN
                        <span class="glyphicon glyphicon-lock" style="float: right;margin:0px 0px;font-size: 36px;color: #fff;">
                        </span></h3>
                    </div>
                    <div class="panel-body">
                        <form role="form">
                            <fieldset>
                                <div class="form-group">
                                            
                                        </div>
                                <label class="label" style="color:#aaa;font-size: 15px; ">USERNAME:</label>
                                <div class="form-group input-group">
                                <span class="input-group-addon"><span class="glyphicon glyphicon-user" ></span></span>
                                    <input type="text" class="form-control" name="regno" placeholder="Enter Your PSN">
                                </div>
                                
                               <label class="label" style="color:#aaa;font-size: 15px; ">PASSWORD:</label>
                                <div class="form-group input-group">
                                    <span class="input-group-addon"><span class="glyphicon glyphicon-lock"></span></span>
                                    <input type="password" class="form-control" name="psw" placeholder="Password">
                                </div>
                                <input type="checkbox" class="check" name=""/><label class="label" style="color:#930;font-size: 15px; ">Remember Me:</label><br><br>
                                
                                <a href="adminsite.html" class="btn btn-md btn-success"><span class="glyphicon glyphicon-log-in"></span>  Admin Login</a>
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
  </footer>
<div class="w3-tag w3-highway-green">hhhh</div>
</body>
</html>