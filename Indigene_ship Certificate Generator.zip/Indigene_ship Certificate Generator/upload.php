<?php
require "connection.php";
$date1 =date('d-m-y h:i:s');
?>
<!DOCTYPE html>
<html>
<head>
	<title>mautech.edu.ng</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
	<!--linking boostrap-->
	<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css">
	<!--linking custom CSS-->
	<link rel="stylesheet" type="text/css" href="css/mystyle.css">
	<!--linking JS for boostrap-->
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<!--- I copied from getboostrap.com-->
	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
	<!-- jQuery library -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
	<!-- Latest compiled JavaScript -->
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    <!--slider-->
    <link rel="stylesheet" type="text/css" href="css/custom-slider.css"/>
    <script type="text/javascript" src="js/jquery-1.11.1.js"></script>
    <script type="text/javascript" src="js/jquery.custom-slider.js"></script>
    <script>
        $(document).ready(function(){
            $(".slider").customslider({ height:"100px", width: "100%", speed:700 })
        });
    </script>
</head>
<body>
<!--header-->
<div class ="navbar navbar-default  navbar-fixed-top" style="height: 60px;">
    <div class="navbar navbar-brand">
        <a <href="index.html"><img src="img/a1.jpeg" width="65%" height="65%"   style="margin-top: -15px;float: left;" class="img-responsive img-circle"></a>
    </div>
    <p class="txtlogo" style="color:#fff; margin-top:25px; margin-left: -20px; font-size: 20px;">GOMBE LOCAL GOVERNMENT</p>
    <?php echo "<a style ='float:right;margin-top:-30px; margin-right:10px;color:#fff;'>".$date1."</a>"; ?>
    </div>

    <div class="container"style ="margin-top:100px;">
      <div class="row">
        <div class="col-sm-4">
          <div class="panel panel-default">
            <div class="panel-heading"style ="background-color:#009d44;border-bottom: 2px solid red;">
            <h4 class="panel-title"style ="color:#fff;">Check your certificate<span class="glyphicon glyphicon-envelope"style ="float:right"></span></h4>
            </div>
            <div class="panel-body">
              <form role ="form" method="
              POST">
                <div class="form-group">
                  <div class="form-group input-group">
                   <input type="text" name="fname"placeholder="search"class="form-control">
                  <span class="input-group-addon">
                  <span class="glyphicon glyphicon-search"></span>
                  </span>
              </div>
                </div>
              </form>
            </div>
          </div>
        </div>
          <div class="col-sm-8">
            
            <div class="panel panel-default">
            <div class="panel-heading"style ="background-color:#009d44;border-bottom: 2px solid red;">
              <h4 class="panel-title"style ="color:#fff;"> Fill your bio_data<span class="glyphicon glyphicon-pencil" style="float: right;font-size: 25px;"></span> </h4>
            </div>
            <div class="panel-body">
              <form role ="form" method="
              POST">
              <div class="row">
                <div class="col-sm-4 col-lg-4">
                  <div class="form-group">
                  <label for="fname">First Name:</label>
                    <div class="form-group input-group">
                      <span class="input-group-addon">
                      <span class="glyphicon glyphicon-user"></span>
                      </span>
                      <input type="text" name="fname"placeholder="First Name"class="form-control">
                    </div>
                    </div>
                </div>

                <div class="col-sm-4 col-lg-4">
                  <div class="form-group">
                  <label for="fname">middle Name:</label>
                    <div class="form-group input-group">
                      <span class="input-group-addon">
                      <span class="glyphicon glyphicon-user"></span>
                      </span>
                      <input type="text" name="mname"placeholder="Middle Name"class="form-control">
                    </div>
                    </div>
                </div>

                <div class="col-sm-4 col-lg-4">
                  <div class="form-group">
                  <label for="fname">Last Name:</label>
                    <div class="form-group input-group">
                      <span class="input-group-addon">
                      <span class="glyphicon glyphicon-user"></span>
                      </span>
                      <input type="text" name="lname"placeholder="Last Name"class="form-control">
                    </div>
                    </div>
                </div>
              </div>

              <div class="row">

              <div class="col-sm-4 col-lg-4">
                  <div class="form-group">
                  <label for="fname">dob:</label>
                    <div class="form-group input-group">
                      <span class="input-group-addon">
                      <span class="glyphicon glyphicon-tent"></span>
                      </span>
                      <input type="date" name="dob" class="form-control" width="40px">
                    </div>
                    
                    </div>
                </div>
                <div class="col-sm-4 col-lg-4">
                  <div class="form-group">
                  <label for="fname">Gender:</label>
                    <div class="form-group input-group">
                      <span class="input-group-addon">
                      <span class="glyphicon glyphicon-apple"></span>
                      </span>
                   
                    <select name="Gender" class="form-control">
                      <option>Male</option>
                      <option>Female</option>
                    </select>
                    </div>
                  </div>
                </div>

                <div class="col-sm-4 col-lg-4">
                  <div class="form-group">
                  <label for="fname">Marital status:</label>
                    <div class="form-group input-group">
                      <span class="input-group-addon">
                      <span class="glyphicon glyphicon-leaf"></span>
                      </span>
                   
                    <select name="mstatus" class="form-control">
                      <option>single</option>
                      <option>married</option>
                      <option>divorce</option>
                    </select>
                    </div>
                  </div>
                </div>
              </div>

              
              <div class="row">
                <div class="col-sm-4 col-lg-4">
                  <div class="form-group">
                  <label for="fname">Nationality:</label>
                    <div class="form-group input-group">
                      <span class="input-group-addon">
                      <span class="glyphicon glyphicon-flag"></span>
                      </span>
                   
                    <select name="nationality" class="form-control">
                      <option>Nigeria</option>
                      <option>Niger</option>
                       <option>Camaroon</option>
                        <option>Ghana</option>
                    </select>
                    </div>
                  </div>
                </div>

                <div class="col-sm-4 col-lg-4">
                  <div class="form-group">
                  <label for="fname">State:</label>
                    <div class="form-group input-group">
                      <span class="input-group-addon">
                      <span class="glyphicon glyphicon-list"></span>
                      </span>
                   
                    <select name="State" class="form-control">
                      <option>Gombe</option>
                      <option>Kano</option>
                      <option>Bauchi</option>
                      <option>Maiduguri</option>
                      <option>Yobe</option>
                      <option>Yola</option>
                    </select>
                    </div>
                  </div>
                </div>

                <div class="col-sm-4 col-lg-4">
                  <div class="form-group">
                  <label for="fname">Select your Ward:</label>
                    <div class="form-group input-group">
                      <span class="input-group-addon">
                      <span class="glyphicon glyphicon-list"></span>
                      </span>
                     <select name="Ward" class="form-control">
                      <option>Select your Ward:</option>
                      <option>Billiri</option>
                      <option>Shamaki</option>
                      <option>Dawaki</option>
                      <option>Y/Deba</option>
                      <option>Bolari</option>
                      <option>Gikadafari</option>
                      <option>yalanguruza</option>
                    </select>
                    </div>
                    
                    </div>
                </div>


                <div class="row">
                <div class="col-sm-4 col-lg-4">
                  <div class="form-group">
                  <label for="address">Contact address:</label>
                    <div class="form-group input-group">
                      <span class="input-group-addon">
                      <span class="glyphicon glyphicon-home"></span>
                      </span>
                   
                    <input type="text" name="caddress"class="form-control"placeholder="Enter your address">
                    </div>
                  </div>
                </div>

                <div class="col-sm-4 col-lg-4">
                  <div class="form-group">
                  <label for="fname">Enter your phone no:</label>
                    <div class="form-group input-group">
                      <span class="input-group-addon">
                      <span class="glyphicon glyphicon-phone"></span>
                      </span>
                   
                    <input type="text" name="phone"class="form-control"placeholder="Enter phone no">
                    </div>
                  </div>
                </div>

                <div class="col-sm-4 col-lg-4">
                  <div class="form-group">
                  <label for="fname">Select your tribe:</label>
                    <div class="form-group input-group">
                      <span class="input-group-addon">
                      <span class="glyphicon glyphicon-list"></span>
                      </span>
                     <select name="mstatus" class="form-control">
                      <option>Select tribe:</option>
                      <option>hausa</option>
                      <option>fulani</option>
                      <option>kanuri</option>
                      <option>bolewa</option>
                      <option>terawa</option>
                      <option>yarabawa</option>
                      <option></option>
                    </select>
                    </div>
                    
                    </div>
                </div>
                </div>
                <button type="Reset" class="btn btn-danger btn-lg"style ="margin-left:30px;">
                <span class="glyphicon glyphicon-trash"> Reset</span> 
                </button>&nbsp;&nbsp;
                  <button type="submit" class="btn btn-primary btn-lg"style ="margin-left:30px;"><span class="glyphicon glyphicon-send"></span> Submit </button>
              </form>
            </div>
          </div>
          </div>
      </div>
    </div>
  
    

</body>
</html>