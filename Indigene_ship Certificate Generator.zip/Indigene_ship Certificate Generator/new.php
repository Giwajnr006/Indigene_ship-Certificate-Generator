<script type="text/javascript" src="jquery.js" ></script>

<?php  session_start(); require("projectconnection.php");
			$uname = "umar"; 
			$email = "fd"; 
			$id = "df"; 
			$phone = "08065054319"; 
?>
			 <input type="hidden" value="<?php echo $phone; ?>" id="phone" />
			 <input type="hidden" value="<?php echo $uname; ?>" id="uname" />
			 <input type="hidden" value="<?php echo $email; ?>" id="email" />
			 <input type="hidden" value="<?php echo $id; ?>" id="id" />
<?php
	if (isset($_POST['view'])){echo "<script language='javascript'>location.href='student.php'</script>"; }

if (isset($_POST['send'])){  ?>
		

			<script type="text/javascript">
				$(document).ready(function (){ 
				var uname = $('#uname').val();
				var email = $('#email').val();
				var id = $('#id').val();
				var phone = $('#phone').val();
				var sms = "Your Account was successfull Created. Your registration number is: "+id+", Your  UserName is:"+uname+" and Your  password is:"+email+"";
				
	var url = "https://kullsms.com/customer/api/?username=nuramuhammad07061@gmail.com&password=nura6199&message="+sms+"&sender=LGA-GOMBE="+phone;
	var un = "Click on view to procede to your profile";

					                alert (un);
                    $.get(url,function(){});
				});
			</script>
			
            <?php
       }     		

     ?>       
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Reg_complete</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="style.css" rel="stylesheet" type="text/css">
<link  rel="icon" type="image/gif" sizes="8x8" href="images/lg1.gif">
<style type="text/css">
<!--
.style27 {color: #FFFFFF}
.style28 {color: #0000FF}
-->
</style>
</head>
<body bgcolor="#006600"><?php include("header.php") ?>
<table width="100%" bgcolor="#003300"><tr>
  <td>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      <a href="index.php">HOME</a>&nbsp;&nbsp;&nbsp;&nbsp;
      <a href="gallery.php">GALLERY</a>&nbsp;&nbsp;&nbsp;&nbsp;
      <a href="about_us.php">ABOUT US</a>&nbsp;&nbsp;&nbsp;&nbsp;
      <a href="contact.php">CONTACT US</a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
</tr></table>

<br />
<table width="90%" height="411" border="0" align="center" >
  <tr class="transparent">
    <td width="79%" height="373" valign="top" bgcolor="#FFFFFF"> 

 <table width='400' bgcolor='ivory' height='312' align='center' cellpadding='8' style='box-shadow:0px 0px 0px 0.5px; border-radius: 10px'>
   
    <tr>
      <th height='75' align='center' valign='top' class='errormessage' scope='col'><?php  ?><hr />
	  	  <br />
                   
<form method="POST">
<input type="submit" class='buttonlong' name='send'/><br /><br />
<Label> Note: <span class="style28">click on procede after saving to procede to your account</span></Label>
<br/></br><input type="submit"  name='view' value="Proceede"/>
</form>	  </th>
      </tr>
    <tr>
      <th height='75' align='center' valign='top'  scope='col'>
    </tr>
  </table>

	</td>
  </tr>
</table>
<br />
<table width="100%" background="images/b1.jpg" height="80" border="0" align="center" bgcolor="#999999" style="box-shadow:0px 0px 7px 1px #000">
  <tr class="transparent">
    <td width="183" valign="top"> <span class="style27">Contact Address:
	xxxxxxxxxxxxxxxxxx	</span>	</td>
    <td width="161" valign="top">  <span class="style27">Phone Number:
	xxxxxxxxxxxxxxxxxxx</span> </td>
    <td width="161" valign="top"><span class="style27">Email:
	xxxxxxxxxxxxxxxxxx</span></td>
  </tr>
</table>

</body>
</html>