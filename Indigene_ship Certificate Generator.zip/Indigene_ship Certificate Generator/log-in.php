<?php
require"connection.php";

if(isset($_POST['ok'])){
	$reg_no = $_POST['regno'];
	$pass = $_POST['psw']; 

	$sq1 = "SELECT * FROM signup_tbl WHERE reg_no='$reg_no' AND password='$pass'";
	$re = mysql_query($sq1);
	$rows = mysql_num_rows($re);
	if($rows==1){
	echo "Success";
	}else{
	echo "Wrong";
	}
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>mautech.edu.ng</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
	<!--linking boostrap-->
	<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css">
	<!--linking custom CSS-->
   <link rel="stylesheet" type="text/css" href="css/mystyle.css">
	<!-- <link rel="stylesheet" type="text/css" href="css/custom.css">-->
	<!--linking JS for boostrap-->
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<!--- I copied from getboostrap.com-->
	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
	<!-- jQuery library -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
	<!-- Latest compiled JavaScript -->
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body style ="background-color:#bfbfba">
<!-- Navigation -->
<div class="container">
<div class="row">
        <nav class="navbar navbar-default navbar-fixed-top" role="navigation" style="background-color:#dde091;">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#col">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <div class="caption">
                <a class="navbar-brand" href="index.html"><img src="img/logo.png" width=30%" height="30%" style="margin-top: -15px;float: left;" class="img-responsive"><p class="txtlogo"></p></a></div>
            </div>
            <div class="collapse navbar-collapse" style="background-color: #8b0000" id="col">
            	<ul class="nav nav-tabs">
            		<li><a href="index.php">Home</a></li>
            		<li><a href="login.html" class="active">Login</a></li>
                    <li><a href="#">About</a></li>
            		<li><a href="#">Contact us</a></li>
            		<li><a href="#">Map</a></li>
            	</ul>
            </div>
            </nav>
		
 <!-- /.navbar-header -->
	</div>
</div>
<!--login-->
<div class="container">
        <div class="row">
            <div class="col-md-5 col-md-offset-3 col-xs-11">
                <div class="login-panel panel panel-default" style="margin-top: 100px;">
                    <div class="panel-heading" style="background-color:#5bc0de;height: 4em;  border-bottom: 2px solid red;">
                        <h3 class="panel-title" style="font-size: 20px;color:#fff;">LOGIN<span class="glyphicon glyphicon-lock" style="float: right;margin:0px 0px;font-size: 36px;color: #fff;"></span></h3>
                    </div>
                    <div class="panel-body">
                        <form role="form" method="post">
                            <fieldset>
                               <!-- <div class="form-group">
                                            <label class="label" style="color:#5bc0de;font-size: 15px; ">LOGIN AS:</label>
                                            <select class="form-control" >
                                                <option>Student</option>
                                                <option>Admin</option>
                                            </select>
                                        </div>-->
                                <label class="label" style="color:#5bc0de;font-size: 15px; ">USERNAME:</label>
                                <div class="form-group input-group">
                                    <span class="input-group-addon"><span class="glyphicon glyphicon-user" style="color: red"></span></span>
                                    <input type="text" class="form-control" name="regno" placeholder="Registration number">
                                </div>
                                
                               <label class="label" style="color:#5bc0de;font-size: 15px; ">PASSWORD:</label>
                                <div class="form-group input-group">
                                    <span class="input-group-addon"><span class="glyphicon glyphicon-lock" style="color: red;"></span></span>
                                    <input type="password" class="form-control" name="psw" placeholder="Password">
                                </div>
                                <!-- Change this to a button or input when using this as a form -->
                                <button type="submit" name ="ok"class="btn btn-lg btn-info btn-block"><span class="glyphicon glyphicon-log-in"></span>  Login</button>
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<!---scripft -->
 <!-- jQuery -->
    <script src="js/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

<script>
	$(function(){
		$('.nav-tabs a:first').tab('show');
	});
</script>

</body>
</html>