<?php
session_start();
require "socialconnection.php"; 
$date1 =date('d-m-y h:i:s');
if (isset($_POST['logout'])) {
        session_unset();
        header("location:home.php");
    }
	?>
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Log in</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css"/>
<link href="css/mstyle.css" rel="stylesheet" type="text/css"/>
</head>

<body style="background-color: #cdc7c7;">
<div class ="navbar navbar-default  navbar-fixed-top" style="height: 60px; box-shadow:  2px 2px 5px 4px #222;opacity: 0.9;">
    <div class="navbar navbar-brand">
        <!--<a <href="index.html"><img src="img/a1.jpeg" width="65%" height="65%"   style="margin-top: -15px;float: left;" class="img-responsive img-circle"></a>-->
    </div>
    <p class="txtlogo" style="color:#3a6182; margin-top:25px; margin-left: -20px; font-size: 20px;">GOMBE LOCAL GOVERNMENT
    	<a href="home.php" style="margin-left: 250px;"><span class="glyphicon glyphicon-log-out" style =" margin-top:0px; margin-left: 270px;"> </span> Logout</a>
    </p>
    
    </div>
<div class="container" style="margin-top: 100px;">
	<div class="row">
	<div class=" col-sm-1 col-lg-1"></div>
	<div class="col-sm-10 col-lg-10">
	<div class="panel panel-default" style="margin-top: 0px; background-color: #cdc7c7;">
<!--<div class="panel-heading"style ='background-color:#313636; height:80px;border-radius:4px; 0px; 25px; 0px;><h3 class="panel-title" style="color:#fff;margin-top: 10px; margin-left: 200px;">CHAT ROOM</h3></div>-->
<div class="panel-body">
	
			<ul class="media-list"style ="width:660px;">
			<?php
			$ql= mysql_query("SELECT * FROM comment_tbl ORDER BY coment_id ASC");
			for($i=0; $i<mysql_num_rows($ql); $i++){

				$coment =mysql_real_escape_string(trim(mysql_result($ql, $i,'comment')));
				$userid =mysql_result($ql, $i,'commentor');
				$userimage =mysql_result($ql, $i,'commenter_image');
				$comentdate =mysql_result($ql, $i,'comment_date');


				echo "
				<li class='media'style ='border-radius: 20px 10px 20px 0px; width:750px; border-bottom: 10px solid; color: #3a6182; background-color:#928b8b;'><hr>
					<div class='media_body'>
						<h3 class='media-heading' style='color:#fff; margin-left:10px'>$userid</h3>
						<p style='color:#fff; margin-left:10px'>$coment</p>
						<p style='margin-left:550px; color:#fff;'>$comentdate</p>
					
					</div>
					</li>
				";
			}
			?>
			
				
			</ul>

		<?php
		if(isset($_POST['bott'])){
			$coment =trim($_POST['coment']);
			$userid =$_SESSION['userid'];
			$date1 =date('d-m-y h:i:s');
			//echo $userid;
			if (!empty($coment)){
				$myqury =mysql_query("INSERT INTO comment_tbl VALUES('','$coment','$userid','','$date1')");
				if($myqury){
					echo "<div class ='alert alert-info'>Sent</div>";
				}else{
					echo "<div class ='alert alert-danger'>error</div>";
				}
			}
		}
			
		?>

		<form role ="form"enctype ="multipart/form-data"method="POST">
		<textarea  COLS=10 ROWS=5 name="coment" placeholder="comments"class="form-control"></textarea><br>
		<button type="submit"name ="bott" class ="btn btn-default btn-lg"style="margin-left:50px; margin-top:10px; margin-bottom:15px; background-color: #3a6182; color:#fff;">POST</button></form>
		<a href="#top" class ="btn btn-info btn-sm"style="float: right; margin-top:-55px; color: #fff; background-color: #3a6182; font-size: 13px;"role="button"> Back to top</a>
		</div>
		
		</div>
		</div>
		</div>
		<div class="col-sm-1 col-lg-1"></div>
		</div>
	</div>
</body>
</html> 

