<?php
session_start();
ob_start();
require "projectconnection.php";

if (!isset($_SESSION['serial_no'])) {
    header("Location: login.php"); // Redirect to login if session is not set
    exit;
}

$session = $_SESSION['serial_no'];

// Using prepared statement to prevent SQL injection
$query = "SELECT * FROM sign_up WHERE sn = ?";
$stmt = mysqli_prepare($connection, $query);
mysqli_stmt_bind_param($stmt, 's', $session);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if ($result) {
    $user = mysqli_fetch_array($result, MYSQLI_ASSOC);
} else {
    echo "Error fetching user data.";
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="text/image" href="img/a1.jpeg">
    <!-- linking bootstrap -->
    <link type="text/css" rel="stylesheet" href="css/bootstrap.min.css">
    <!-- linking custom CSS -->
    <link rel="stylesheet" type="text/css" href="css/mystyle.css">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.css">
    <!-- linking JS for bootstrap -->
    <script type="text/javascript" src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <style>
        .carousel-inner > .item > img,
        .carousel-inner > .item > a > img {
            width: 80%;
            height: 110%;
            margin: auto;
        }
    </style>
    <!-- slider -->
    <link rel="stylesheet" type="text/css" href="css/custom-slider.css"/>
    <script type="text/javascript" src="js/jquery-1.11.1.js"></script>
    <script type="text/javascript" src="js/jquery.custom-slider.js"></script>
    <script>
        $(document).ready(function(){
            $(".slider").customslider({ height:"px", : "%", speed:700 })
        });
    </script>
</head>
<body style="background-image: url(images/80.png);background-size: cover;background-attachment: fixed;">
<!-- header -->
<div class="navbar navbar-default navbar-fixed-top" style="background-color:#2E8B57; height: 60px; border-bottom: 2px solid; color: yellow;">
    <div class="navbar navbar-brand">
        <a href="index.html"><img src="img/a1.jpeg" width="65%" height="65%" style="margin-top: -15px;float: left;" class="img-responsive img-circle"></a>
    </div>
    <p class="txtlogo" style="color:#fff; margin-top:25px; margin-left: -190px; font-size: 20px;">GOMBE INDIGENE APPLICATION
        <div style="float: right; margin-top: -40px; margin-right: 10px; padding: 0px 10px 0px 10px;">
            <a href="www.facebook.com" title="www.facebook.com/gme.lga" ><span class="facebook"></span></a>
            <a href="www.twitter.com" title="www.twitter.com/@gme.lga"><span class="twitter"></span></a>
            <a href="www.rss.com" title="www.rss.com/gme.lga"><span class="rss"></span></a>
            <a href="www.google.com" title="www.googleplus.com/gme.lga"><span class="google"></span></a>
        </div>
    </p>

    <nav class="navbar navbar-default navbar-static-top" role="navigation" style="background-color:#fff;margin-top: -3px; border-bottom: 2px solid; color: yellow;">
        <div class="container-fluid">
            <!-- Brand and toggle get grouped -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                        data-target="#col">
                    <span class="sr-only">toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
            </div>
            <!-- collect the nav links, forms, and other content for toggle -->
            <div class="collapse navbar-collapse" id="col">
                <ul class="nav navbar-nav">
                    <li><a href="home.php" class="active">
                        <span class="glyphicon glyphicon-home"></span> Home
                        <span class="sr-only">(Current)</span></a></li>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                            <span class="glyphicon glyphicon-user"></span> You are Welcome <?php echo strtoupper($user['fname']); ?><span class=""></span></a>
                        <!--
                        <ul class="dropdown-menu" role="menu">
                            <li><a href="home.php">logout</a></li>
                            <li class="divider"></li>
                            <li><a href="create_account.php">sign up </a></li>
                            <li class="divider"></li>
                            <li><a href="biodata">Registration </a></li>
                            <li class="divider"></li>
                            <li class="divider"></li>
                            <li><a href="#">identification letter</a></li>
                        </ul>
                        -->
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</div>

<div class="container-fluid" style="margin-top: 130px;">
    <div class="row">
        <div class="col-sm-3 col-lg-3"></div>

        <div class="col-sm-3 col-lg-3">
            <div class="panel panel-default" style="background-color:#7dd28f; border: 4px solid; border-radius:6px; color: #afc0be;">
                <div class="well" style="background-color: #2E8B57; color: #fff;"><a href="biodata2.php" style="color:#fff; font-weight: 600; font-size: 15px">Apply for indigene</a></div>
                <div class="panel-body" style="background-color:#3cb371;">
                </div>
            </div>
        </div>
        <div class="col-sm-3 col-lg-3">
            <div class="panel panel-default" style="background-color: #7dd28f;  border: 4px solid; border-radius:6px; color: #afc0be;">
                <div class="well" style="background-color: #2E8B57; color:#fff;"><a href="notification.php" style="color: #fff; font-weight: 600; font-size: 15px">Check Approved</a></div>
                <div class="panel-body" style="background-color:#3cb371;">
                </div>
            </div>
        </div>

        <div class="col-sm-3 col-lg-3"></div>
    </div>

    <!-- second row -->
    <div class="row">
        <div class="col-sm-3 col-lg-3"></div>
        <div class="col-sm-3 col-lg-3">
            <div class="panel panel-default" style="background-color:#7dd28f; border: 4px solid; border-radius:6px; color: #afc0be;">
                <div class="well" style="background-color: #2E8B57; color: #fff; font-style:"><a href="printform.php" style="color: #fff; font-weight: 600; font-size: 15px">Print Identification Form</a></div>
                <div class="panel-body" style="background-color:#3cb371;">
                </div>
            </div>
        </div>
        <div class="col-sm-3 col-lg-3">
            <div class="panel panel-default" style="background-color:#7dd28f; border: 4px solid; border-radius:6px; color: #afc0be;">
                <div class="well" style="background-color: #2E8B57; color: #fff;"><a href="contact.php" style="color:#fff; font-weight: 600; font-size: 15px">Enter here for complaints</a></div>
                <div class="panel-body" style="background-color:#3cb371;">
                </div>
            </div>
        </div>

        <div class="col-sm-3 col-lg-3"></div>
    </div>
</div>

 <!-- ******begining of the footer****************-->
   <div class="footer" style="margin-top:45px; background-color: #2E8B57;opacity: 0.9;">
    <div class ="navbar navbar-inverse  navbar-fixed-bottom" style="height: 50px; background-color: #2E8B57; border-top: 2px solid yellow;">
        <div class="navbar navbar-brand"> 
        <p> <marquee direction="left" style="color: yellow;">Welcome to indigeneship online application. Copyright &#169; 2024| <a href="http://Gombe.gme.ng/" target="_blank" style="color: yellow" >Gombe.gme.ng</a> | All rights reserved. Copyright &#169; 2024 | <a href="http://Gombe.gme.ng/" target="_blank" style="color: yellow" >Gombe.gme.ng</a> | All rights reserved.</marquee><b><a href = "#Top" class="bb" style="float: right;margin-top: 40px;">back to top</a></b><p>
       

             
    </div>
 </div>
 </div>
 
 
 <!-- ************* End of the footer ****************-->

</body>
</html>