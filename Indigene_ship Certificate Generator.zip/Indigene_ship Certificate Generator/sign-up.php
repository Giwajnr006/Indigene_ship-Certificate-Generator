<?php
require"connection.php";

if(isset($_POST['submit'])){
	
	$form_number = $_POST['number'];
	$reg_no = $_POST['reg_no'];
	$mail = $_POST['email'];
	$pass = $_POST['pwd'];
	
	$sqlquery = "INSERT INTO signup_tbl (form_number, reg_no, email, password) VALUES ('$form_number', '$reg_no', '$mail', '$pass')";
	$result = mysql_query($sqlquery);
	if($result){
	echo "Record Success";
	}else{
	echo "Error";
	}
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>mautech.edu.ng</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
	<!--linking boostrap-->
	<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css">
	<!--linking custom CSS-->
	<link rel="stylesheet" type="text/css" href="css/mystyle.css">
	<!--linking JS for boostrap-->
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<!--- I copied from getboostrap.com-->
	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
	<!-- jQuery library -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
	<!-- Latest compiled JavaScript -->
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body style="background-image: url(img/bgg.jpg);background-size: cover;background-attachment: fixed;">
<!-- Navigation -->
<div>
		<nav class="navbar navbar-default navbar-fixed-top"role="navigation"style="background-color:#009d44; height:20px;">
			<div class="navbar navbar-header">
				<button type ="button"class ="navbar-toggle" data-toggle="collapse"data-target="#col">
					<span class="icon-bar">toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<div class="caption">
					<a href="#" class="navbar navbar-brand"><img src ="img/mautech-logo-1.png" width="20%px" 
					height="20%px" style ="margin-top:-20px;float:left;"class ="img-responsive">
					<p class ="text-logo" style="color:#fff;">Mautech</p></a>
					</div>
					 </div>
						<div class="collapse navbar-collapse" style="background-color:green;" id="col">
            	<ul class="nav nav-tabs">
            		<li><a href="index.html">Home</a></li>
            		<li  class="active"><a href="sign-up.html">Registration</a></li>
                    <li><a href="#">About</a></li>
            		<li><a href="#">Contact us</a></li>
            		<li><a href="#">Map</a></li>
            	</ul>
            </div>
				
			</div>
		</nav>
	<div>
	<!-- /.navbar-header -->
	<div class="container">
		<div class ="row">
			<div class ="col-md-5 col-md-offset-1 col-xs-11"style="margin-top:50px;">
				<div class ="login-panel panel panel-default">
				<div class="panel-heading"style="background-color:#1de7e9;height:4em;">
				<h3 class="panel-title"style ="font-zise:20px;">Create Account
				<span class="glyphicon glyphicon-pencil"style="float:right; font-size:30px;"></span></h3>
				</div>
				<div class ="panel-body">
					<form role="form"method="post">
						<fieldset>
							<div class="form-group">
							<label class="label"style="color:#1de7e9;font-size:20px;"></label>
							</div>
							<label class="label"style="color:#1de7e9;font-size:15px;">Form Number</label>
							<div class ="form-group input-group">
							<span class="input-group-addon"><span class="glyphicon glyphicon-info-sign"style="color:#8e2628;"></span></span>
							<input type ="text" name ="number" placeholder="Enter your form number" class="form-control">
							</div>
							<label class="label"style="color:#1de7e9;font-size:15px;">User Name</label>
							<div class ="form-group input-group">
							<span class="input-group-addon"><span class="glyphicon glyphicon-user"style="color:#8e2628;"></span></span>
							<input type ="text" name ="reg_no" placeholder="Registration number" class="form-control">
							</div>
							
							<label class="label"style="color:#1de7e9;font-size:15px;">Email address</label>
							<div class ="form-group input-group">
							<span class="input-group-addon"><span style="color:#8e2628;">@</span></span>
							<input type ="email" name ="email" placeholder="Enter your email" class="form-control">
							</div>
							<label class="label"style="color:#1de7e9;font-size:15px;">password</label>
							<div class ="form-group input-group">
							<span class="input-group-addon"><span class="glyphicon glyphicon-lock"style="color:#8e2628;"></span></span>
							<input type ="password" name ="pwd" placeholder="password" class="form-control">
							</div>
							<!-- Change this to a button or input when using this as a form -->
							<button type="subnit" name="submit" class="btn btn-primary">Sign Up</button>
						</fieldset>
					</form>
				</div>
			</div>
		</div>
	</div>
</body>

</body>
</html>