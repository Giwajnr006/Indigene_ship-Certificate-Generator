<?php
function validatepassword($pass1, $pass2){
	$returnvalue ="";
	if($pass1 == $pass2){
		$returnvalue ="true";
	}else{
		$returnvalue ="false";
	}
	RETURN $returnvalue;
}

?>