<?php
require "projectconnection.php";
$date1 =date('d-m-y h:i:s');

?>
<!DOCTYPE html>
<html>
<head>
	<title>View applcants</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="=device-, initial-scale=1.0"> 
	<!--linking boostrap-->
	<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css">
	<!--linking custom CSS-->
  <link rel="stylesheet" type="text/css" href="css/font-awesome.css">
	<link rel="stylesheet" type="text/css" href="css/mystyle.css">
	<!--linking JS for boostrap-->
  <link rel="shortcut icon" href="../favicon.ico"> 
        
	<script type="text/javascript" src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js" type="text/javascript"></script>
<!-- background slider link
<link rel="stylesheet" type="text/css" href="css/style1.css" />
    <script type="text/javascript" src="js/modernizr.custom.86080.js"></script>
    -->

    
</head>
<body>
       
        -->
<!--header-->
<div class ="navbar navbar-default  navbar-fixed-top" style="height: 60px;background-color:#2E8B57;">
    <div class="navbar navbar-brand">
        <a <href="index.html"><img src="img/a1.jpeg" width ="65%" height="55%" style="margin-top: -15px;float: left;" class="img-responsive img-circle"></a>
    </div>
    <p class="txtlogo" style="color:#fff; margin-top:25px; margin-left: -20px; font-size: 20px;">GOMBE LOCAL GOVERNMENT</p>
    <?php echo "<a style ='float:right;margin-top:-30px; margin-right:10px;color:#fff;'>".$date1."</a>"; ?>
</div>
<!-- Navigation 
<div class="container"style ="margin-top:150px">
<div class="row">
<div class ="col-md-12">
        <nav class="navbar navbar-default" role="navigation" style="background-color:#00802b;
 border-bottom: 2px solid red; margin-top:px;">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#col">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <div class="caption">
                <a class="navbar-brand" href="index.html"><img src="img/sarki.jpeg" width ="50px" height="50px" style="margin-top: -11px;float: left;" class="img-responsive img-circle"><p class="txtlogo" ></p></a></div>
            </div>
            <div class="collapse navbar-collapse" style="background-color:#00802b; border-bottom: 2px solid;"id="col">
            	<ul class="nav nav-tabs">
            		<li class="active"><a href="index.html">Home</a></li>
            		<li><a href="#">About</a></li>
            		<li><a href="#">Contact us</a></li>
                    <li><a href="#">History</a></li>
                    <li><a href="#">Gallery</a></li>
            		<li><a href="#">Map</a></li>
            	</ul>
            </div>
         </nav>
       </div>
	</div>
</div>
-->
<div class="container"style ="margin-top:150px">
  <div class="row">
    <div class="col-md-6">
      <div class="panel panel-default"style ="width:100%;">
        <div class="panel-heading">passport</div>
        <div class="panel-body">
          <img src="images/umar.jpg"width="100%">
        </div>
      </div>
    </div>
    <div class="col-md-6">
      <div class="panel panel-default"style ="width:100%;">
        <div class="panel-heading">primary certificate</div>
        <div class="panel-body">
          <img src="images/primary.jpg"width="100%">
        </div>
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col-md-6">
      <div class="panel panel-default"style ="width:100%;">
        <div class="panel-heading">Birth certificate</div>
        <div class="panel-body">
          <img src="images/nura.jpg"width="100%">
        </div>
      </div>
    </div>
    <div class="col-md-6">
      <div class="panel panel-default"style ="width:100%;">
        <div class="panel-heading">identification form</div>
        <div class="panel-body">
          <img src="images/form2.png"width="100%">
        </div>
      </div>
    </div>
  </div>
</div>
</body>
</html>