
<html>
<head>
	<title></title>
</head>
<body>
<form method="$POST" action="">
	<label>State</label><br>
	<select id ="State"  onchange ="getAbia('State','local')"/>
	<option>select state</option>

	</select>
	<select id ="local">
		<option>select your local government</option>
	</select>
	

	<script type="text/javascript">
		var Abiastate ="";
		var Abiastated =new Array("ABIA","ADMAWA","AKWAIBOM","ANAMBRA","BAUCHI","BAYELSA","BENUE","BORNO","CROSS-RIVER","DELTA","EDO","EBONYI","EKITI","ENUGU","GOMBE","IMO","JIGAWA","KADUNA","KANO","KATSINA","KEBBI","KOGI","KAWRA","LAGOS","NIGER","OGUN","OYO","NASARAWA","PLATEAU","RIVERS","SOKOTO","TARABA","YOBE","ZAMFARA");
		for(var i =0; i<Abiastated.length; i++){
			Abiastate=Abiastate+"<option value="+i+">"+Abiastated[i]+"</option>";
		}
		document.getElementById('State').innerHTML=Abiastate;

		function getAbia(abiast, abialga){
			var abialocal ="";
			var Abia = document.getElementById(abiast).value;
			var selectAbia = new Array('Aba North', 'Aba South', 'Arochukwu', 'Bende','Isiala', 'Ngwa South', 'Ikwuano', 'Ngwa North','Isiala', 'Isukwuato','Ukwa West', 'Ukwa East','Umuahia','Umuahia South');
			if(Abia =="0"){
				for(var i=0; i<=selectAbia.length; i++){
			abialocal =abialocal+"<option>"+selectAbia[i]+"</option>";
			}
			document.getElementById(abialga).innerHTML = abialocal;
			}
			}
		
	</script>
	</form>
</body>
</html>